package com.example.fuud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
