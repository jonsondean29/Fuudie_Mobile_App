import 'package:gap/gap.dart';
import 'package:flutter/material.dart';

PreferredSizeWidget customAppBar(
    {required String title,
    required GlobalKey<ScaffoldState> scaffoldKey,
    bool? locationImage}) {
  return PreferredSize(
    preferredSize: locationImage != null
        ? const Size.fromHeight(90)
        : const Size.fromHeight(50),
    child: Container(
      height: 200,
      decoration: const BoxDecoration(
        // borderRadius: BorderRadius.only(bottomRight: Radius.circular(60)),
        color: Colors.white,
      ),
      child: Stack(
        children: [
          Image.asset(
            'assets/images/top-bg.png',
            height: 80,
          ),
          locationImage != null
              ? Align(
                  alignment: Alignment.bottomLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Image.asset(
                          'assets/images/logo3.png',
                          fit: BoxFit.cover,
                          height: 60,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            title,
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Row(
                          children: [
                            locationImage
                                ? Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Image.asset(
                                        width: 37,
                                        'assets/images/language-icon.png',
                                      ),
                                      const Text(
                                        'London',
                                        style: TextStyle(fontSize: 12),
                                      ),
                                      const Gap(10)
                                    ],
                                  )
                                : const SizedBox(),
                            const Gap(10),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                const Gap(10),
                                IconButton(
                                  padding: const EdgeInsets.only(top: 10),
                                  onPressed: () {
                                    scaffoldKey.currentState!.openEndDrawer();
                                  },
                                  icon: const Icon(Icons.menu),
                                  iconSize: 37,
                                ),
                                const Text(
                                  '',
                                  style: TextStyle(fontSize: 12),
                                ),
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                )
              : const SizedBox(),
        ],
      ),
    ),
  );
}
