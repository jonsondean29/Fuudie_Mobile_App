part of 'location_bloc.dart';

@freezed
class LocationState with _$LocationState {
  // const factory LocationState.initial() = _Initial;
  const factory LocationState({
    required double latitude,
    required double longitude,
  }) = _LocationState;
  factory LocationState.initial() =>
      const LocationState(latitude: 0.0, longitude: 0.0);
}
