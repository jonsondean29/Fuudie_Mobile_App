// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'network_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NetworkEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() internetConnected,
    required TResult Function() internetDisConnected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? internetConnected,
    TResult? Function()? internetDisConnected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? internetConnected,
    TResult Function()? internetDisConnected,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InternetConnected value) internetConnected,
    required TResult Function(InternetDisConnected value) internetDisConnected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(InternetConnected value)? internetConnected,
    TResult? Function(InternetDisConnected value)? internetDisConnected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InternetConnected value)? internetConnected,
    TResult Function(InternetDisConnected value)? internetDisConnected,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkEventCopyWith<$Res> {
  factory $NetworkEventCopyWith(
          NetworkEvent value, $Res Function(NetworkEvent) then) =
      _$NetworkEventCopyWithImpl<$Res, NetworkEvent>;
}

/// @nodoc
class _$NetworkEventCopyWithImpl<$Res, $Val extends NetworkEvent>
    implements $NetworkEventCopyWith<$Res> {
  _$NetworkEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InternetConnectedImplCopyWith<$Res> {
  factory _$$InternetConnectedImplCopyWith(_$InternetConnectedImpl value,
          $Res Function(_$InternetConnectedImpl) then) =
      __$$InternetConnectedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InternetConnectedImplCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$InternetConnectedImpl>
    implements _$$InternetConnectedImplCopyWith<$Res> {
  __$$InternetConnectedImplCopyWithImpl(_$InternetConnectedImpl _value,
      $Res Function(_$InternetConnectedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InternetConnectedImpl implements InternetConnected {
  const _$InternetConnectedImpl();

  @override
  String toString() {
    return 'NetworkEvent.internetConnected()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InternetConnectedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() internetConnected,
    required TResult Function() internetDisConnected,
  }) {
    return internetConnected();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? internetConnected,
    TResult? Function()? internetDisConnected,
  }) {
    return internetConnected?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? internetConnected,
    TResult Function()? internetDisConnected,
    required TResult orElse(),
  }) {
    if (internetConnected != null) {
      return internetConnected();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InternetConnected value) internetConnected,
    required TResult Function(InternetDisConnected value) internetDisConnected,
  }) {
    return internetConnected(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(InternetConnected value)? internetConnected,
    TResult? Function(InternetDisConnected value)? internetDisConnected,
  }) {
    return internetConnected?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InternetConnected value)? internetConnected,
    TResult Function(InternetDisConnected value)? internetDisConnected,
    required TResult orElse(),
  }) {
    if (internetConnected != null) {
      return internetConnected(this);
    }
    return orElse();
  }
}

abstract class InternetConnected implements NetworkEvent {
  const factory InternetConnected() = _$InternetConnectedImpl;
}

/// @nodoc
abstract class _$$InternetDisConnectedImplCopyWith<$Res> {
  factory _$$InternetDisConnectedImplCopyWith(_$InternetDisConnectedImpl value,
          $Res Function(_$InternetDisConnectedImpl) then) =
      __$$InternetDisConnectedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InternetDisConnectedImplCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$InternetDisConnectedImpl>
    implements _$$InternetDisConnectedImplCopyWith<$Res> {
  __$$InternetDisConnectedImplCopyWithImpl(_$InternetDisConnectedImpl _value,
      $Res Function(_$InternetDisConnectedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InternetDisConnectedImpl implements InternetDisConnected {
  const _$InternetDisConnectedImpl();

  @override
  String toString() {
    return 'NetworkEvent.internetDisConnected()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InternetDisConnectedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() internetConnected,
    required TResult Function() internetDisConnected,
  }) {
    return internetDisConnected();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? internetConnected,
    TResult? Function()? internetDisConnected,
  }) {
    return internetDisConnected?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? internetConnected,
    TResult Function()? internetDisConnected,
    required TResult orElse(),
  }) {
    if (internetDisConnected != null) {
      return internetDisConnected();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InternetConnected value) internetConnected,
    required TResult Function(InternetDisConnected value) internetDisConnected,
  }) {
    return internetDisConnected(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(InternetConnected value)? internetConnected,
    TResult? Function(InternetDisConnected value)? internetDisConnected,
  }) {
    return internetDisConnected?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InternetConnected value)? internetConnected,
    TResult Function(InternetDisConnected value)? internetDisConnected,
    required TResult orElse(),
  }) {
    if (internetDisConnected != null) {
      return internetDisConnected(this);
    }
    return orElse();
  }
}

abstract class InternetDisConnected implements NetworkEvent {
  const factory InternetDisConnected() = _$InternetDisConnectedImpl;
}

/// @nodoc
mixin _$NetworkState {
  bool get isInternetConnected => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $NetworkStateCopyWith<NetworkState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkStateCopyWith<$Res> {
  factory $NetworkStateCopyWith(
          NetworkState value, $Res Function(NetworkState) then) =
      _$NetworkStateCopyWithImpl<$Res, NetworkState>;
  @useResult
  $Res call({bool isInternetConnected});
}

/// @nodoc
class _$NetworkStateCopyWithImpl<$Res, $Val extends NetworkState>
    implements $NetworkStateCopyWith<$Res> {
  _$NetworkStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isInternetConnected = null,
  }) {
    return _then(_value.copyWith(
      isInternetConnected: null == isInternetConnected
          ? _value.isInternetConnected
          : isInternetConnected // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$NetworkStateImplCopyWith<$Res>
    implements $NetworkStateCopyWith<$Res> {
  factory _$$NetworkStateImplCopyWith(
          _$NetworkStateImpl value, $Res Function(_$NetworkStateImpl) then) =
      __$$NetworkStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isInternetConnected});
}

/// @nodoc
class __$$NetworkStateImplCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$NetworkStateImpl>
    implements _$$NetworkStateImplCopyWith<$Res> {
  __$$NetworkStateImplCopyWithImpl(
      _$NetworkStateImpl _value, $Res Function(_$NetworkStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isInternetConnected = null,
  }) {
    return _then(_$NetworkStateImpl(
      isInternetConnected: null == isInternetConnected
          ? _value.isInternetConnected
          : isInternetConnected // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$NetworkStateImpl implements _NetworkState {
  const _$NetworkStateImpl({required this.isInternetConnected});

  @override
  final bool isInternetConnected;

  @override
  String toString() {
    return 'NetworkState(isInternetConnected: $isInternetConnected)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NetworkStateImpl &&
            (identical(other.isInternetConnected, isInternetConnected) ||
                other.isInternetConnected == isInternetConnected));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isInternetConnected);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NetworkStateImplCopyWith<_$NetworkStateImpl> get copyWith =>
      __$$NetworkStateImplCopyWithImpl<_$NetworkStateImpl>(this, _$identity);
}

abstract class _NetworkState implements NetworkState {
  const factory _NetworkState({required final bool isInternetConnected}) =
      _$NetworkStateImpl;

  @override
  bool get isInternetConnected;
  @override
  @JsonKey(ignore: true)
  _$$NetworkStateImplCopyWith<_$NetworkStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
