import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';

part 'network_bloc.freezed.dart';
part 'network_event.dart';
part 'network_state.dart';

@injectable
class NetworkBloc extends Bloc<NetworkEvent, NetworkState> {
  StreamSubscription? connectivityStream;

  NetworkBloc() : super(NetworkState.initial()) {
    /* set Stream listner to listen for network changes */
    connectivityStream =
        Connectivity().onConnectivityChanged.listen((networkConnetivity) {
      if (networkConnetivity == ConnectivityResult.wifi ||
          networkConnetivity == ConnectivityResult.mobile) {
        /* if internet is connected call internetConnected 
        function to set isInternetConnected to true */
        add(const NetworkEvent.internetConnected());
      } else {
        /* if internet is not connected call internetDisConnected 
        function to set isInternetConnected to false */
        add(const NetworkEvent.internetDisConnected());
      }
    });
    /* event for emit  isInternetConnected true state*/
    on<InternetConnected>(
        (event, emit) => emit(state.copyWith(isInternetConnected: true)));
    /* event for emit  isInternetConnected false state*/
    on<InternetDisConnected>(
        (event, emit) => emit(state.copyWith(isInternetConnected: false)));
  }

  @override
  Future<void> close() {
    /* close stream when the bloc close to prevent memory leaks */
    connectivityStream?.cancel();
    return super.close();
  }
}
