import 'dart:convert';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/data/models/signin_responce_model.dart';

abstract class SignInRemoteDatasource {
  Future<SignInResponce> signInUser(SigninParams params);
}

@LazySingleton(as: SignInRemoteDatasource)
class SignInRemoteDatasourceImpl implements SignInRemoteDatasource {
  final Client client;
  SignInRemoteDatasourceImpl({required this.client});

  @override
  Future<SignInResponce> signInUser(SigninParams params) async {
    debugPrint('params ${jsonEncode(params.toJson())}');
    try {
      final response = await client.post(
        Uri.parse(Apis.signIn),
        body: jsonEncode(params.toJson()),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        debugPrint('myResponce ${response.statusCode}, : ${response.body} ');

        final responseBody = json.decode(response.body);
        if (responseBody['returnId'] is Map<String, dynamic>) {
          final user = SignInResponce.fromJson(responseBody);
          if (user.messageType == 1) {
            await saveint('id', user.returnId!.id!);
            return user;
          } else {
            // throw CacheException();
            throw ServerException(errorMessage: user.message!);
          }
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: responseBody['message']);
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
