import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
import 'package:fuud/features/auth/data/models/signin_responce_model.dart';
// signin_responce_extensions.dart

extension SignInResponceX on SignInResponce {
  SignInEntity toEntity() {
    return SignInEntity(
      messageType: messageType,
      message: message,
      returnId: returnId,
    );
  }
}
