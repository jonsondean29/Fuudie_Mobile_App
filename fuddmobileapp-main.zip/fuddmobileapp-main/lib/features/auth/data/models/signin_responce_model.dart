import 'dart:convert';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
// ignore_for_file: invalid_annotation_target

// To parse this JSON data, do
//
//     final signInResponce = signInResponceFromJson(jsonString);

part 'signin_responce_model.freezed.dart';
part 'signin_responce_model.g.dart';

SignInResponce signInResponceFromJson(String str) =>
    SignInResponce.fromJson(json.decode(str));

String signInResponceToJson(SignInResponce data) => json.encode(data.toJson());

@freezed
class SignInResponce extends SignInEntity with _$SignInResponce {
  const factory SignInResponce({
    @JsonKey(name: "messageType") int? messageType,
    @JsonKey(name: "message") String? message,
    @JsonKey(name: "returnId") ReturnId? returnId,
  }) = _SignInResponce;

  factory SignInResponce.fromJson(Map<String, dynamic> json) =>
      _$SignInResponceFromJson(json);
}

@freezed
class ReturnId with _$ReturnId {
  const factory ReturnId({
    @JsonKey(name: "id") int? id,
    @JsonKey(name: "name") String? name,
    @JsonKey(name: "email") String? email,
    @JsonKey(name: "password") String? password,
    @JsonKey(name: "token") dynamic token,
    @JsonKey(name: "usertype") int? usertype,
    @JsonKey(name: "refercode") String? refercode,
    @JsonKey(name: "referbyid") int? referbyid,
    @JsonKey(name: "profileimg") String? profileimg,
    @JsonKey(name: "phone") dynamic phone,
    @JsonKey(name: "address") dynamic address,
    @JsonKey(name: "city") dynamic city,
    @JsonKey(name: "state") dynamic state,
    @JsonKey(name: "country") dynamic country,
    @JsonKey(name: "pincode") dynamic pincode,
    @JsonKey(name: "createdon") DateTime? createdon,
    @JsonKey(name: "userrole") int? userrole,
    @JsonKey(name: "isactive") int? isactive,
    @JsonKey(name: "updatedon") dynamic updatedon,
    @JsonKey(name: "issubscribed") int? issubscribed,
    @JsonKey(name: "totbooked") int? totbooked,
    @JsonKey(name: "lastbookedon") DateTime? lastbookedon,
    @JsonKey(name: "mainimg") dynamic mainimg,
    @JsonKey(name: "adminmanage") int? adminmanage,
    @JsonKey(name: "customermanage") int? customermanage,
    @JsonKey(name: "orderlist") int? orderlist,
    @JsonKey(name: "productmodule") int? productmodule,
    @JsonKey(name: "manufacturermodule") int? manufacturermodule,
    @JsonKey(name: "recipemodule") int? recipemodule,
    @JsonKey(name: "newslettermanage") int? newslettermanage,
    @JsonKey(name: "taxdiscountmanage") int? taxdiscountmanage,
    @JsonKey(name: "couponmanage") int? couponmanage,
    @JsonKey(name: "pagemanage") int? pagemanage,
    @JsonKey(name: "generalsettings") int? generalsettings,
    @JsonKey(name: "notifytolowstock") int? notifytolowstock,
    @JsonKey(name: "userright") dynamic userright,
  }) = _ReturnId;

  factory ReturnId.fromJson(Map<String, dynamic> json) =>
      _$ReturnIdFromJson(json);
}
