// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signup_responce_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SignUpResponceImpl _$$SignUpResponceImplFromJson(Map<String, dynamic> json) =>
    _$SignUpResponceImpl(
      messageType: json['messageType'] as int?,
      message: json['message'] as String?,
      returnId: json['returnId'] == null
          ? null
          : ReturnId.fromJson(json['returnId'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$SignUpResponceImplToJson(
        _$SignUpResponceImpl instance) =>
    <String, dynamic>{
      'messageType': instance.messageType,
      'message': instance.message,
      'returnId': instance.returnId,
    };

_$ReturnIdImpl _$$ReturnIdImplFromJson(Map<String, dynamic> json) =>
    _$ReturnIdImpl(
      id: json['id'] as int?,
      name: json['name'] as String?,
      email: json['email'] as String?,
      password: json['password'] as String?,
      token: json['token'],
      usertype: json['usertype'] as int?,
      refercode: json['refercode'] as String?,
      referbyid: json['referbyid'] as int?,
      profileimg: json['profileimg'] as String?,
      phone: json['phone'],
      address: json['address'],
      city: json['city'],
      state: json['state'],
      country: json['country'],
      pincode: json['pincode'],
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
      userrole: json['userrole'] as int?,
      isactive: json['isactive'] as int?,
      updatedon: json['updatedon'],
      issubscribed: json['issubscribed'] as int?,
      totbooked: json['totbooked'] as int?,
      lastbookedon: json['lastbookedon'] == null
          ? null
          : DateTime.parse(json['lastbookedon'] as String),
      mainimg: json['mainimg'],
      adminmanage: json['adminmanage'] as int?,
      customermanage: json['customermanage'] as int?,
      orderlist: json['orderlist'] as int?,
      productmodule: json['productmodule'] as int?,
      manufacturermodule: json['manufacturermodule'] as int?,
      recipemodule: json['recipemodule'] as int?,
      newslettermanage: json['newslettermanage'] as int?,
      taxdiscountmanage: json['taxdiscountmanage'] as int?,
      couponmanage: json['couponmanage'] as int?,
      pagemanage: json['pagemanage'] as int?,
      generalsettings: json['generalsettings'] as int?,
      notifytolowstock: json['notifytolowstock'] as int?,
      userright: json['userright'],
    );

Map<String, dynamic> _$$ReturnIdImplToJson(_$ReturnIdImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'email': instance.email,
      'password': instance.password,
      'token': instance.token,
      'usertype': instance.usertype,
      'refercode': instance.refercode,
      'referbyid': instance.referbyid,
      'profileimg': instance.profileimg,
      'phone': instance.phone,
      'address': instance.address,
      'city': instance.city,
      'state': instance.state,
      'country': instance.country,
      'pincode': instance.pincode,
      'createdon': instance.createdon?.toIso8601String(),
      'userrole': instance.userrole,
      'isactive': instance.isactive,
      'updatedon': instance.updatedon,
      'issubscribed': instance.issubscribed,
      'totbooked': instance.totbooked,
      'lastbookedon': instance.lastbookedon?.toIso8601String(),
      'mainimg': instance.mainimg,
      'adminmanage': instance.adminmanage,
      'customermanage': instance.customermanage,
      'orderlist': instance.orderlist,
      'productmodule': instance.productmodule,
      'manufacturermodule': instance.manufacturermodule,
      'recipemodule': instance.recipemodule,
      'newslettermanage': instance.newslettermanage,
      'taxdiscountmanage': instance.taxdiscountmanage,
      'couponmanage': instance.couponmanage,
      'pagemanage': instance.pagemanage,
      'generalsettings': instance.generalsettings,
      'notifytolowstock': instance.notifytolowstock,
      'userright': instance.userright,
    };
