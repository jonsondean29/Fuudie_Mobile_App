import 'package:fuud/features/auth/data/models/signin_responce_model.dart';

class SignInEntity {
  final int? messageType;
  final String? message;
  final ReturnId? returnId;

  SignInEntity(
      {required this.messageType,
      required this.message,
      required this.returnId});
}
