import 'package:fuud/features/auth/data/models/signup_responce_model.dart';

class SignUpEntity {
  final int? messageType;
  final String? message;
  final ReturnId? returnId;

  SignUpEntity(
      {required this.messageType,
      required this.message,
      required this.returnId});
}
