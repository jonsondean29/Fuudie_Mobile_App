import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';

abstract class SignInRepository {
  Future<Either<Failure, SignInEntity>> signinUser(SigninParams params);
}
