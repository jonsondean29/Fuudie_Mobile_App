import 'dart:io';
import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_form.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_apple.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_google.dart';

@RoutePage()
class SigninPage extends StatefulWidget {
  const SigninPage({super.key});
  static const routeName = '/signin';

  @override
  State<SigninPage> createState() => _SigninPageState();
}

class _SigninPageState extends State<SigninPage> with WidgetsBindingObserver {
  final emailController = TextEditingController();

  final passwordController = TextEditingController();
  bool isKeyboardActive = false;
  final formKey = GlobalKey<FormState>();
  @override
  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeMetrics() {
    final bool isKeyboardShowing = MediaQuery.of(context).viewInsets.bottom > 0;
    setState(() {
      isKeyboardActive = isKeyboardShowing;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: Image.asset(
              'assets/images/top-bg.png',
              height: 100,
            ),
          ),
          if (!isKeyboardActive)
            GestureDetector(
              onTap: () {
                context.router.push(const SigninRoute());
              },
              child: Align(
                alignment: Alignment.bottomRight,
                child: Image.asset(
                  'assets/images/footer-bg.png',
                  height: 100,
                ),
              ),
            ),
          ListView(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MediaQuery.of(context).size.height > 800
                      ? Gap(MediaQuery.of(context).size.height * 0.1)
                      : const Gap(20),
                  Center(
                    child: Container(
                      height: 140,
                      width: 160,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.white,
                        border: Border.all(width: 2, color: AppColors.black),
                      ),
                      child: const Center(
                        child: Text(
                          'Fuud',
                          style: TextStyle(
                              fontSize: 50,
                              fontWeight: FontWeight.w900,
                              color: AppColors.black),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Log In',
                          style: TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SignInForm(
                            emailController: emailController,
                            passwordController: passwordController,
                            formKey: formKey),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                              onPressed: () {},
                              child: const Text(
                                'Forgot password ?',
                                style: TextStyle(
                                    color: Colors.black, fontSize: 16),
                              ),
                            )
                          ],
                        ),
                        BlocConsumer<AuthBloc, AuthState>(
                          listener: (context, state) {},
                          builder: (context, state) {
                            return state.maybeWhen(
                              success: (signInEntity, signUpEntity) {
                                // WidgetsBinding.instance
                                //     .addPostFrameCallback((_) {
                                //   );
                                // });
                                // return const SizedBox();
                                return GestureDetector(
                                  onTap: () {
                                    if (formKey.currentState!.validate()) {
                                      context.read<AuthBloc>().add(
                                            Login(
                                              context: context,
                                              signinParams: SigninParams(
                                                email:
                                                    emailController.text.trim(),
                                                password: passwordController
                                                    .text
                                                    .trim(),
                                              ),
                                            ),
                                          );
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                        color: AppColors.black,
                                        borderRadius:
                                            BorderRadius.circular(50)),
                                    child: const Center(
                                      child: Text(
                                        'Log In',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                );
                              },
                              loading: () => const Center(
                                  child: CircularProgressIndicator()),
                              orElse: () {
                                return GestureDetector(
                                  onTap: () {
                                    if (formKey.currentState!.validate()) {
                                      context.read<AuthBloc>().add(
                                            Login(
                                              context: context,
                                              signinParams: SigninParams(
                                                email:
                                                    emailController.text.trim(),
                                                password: passwordController
                                                    .text
                                                    .trim(),
                                              ),
                                            ),
                                          );
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                        color: AppColors.black,
                                        borderRadius:
                                            BorderRadius.circular(50)),
                                    child: const Center(
                                      child: Text(
                                        'Log In',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        Center(
                          child: RichText(
                            overflow: TextOverflow.clip,
                            text: TextSpan(
                              children: [
                                const TextSpan(
                                    text: 'By Login You Agree to the ',
                                    style: TextStyle(color: Colors.black)),
                                TextSpan(
                                  text: 'Terms of Service',
                                  style: const TextStyle(
                                    decoration: TextDecoration.underline,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      showDialog(
                                        barrierDismissible: false,
                                        // barrierColor: Colors.white,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Container();
                                        },
                                      );
                                    },
                                ),
                                const TextSpan(
                                    text: ' and ',
                                    style: TextStyle(color: Colors.black)),
                                TextSpan(
                                  text: 'Privacy Policy',
                                  style: const TextStyle(
                                    decoration: TextDecoration.underline,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      showDialog(
                                        barrierDismissible: false,
                                        // barrierColor: Colors.white,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Container();
                                        },
                                      );
                                    },
                                ),
                                const TextSpan(
                                    text: ' including usage of cookies ',
                                    style: TextStyle(color: Colors.black)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        Platform.isAndroid
                            ? Center(
                                child: Material(
                                    color: Colors.white,
                                    elevation: 5,
                                    borderRadius: BorderRadius.circular(8),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SizedBox(
                                        width: 160,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            const Text(
                                              'Login with',
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            GoogleSignInButton(),
                                          ],
                                        ),
                                      ),
                                    )),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  GoogleSignInButton(),
                                  const Gap(50),
                                  const AppleSignInButton()
                                ],
                              ),
                        const Gap(20),
                        Center(
                          child: InkWell(
                            onTap: () {
                              context.router.push(const SignupRoute());
                            },
                            child: RichText(
                              text: const TextSpan(
                                text: 'You Don\'t Have An Account Yet? ',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                                children: <TextSpan>[
                                  TextSpan(
                                    text: 'Sign Up',
                                    style: TextStyle(
                                        color: AppColors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
