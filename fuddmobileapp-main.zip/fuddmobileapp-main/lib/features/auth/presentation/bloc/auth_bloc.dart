import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:injectable/injectable.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
import 'package:fuud/features/auth/domain/entities/sign_up_entity.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';

part 'auth_event.dart';
part 'auth_state.dart';
part 'auth_bloc.freezed.dart';

@injectable
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SignInUsecase signInUsecase;
  final SignUpUsecase signUpUsecase;
  AuthBloc({required this.signInUsecase, required this.signUpUsecase})
      : super(const _Initial()) {
    on<AuthEvent>(
      (event, emit) async {
        if (event is Login) {
          emit(const AuthState.loading());
          final result = await signInUsecase.call(event.signinParams);
          result.fold(
            (l) {
              emit(AuthState.failure(l.message));
              Fluttertoast.showToast(
                  msg: l.message,
                  toastLength: Toast.LENGTH_LONG,
                  gravity: ToastGravity.BOTTOM,
                  timeInSecForIosWeb: 1,
                  backgroundColor: Colors.red,
                  textColor: Colors.white,
                  fontSize: 16.0);
            },
            (r) {
              event.context.router.replace(const DashboardRoute());
              emit(AuthState.success(signInEntity: r));
            },
          );
        } else if (event is Signup) {
          emit(const AuthState.loading());
          final result = await signUpUsecase.call(event.signUpParams);
          result.fold(
            (l) {
              emit(AuthState.failure(l.message));
              Fluttertoast.showToast(
                  msg: l.message,
                  toastLength: Toast.LENGTH_LONG,
                  gravity: ToastGravity.BOTTOM,
                  timeInSecForIosWeb: 1,
                  backgroundColor: Colors.red,
                  textColor: Colors.white,
                  fontSize: 16.0);
            },
            (r) {
              emit(AuthState.success(signUpEntity: r));
            },
          );
        }
      },
    );
  }
}
