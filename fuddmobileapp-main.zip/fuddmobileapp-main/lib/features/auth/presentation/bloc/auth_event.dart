part of 'auth_bloc.dart';

@freezed
class AuthEvent with _$AuthEvent {
  const factory AuthEvent.login(
      {required SigninParams signinParams,
      required BuildContext context}) = Login;

  const factory AuthEvent.signup(SignUpParams signUpParams) = Signup;
}
