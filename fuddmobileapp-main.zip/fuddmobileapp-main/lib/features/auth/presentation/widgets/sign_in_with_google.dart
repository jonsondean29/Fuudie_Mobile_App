import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';

class GoogleSignInButton extends StatelessWidget {
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);

  GoogleSignInButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
          if (googleUser == null) {
            // User cancelled Google sign-in
            return;
          }

          String? email = googleUser.email;

          if (email.isNotEmpty) {
            if (context.mounted) {
              context.read<AuthBloc>().add(
                    Login(
                        signinParams: SigninParams(
                          email: email,
                          password: "Fudd@2024",
                        ),
                        context: context),
                  );
            }
          } else {
            // Handle the case when email is null after successful sign-in
            Fluttertoast.showToast(
              msg: 'Email not provided by Google sign-in',
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0,
            );
          }
        } catch (error) {
          // Handle Google sign-in errors
          Fluttertoast.showToast(
            msg: error.toString(),
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
      child: SvgPicture.asset('assets/images/google-icon.svg'),
    );
  }
}
