import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';

class GoogleSignUpButton extends StatelessWidget {
  final GoogleSignIn _googleSignUp = GoogleSignIn(scopes: ['email']);

  GoogleSignUpButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          await _googleSignUp.signIn();

          String? email = _googleSignUp.currentUser?.email;
          String? displayName = _googleSignUp.currentUser?.displayName;

          if (email != null && displayName != null) {
            if (context.mounted) {
              context.read<AuthBloc>().add(
                    Signup(
                      SignUpParams(
                        email: email,
                        password: "Fudd@2024",
                        name: displayName,
                      ),
                    ),
                  );
            }
          } else {
            Fluttertoast.showToast(
              msg: 'Failed to retrieve email or name from Google sign-in',
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0,
            );
          }
        } catch (error) {
          Fluttertoast.showToast(
            msg: error.toString(),
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
      child: SvgPicture.asset('assets/images/google-icon.svg'),
    );
  }
}
