import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:fuud/features/activity/presentation/bloc/activity_bloc.dart';
import 'package:fuud/features/activity/presentation/widgets/comments_widget.dart';

@RoutePage()
class ActivityPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final searchControoler = TextEditingController();
  final commentController = TextEditingController();
  ActivityPage({super.key});
  static const routeName = 'activity';

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ActivityBloc>().add(const GetCommets());
    });
    return Scaffold(
      bottomNavigationBar: Container(
        margin: const EdgeInsets.only(left: 10, right: 10),
        child: Row(
          children: [
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/comment.png',
                  height: 50,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            const Gap(10),
            Expanded(
                child: InputField(
              hintText: "Add a Comment",
              controller: commentController,
              suffixIcon: Image.asset(
                'assets/images/icon-ma.png',
                height: 15,
              ),
            )),
          ],
        ),
      ),
      key: _scaffoldKey,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: false),
      endDrawer: const AppDrawer(),
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.all(10),
          child: Column(
            children: [
              const Gap(10),
              SearchBar(
                hintText: "Search ",
                leading: const Icon(Icons.search),
                surfaceTintColor: const MaterialStatePropertyAll(
                    Color.fromARGB(0, 227, 252, 252)),
                elevation: const MaterialStatePropertyAll(0),
                shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                    side: const BorderSide(width: 1, color: Colors.black),
                    borderRadius: BorderRadius.circular(10))),
              ),
              const Gap(20),
              BlocBuilder<ActivityBloc, ActivityState>(
                builder: (context, state) {
                  return Expanded(
                      child: ListView.builder(
                    itemCount: state.getCommentsEntity.length,
                    itemBuilder: (context, index) => CommentsWidget(
                      getCommentsEntity: state.getCommentsEntity[index],
                    ),
                  ));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
