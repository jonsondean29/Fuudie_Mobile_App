import 'package:injectable/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/usecases/get_comments_usecase.dart';

part 'activity_event.dart';
part 'activity_state.dart';
part 'activity_bloc.freezed.dart';

@injectable
class ActivityBloc extends Bloc<ActivityEvent, ActivityState> {
  final GetCommentsUsecase getCommentsUsecase;
  ActivityBloc({required this.getCommentsUsecase})
      : super(ActivityState.initial()) {
    on<GetCommets>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await getCommentsUsecase.call();
      result.fold((l) => null,
          (r) => emit(state.copyWith(isLoading: false, getCommentsEntity: r)));
    });
  }
}
