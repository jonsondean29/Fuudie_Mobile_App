part of 'activity_bloc.dart';

@freezed
class ActivityState with _$ActivityState {
  const factory ActivityState(
      {required bool isLoading,
      required List<GetCommentsEntity> getCommentsEntity}) = _ActivityState;
  factory ActivityState.initial() =>
      const ActivityState(isLoading: false, getCommentsEntity: []);
}
