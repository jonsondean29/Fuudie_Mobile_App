class GetCommentsEntity {
  final int id;
  final int creatorid;
  final String creatorname;
  final String title;
  final String description;
  final String usertype;
  final int totview;
  final int totreply;
  final int totlike;
  final int totdislike;
  final int totshare;
  final String slug;
  final DateTime createdon;
  final int isactive;
  final DateTime lastreply;
  final dynamic replies;

  GetCommentsEntity({
    required this.id,
    required this.creatorid,
    required this.creatorname,
    required this.title,
    required this.description,
    required this.usertype,
    required this.totview,
    required this.totreply,
    required this.totlike,
    required this.totdislike,
    required this.totshare,
    required this.slug,
    required this.createdon,
    required this.isactive,
    required this.lastreply,
    required this.replies,
  });
}
