import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';

abstract class GetCommentsRepository {
  Future<Either<Failure, List<GetCommentsEntity>>> getGetComments();
}
