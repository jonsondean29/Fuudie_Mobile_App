import 'dart:convert';
import 'package:freezed_annotation/freezed_annotation.dart';
// ignore_for_file: invalid_annotation_target

// To parse this JSON data, do
//
//     final getCommentsModel = getCommentsModelFromJson(jsonString);

part 'get_comments_model.freezed.dart';
part 'get_comments_model.g.dart';

List<GetCommentsModel> getCommentsModelFromJson(String str) =>
    List<GetCommentsModel>.from(
        json.decode(str).map((x) => GetCommentsModel.fromJson(x)));

String getCommentsModelToJson(List<GetCommentsModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

@freezed
class GetCommentsModel with _$GetCommentsModel {
  const factory GetCommentsModel({
    @JsonKey(name: "id") required int id,
    @JsonKey(name: "creatorid") required int creatorid,
    @JsonKey(name: "creatorname") required String creatorname,
    @JsonKey(name: "title") required String title,
    @JsonKey(name: "description") required String description,
    @JsonKey(name: "usertype") required String usertype,
    @JsonKey(name: "totview") required int totview,
    @JsonKey(name: "totreply") required int totreply,
    @JsonKey(name: "totlike") required int totlike,
    @JsonKey(name: "totdislike") required int totdislike,
    @JsonKey(name: "totshare") required int totshare,
    @JsonKey(name: "slug") required String slug,
    @JsonKey(name: "createdon") required DateTime createdon,
    @JsonKey(name: "isactive") required int isactive,
    @JsonKey(name: "lastreply") required DateTime lastreply,
    @JsonKey(name: "replies") required dynamic replies,
  }) = _GetCommentsModel;

  factory GetCommentsModel.fromJson(Map<String, dynamic> json) =>
      _$GetCommentsModelFromJson(json);
}
