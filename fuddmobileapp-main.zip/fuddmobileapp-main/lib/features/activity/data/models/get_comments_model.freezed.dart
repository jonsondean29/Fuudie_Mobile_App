// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_comments_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

GetCommentsModel _$GetCommentsModelFromJson(Map<String, dynamic> json) {
  return _GetCommentsModel.fromJson(json);
}

/// @nodoc
mixin _$GetCommentsModel {
  @JsonKey(name: "id")
  int get id => throw _privateConstructorUsedError;
  @JsonKey(name: "creatorid")
  int get creatorid => throw _privateConstructorUsedError;
  @JsonKey(name: "creatorname")
  String get creatorname => throw _privateConstructorUsedError;
  @JsonKey(name: "title")
  String get title => throw _privateConstructorUsedError;
  @JsonKey(name: "description")
  String get description => throw _privateConstructorUsedError;
  @JsonKey(name: "usertype")
  String get usertype => throw _privateConstructorUsedError;
  @JsonKey(name: "totview")
  int get totview => throw _privateConstructorUsedError;
  @JsonKey(name: "totreply")
  int get totreply => throw _privateConstructorUsedError;
  @JsonKey(name: "totlike")
  int get totlike => throw _privateConstructorUsedError;
  @JsonKey(name: "totdislike")
  int get totdislike => throw _privateConstructorUsedError;
  @JsonKey(name: "totshare")
  int get totshare => throw _privateConstructorUsedError;
  @JsonKey(name: "slug")
  String get slug => throw _privateConstructorUsedError;
  @JsonKey(name: "createdon")
  DateTime get createdon => throw _privateConstructorUsedError;
  @JsonKey(name: "isactive")
  int get isactive => throw _privateConstructorUsedError;
  @JsonKey(name: "lastreply")
  DateTime get lastreply => throw _privateConstructorUsedError;
  @JsonKey(name: "replies")
  dynamic get replies => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetCommentsModelCopyWith<GetCommentsModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetCommentsModelCopyWith<$Res> {
  factory $GetCommentsModelCopyWith(
          GetCommentsModel value, $Res Function(GetCommentsModel) then) =
      _$GetCommentsModelCopyWithImpl<$Res, GetCommentsModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int id,
      @JsonKey(name: "creatorid") int creatorid,
      @JsonKey(name: "creatorname") String creatorname,
      @JsonKey(name: "title") String title,
      @JsonKey(name: "description") String description,
      @JsonKey(name: "usertype") String usertype,
      @JsonKey(name: "totview") int totview,
      @JsonKey(name: "totreply") int totreply,
      @JsonKey(name: "totlike") int totlike,
      @JsonKey(name: "totdislike") int totdislike,
      @JsonKey(name: "totshare") int totshare,
      @JsonKey(name: "slug") String slug,
      @JsonKey(name: "createdon") DateTime createdon,
      @JsonKey(name: "isactive") int isactive,
      @JsonKey(name: "lastreply") DateTime lastreply,
      @JsonKey(name: "replies") dynamic replies});
}

/// @nodoc
class _$GetCommentsModelCopyWithImpl<$Res, $Val extends GetCommentsModel>
    implements $GetCommentsModelCopyWith<$Res> {
  _$GetCommentsModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? creatorid = null,
    Object? creatorname = null,
    Object? title = null,
    Object? description = null,
    Object? usertype = null,
    Object? totview = null,
    Object? totreply = null,
    Object? totlike = null,
    Object? totdislike = null,
    Object? totshare = null,
    Object? slug = null,
    Object? createdon = null,
    Object? isactive = null,
    Object? lastreply = null,
    Object? replies = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      creatorid: null == creatorid
          ? _value.creatorid
          : creatorid // ignore: cast_nullable_to_non_nullable
              as int,
      creatorname: null == creatorname
          ? _value.creatorname
          : creatorname // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      usertype: null == usertype
          ? _value.usertype
          : usertype // ignore: cast_nullable_to_non_nullable
              as String,
      totview: null == totview
          ? _value.totview
          : totview // ignore: cast_nullable_to_non_nullable
              as int,
      totreply: null == totreply
          ? _value.totreply
          : totreply // ignore: cast_nullable_to_non_nullable
              as int,
      totlike: null == totlike
          ? _value.totlike
          : totlike // ignore: cast_nullable_to_non_nullable
              as int,
      totdislike: null == totdislike
          ? _value.totdislike
          : totdislike // ignore: cast_nullable_to_non_nullable
              as int,
      totshare: null == totshare
          ? _value.totshare
          : totshare // ignore: cast_nullable_to_non_nullable
              as int,
      slug: null == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String,
      createdon: null == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isactive: null == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int,
      lastreply: null == lastreply
          ? _value.lastreply
          : lastreply // ignore: cast_nullable_to_non_nullable
              as DateTime,
      replies: freezed == replies
          ? _value.replies
          : replies // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetCommentsModelImplCopyWith<$Res>
    implements $GetCommentsModelCopyWith<$Res> {
  factory _$$GetCommentsModelImplCopyWith(_$GetCommentsModelImpl value,
          $Res Function(_$GetCommentsModelImpl) then) =
      __$$GetCommentsModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int id,
      @JsonKey(name: "creatorid") int creatorid,
      @JsonKey(name: "creatorname") String creatorname,
      @JsonKey(name: "title") String title,
      @JsonKey(name: "description") String description,
      @JsonKey(name: "usertype") String usertype,
      @JsonKey(name: "totview") int totview,
      @JsonKey(name: "totreply") int totreply,
      @JsonKey(name: "totlike") int totlike,
      @JsonKey(name: "totdislike") int totdislike,
      @JsonKey(name: "totshare") int totshare,
      @JsonKey(name: "slug") String slug,
      @JsonKey(name: "createdon") DateTime createdon,
      @JsonKey(name: "isactive") int isactive,
      @JsonKey(name: "lastreply") DateTime lastreply,
      @JsonKey(name: "replies") dynamic replies});
}

/// @nodoc
class __$$GetCommentsModelImplCopyWithImpl<$Res>
    extends _$GetCommentsModelCopyWithImpl<$Res, _$GetCommentsModelImpl>
    implements _$$GetCommentsModelImplCopyWith<$Res> {
  __$$GetCommentsModelImplCopyWithImpl(_$GetCommentsModelImpl _value,
      $Res Function(_$GetCommentsModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? creatorid = null,
    Object? creatorname = null,
    Object? title = null,
    Object? description = null,
    Object? usertype = null,
    Object? totview = null,
    Object? totreply = null,
    Object? totlike = null,
    Object? totdislike = null,
    Object? totshare = null,
    Object? slug = null,
    Object? createdon = null,
    Object? isactive = null,
    Object? lastreply = null,
    Object? replies = freezed,
  }) {
    return _then(_$GetCommentsModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      creatorid: null == creatorid
          ? _value.creatorid
          : creatorid // ignore: cast_nullable_to_non_nullable
              as int,
      creatorname: null == creatorname
          ? _value.creatorname
          : creatorname // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      usertype: null == usertype
          ? _value.usertype
          : usertype // ignore: cast_nullable_to_non_nullable
              as String,
      totview: null == totview
          ? _value.totview
          : totview // ignore: cast_nullable_to_non_nullable
              as int,
      totreply: null == totreply
          ? _value.totreply
          : totreply // ignore: cast_nullable_to_non_nullable
              as int,
      totlike: null == totlike
          ? _value.totlike
          : totlike // ignore: cast_nullable_to_non_nullable
              as int,
      totdislike: null == totdislike
          ? _value.totdislike
          : totdislike // ignore: cast_nullable_to_non_nullable
              as int,
      totshare: null == totshare
          ? _value.totshare
          : totshare // ignore: cast_nullable_to_non_nullable
              as int,
      slug: null == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String,
      createdon: null == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isactive: null == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int,
      lastreply: null == lastreply
          ? _value.lastreply
          : lastreply // ignore: cast_nullable_to_non_nullable
              as DateTime,
      replies: freezed == replies
          ? _value.replies
          : replies // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetCommentsModelImpl implements _GetCommentsModel {
  const _$GetCommentsModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "creatorid") required this.creatorid,
      @JsonKey(name: "creatorname") required this.creatorname,
      @JsonKey(name: "title") required this.title,
      @JsonKey(name: "description") required this.description,
      @JsonKey(name: "usertype") required this.usertype,
      @JsonKey(name: "totview") required this.totview,
      @JsonKey(name: "totreply") required this.totreply,
      @JsonKey(name: "totlike") required this.totlike,
      @JsonKey(name: "totdislike") required this.totdislike,
      @JsonKey(name: "totshare") required this.totshare,
      @JsonKey(name: "slug") required this.slug,
      @JsonKey(name: "createdon") required this.createdon,
      @JsonKey(name: "isactive") required this.isactive,
      @JsonKey(name: "lastreply") required this.lastreply,
      @JsonKey(name: "replies") required this.replies});

  factory _$GetCommentsModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetCommentsModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  final int id;
  @override
  @JsonKey(name: "creatorid")
  final int creatorid;
  @override
  @JsonKey(name: "creatorname")
  final String creatorname;
  @override
  @JsonKey(name: "title")
  final String title;
  @override
  @JsonKey(name: "description")
  final String description;
  @override
  @JsonKey(name: "usertype")
  final String usertype;
  @override
  @JsonKey(name: "totview")
  final int totview;
  @override
  @JsonKey(name: "totreply")
  final int totreply;
  @override
  @JsonKey(name: "totlike")
  final int totlike;
  @override
  @JsonKey(name: "totdislike")
  final int totdislike;
  @override
  @JsonKey(name: "totshare")
  final int totshare;
  @override
  @JsonKey(name: "slug")
  final String slug;
  @override
  @JsonKey(name: "createdon")
  final DateTime createdon;
  @override
  @JsonKey(name: "isactive")
  final int isactive;
  @override
  @JsonKey(name: "lastreply")
  final DateTime lastreply;
  @override
  @JsonKey(name: "replies")
  final dynamic replies;

  @override
  String toString() {
    return 'GetCommentsModel(id: $id, creatorid: $creatorid, creatorname: $creatorname, title: $title, description: $description, usertype: $usertype, totview: $totview, totreply: $totreply, totlike: $totlike, totdislike: $totdislike, totshare: $totshare, slug: $slug, createdon: $createdon, isactive: $isactive, lastreply: $lastreply, replies: $replies)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetCommentsModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.creatorid, creatorid) ||
                other.creatorid == creatorid) &&
            (identical(other.creatorname, creatorname) ||
                other.creatorname == creatorname) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.usertype, usertype) ||
                other.usertype == usertype) &&
            (identical(other.totview, totview) || other.totview == totview) &&
            (identical(other.totreply, totreply) ||
                other.totreply == totreply) &&
            (identical(other.totlike, totlike) || other.totlike == totlike) &&
            (identical(other.totdislike, totdislike) ||
                other.totdislike == totdislike) &&
            (identical(other.totshare, totshare) ||
                other.totshare == totshare) &&
            (identical(other.slug, slug) || other.slug == slug) &&
            (identical(other.createdon, createdon) ||
                other.createdon == createdon) &&
            (identical(other.isactive, isactive) ||
                other.isactive == isactive) &&
            (identical(other.lastreply, lastreply) ||
                other.lastreply == lastreply) &&
            const DeepCollectionEquality().equals(other.replies, replies));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      creatorid,
      creatorname,
      title,
      description,
      usertype,
      totview,
      totreply,
      totlike,
      totdislike,
      totshare,
      slug,
      createdon,
      isactive,
      lastreply,
      const DeepCollectionEquality().hash(replies));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetCommentsModelImplCopyWith<_$GetCommentsModelImpl> get copyWith =>
      __$$GetCommentsModelImplCopyWithImpl<_$GetCommentsModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetCommentsModelImplToJson(
      this,
    );
  }
}

abstract class _GetCommentsModel implements GetCommentsModel {
  const factory _GetCommentsModel(
          {@JsonKey(name: "id") required final int id,
          @JsonKey(name: "creatorid") required final int creatorid,
          @JsonKey(name: "creatorname") required final String creatorname,
          @JsonKey(name: "title") required final String title,
          @JsonKey(name: "description") required final String description,
          @JsonKey(name: "usertype") required final String usertype,
          @JsonKey(name: "totview") required final int totview,
          @JsonKey(name: "totreply") required final int totreply,
          @JsonKey(name: "totlike") required final int totlike,
          @JsonKey(name: "totdislike") required final int totdislike,
          @JsonKey(name: "totshare") required final int totshare,
          @JsonKey(name: "slug") required final String slug,
          @JsonKey(name: "createdon") required final DateTime createdon,
          @JsonKey(name: "isactive") required final int isactive,
          @JsonKey(name: "lastreply") required final DateTime lastreply,
          @JsonKey(name: "replies") required final dynamic replies}) =
      _$GetCommentsModelImpl;

  factory _GetCommentsModel.fromJson(Map<String, dynamic> json) =
      _$GetCommentsModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int get id;
  @override
  @JsonKey(name: "creatorid")
  int get creatorid;
  @override
  @JsonKey(name: "creatorname")
  String get creatorname;
  @override
  @JsonKey(name: "title")
  String get title;
  @override
  @JsonKey(name: "description")
  String get description;
  @override
  @JsonKey(name: "usertype")
  String get usertype;
  @override
  @JsonKey(name: "totview")
  int get totview;
  @override
  @JsonKey(name: "totreply")
  int get totreply;
  @override
  @JsonKey(name: "totlike")
  int get totlike;
  @override
  @JsonKey(name: "totdislike")
  int get totdislike;
  @override
  @JsonKey(name: "totshare")
  int get totshare;
  @override
  @JsonKey(name: "slug")
  String get slug;
  @override
  @JsonKey(name: "createdon")
  DateTime get createdon;
  @override
  @JsonKey(name: "isactive")
  int get isactive;
  @override
  @JsonKey(name: "lastreply")
  DateTime get lastreply;
  @override
  @JsonKey(name: "replies")
  dynamic get replies;
  @override
  @JsonKey(ignore: true)
  _$$GetCommentsModelImplCopyWith<_$GetCommentsModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
