// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_comments_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetCommentsModelImpl _$$GetCommentsModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetCommentsModelImpl(
      id: json['id'] as int,
      creatorid: json['creatorid'] as int,
      creatorname: json['creatorname'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      usertype: json['usertype'] as String,
      totview: json['totview'] as int,
      totreply: json['totreply'] as int,
      totlike: json['totlike'] as int,
      totdislike: json['totdislike'] as int,
      totshare: json['totshare'] as int,
      slug: json['slug'] as String,
      createdon: DateTime.parse(json['createdon'] as String),
      isactive: json['isactive'] as int,
      lastreply: DateTime.parse(json['lastreply'] as String),
      replies: json['replies'],
    );

Map<String, dynamic> _$$GetCommentsModelImplToJson(
        _$GetCommentsModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'creatorid': instance.creatorid,
      'creatorname': instance.creatorname,
      'title': instance.title,
      'description': instance.description,
      'usertype': instance.usertype,
      'totview': instance.totview,
      'totreply': instance.totreply,
      'totlike': instance.totlike,
      'totdislike': instance.totdislike,
      'totshare': instance.totshare,
      'slug': instance.slug,
      'createdon': instance.createdon.toIso8601String(),
      'isactive': instance.isactive,
      'lastreply': instance.lastreply.toIso8601String(),
      'replies': instance.replies,
    };
