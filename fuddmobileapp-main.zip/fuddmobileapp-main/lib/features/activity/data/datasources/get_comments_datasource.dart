import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/activity/data/models/get_comments_model.dart';

abstract class GetCommentsRemoteDatasource {
  Future<List<GetCommentsModel>> getcommentsList();
}

@LazySingleton(as: GetCommentsRemoteDatasource)
class GetCommentsRemoteDatasourceImpl implements GetCommentsRemoteDatasource {
  final Client client;
  GetCommentsRemoteDatasourceImpl({required this.client});

  @override
  Future<List<GetCommentsModel>> getcommentsList() async {
    print('getcomments api called ${Apis.getComments}');
    try {
      final response = await client.get(
        Uri.parse(Apis.getComments),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myGetCommentsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        final user = getCommentsModelFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
