import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/data/datasources/get_comments_datasource.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

@LazySingleton(as: GetCommentsRepository)
class GetCommentsRepoImpl implements GetCommentsRepository {
  final GetCommentsRemoteDatasource sigInRemoteDatasource;

  GetCommentsRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, List<GetCommentsEntity>>> getGetComments() async {
    try {
      final result = await sigInRemoteDatasource.getcommentsList();
      return right(result
          .map((e) => GetCommentsEntity(
              id: e.id,
              creatorid: e.creatorid,
              creatorname: e.creatorname,
              title: e.title,
              description: e.description,
              usertype: e.usertype,
              totview: e.totview,
              totreply: e.totreply,
              totlike: e.totlike,
              totdislike: e.totdislike,
              totshare: e.totshare,
              slug: e.slug,
              createdon: e.createdon,
              isactive: e.isactive,
              lastreply: e.lastreply,
              replies: e.replies))
          .toList());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
