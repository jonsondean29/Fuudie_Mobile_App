// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:fuud/core/utls/location/bloc/location_bloc.dart';
import 'package:fuud/core/widgets/appbar.dart';

import '../../../explore/presentation/widgets/search_widget.dart';

@RoutePage()
class MapPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final bool isRouteView;
  final String? lat, lng;

  MapPage(
      {Key? key,
      required this.isRouteView,
      required this.lng,
      required this.lat})
      : super(key: key);
  static const routeName = 'map';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        appBar: customAppBar(title: '', scaffoldKey: _scaffoldKey),
        // endDrawer: const AppDrawer(),
        body: BlocBuilder<LocationBloc, LocationState>(
          builder: (context, state) {
            return Mapview(
              userLocation: LatLng(state.latitude, state.longitude),
            );
          },
        ));
  }
}

class Mapview extends StatelessWidget {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  final LatLng userLocation;
  final List<LatLng> locations = [
    const LatLng(9.5034208, 76.3156372),
    const LatLng(9.5036440, 76.3154923),
    const LatLng(9.5041651, 76.3157029),
    const LatLng(9.5045788, 76.3153411),
  ];
  Mapview({
    Key? key,
    required this.userLocation,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder<BitmapDescriptor>(
          future: getDiamondMarker(),
          builder: (context, diamond) {
            return FutureBuilder<BitmapDescriptor>(
              future: getBlackMarker(),
              builder: (context, black) {
                if (black.connectionState == ConnectionState.done &&
                    black.data != null) {
                  return Stack(
                    children: [
                      GoogleMap(
                        markers: {
                          Marker(
                            markerId: const MarkerId("marker1"),
                            position: userLocation,
                            icon: diamond.data!,
                          ),
                          Marker(
                            markerId: const MarkerId("marker2"),
                            position: locations[0],
                            icon: black.data!,
                          ),
                          Marker(
                            markerId: const MarkerId("marker3"),
                            position: locations[1],
                            icon: diamond.data!,
                          ),
                          Marker(
                            markerId: const MarkerId("marker4"),
                            position: locations[2],
                            icon: diamond.data!,
                          ),
                          Marker(
                            markerId: const MarkerId("marker5"),
                            position: locations[3],
                            icon: black.data!,
                          ),
                        },
                        mapType: MapType.terrain,
                        initialCameraPosition: CameraPosition(
                          target: userLocation,
                          zoom: 12.4746,
                        ),
                        onMapCreated: (
                          GoogleMapController controller,
                        ) async {
                          _controller.complete(controller);

                          await controller.animateCamera(
                              CameraUpdate.newCameraPosition(CameraPosition(
                                  target: userLocation, zoom: 16.5)));
                        },
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 10, right: 10, top: 20),
                        child: SearchWidget(
                          hintText: 'search for a place, area',
                          searchController: TextEditingController(),
                        ),
                      )
                    ],
                  );
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            );
          },
        ),
      ),
    );
  }

  Future<BitmapDescriptor> getDiamondMarker() async {
    return BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(5, 5)), // Adjust size as needed
      'assets/images/icon-main.png',
    );
  }

  Future<BitmapDescriptor> getBlackMarker() async {
    return BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(), // Adjust size as needed
      'assets/images/black.png',
    );
  }
}
