part of 'map_bloc.dart';

@freezed
class MapState with _$MapState {
  factory MapState(
      {required bool isLoading, required LatLng? currentLocation}) = _MapState;
  factory MapState.initial() =>
      MapState(isLoading: false, currentLocation: null);
}
