import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:fuud/core/validations/validator.dart';

class ChangePassword extends StatelessWidget {
  ChangePassword({super.key});
  final emailController = TextEditingController();
  final oldPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      surfaceTintColor: Colors.white,
      backgroundColor: Colors.white,
      insetPadding: const EdgeInsets.all(5),
      content: SizedBox(
        height: 350,
        width: MediaQuery.of(context).size.width,
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Change Password',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.cancel_outlined,
                      size: 35,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              InputField(
                  hintText: 'Email',
                  validator: (value) {
                    if (value != null) {
                      return validateEmail(value);
                    }
                    return null;
                  },
                  controller: emailController,
                  readOnly: false,
                  keyboardType: TextInputType.emailAddress),
              const SizedBox(
                height: 10,
              ),
              InputField(
                  hintText: 'Old Password',
                  validator: (value) {
                    if (value != null) {
                      return validateString(
                          value: value, fieldName: 'Old Password');
                    }
                    return null;
                  },
                  controller: oldPasswordController,
                  readOnly: false,
                  keyboardType: TextInputType.text),
              const SizedBox(
                height: 10,
              ),
              InputField(
                  hintText: 'New Password',
                  validator: (value) {
                    if (value != null) {
                      return validateString(
                          value: value, fieldName: 'New Password');
                    }
                    return null;
                  },
                  controller: newPasswordController,
                  readOnly: false,
                  keyboardType: TextInputType.text),
              const Gap(10),

              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      if (_formKey.currentState!.validate()) {
                        // BlocProvider.of<UserAccountBloc>(context).add(
                        //     OnPasswordChange(
                        //         context: context,
                        //         updatePasswordParams: UpdatePasswordParams(
                        //             email: emailController.text.trim(),
                        //             odlPassword:
                        //                 oldPasswordController.text.trim(),
                        //             newPassword:
                        //                 newPasswordController.text.trim())));
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.black),
                      height: 40,
                      width: 150,
                      child: const Center(
                        child: Text(
                          'Submit',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              // ElevatedButton(onPressed: () {}, child: const Text('Submit'))
            ],
          ),
        ),
      ),
    );
  }
}
