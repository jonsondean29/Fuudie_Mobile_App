import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';

@RoutePage()
class AccountPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  AccountPage({super.key});
  static const routeName = 'account';
  final searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      body: SingleChildScrollView(
          child: Container(
        // margin: const EdgeInsets.all(15),
        child: Column(
          children: [
            const Gap(10),
            Container(
              margin: const EdgeInsets.all(15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      const CircleAvatar(
                        radius: 35,
                      ),
                      const Gap(10),
                      Container(
                        height: 30,
                        width: 90,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black, width: 0.3),
                            borderRadius: BorderRadius.circular(3),
                            color: Colors.grey.withOpacity(0.2)),
                        child: const Center(
                          child: Text(
                            'Edit Profile',
                            style: TextStyle(fontSize: 10),
                          ),
                        ),
                      )
                    ],
                  ),
                  Image.asset(
                    'assets/images/icons.png',
                    height: 120,
                  )
                ],
              ),
            ),
            Container(
              height: 80,
              decoration: const BoxDecoration(color: Colors.black),
              child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: InputField(
                      hintText: "Search for place area,list or tag",
                      filled: true,
                      suffixIcon: const Icon(Icons.search),
                      fillColour: Colors.white,
                      controller: searchController)),
            ),
            Container(
              margin: const EdgeInsets.all(15),
              child: Column(
                children: [
                  Image.asset('assets/images/new.png'),
                ],
              ),
            )
            //
          ],
        ),
      )),
    );
  }
}
