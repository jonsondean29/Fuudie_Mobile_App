// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i1;
import 'package:http/http.dart' as _i3;
import 'package:injectable/injectable.dart' as _i2;

import '../core/utls/location/bloc/location_bloc.dart' as _i10;
import '../core/utls/network/bloc/network_bloc.dart' as _i12;
import 'activity/data/datasources/get_comments_datasource.dart' as _i6;
import 'activity/data/repositories/get_comments_repositoryimpl.dart' as _i8;
import 'activity/domain/repositories/get_comment_repository.dart' as _i7;
import 'activity/domain/usecases/get_comments_usecase.dart' as _i9;
import 'activity/presentation/bloc/activity_bloc.dart' as _i32;
import 'auth/data/datasources/signin_datasource.dart' as _i23;
import 'auth/data/datasources/signup_datasource.dart' as _i22;
import 'auth/data/repositories/signin_repository.dart' as _i25;
import 'auth/data/repositories/signup_repository.dart' as _i28;
import 'auth/domain/repositories/sign_in_repositories.dart' as _i24;
import 'auth/domain/repositories/sign_up_repository.dart' as _i27;
import 'auth/domain/usecases/sign_in_usecase.dart' as _i26;
import 'auth/domain/usecases/sign_up_usecase.dart' as _i29;
import 'auth/presentation/bloc/auth_bloc.dart' as _i38;
import 'home/data/datasources/ads_datasource.dart' as _i33;
import 'home/data/datasources/all_tag_resturents_datasource.dart' as _i37;
import 'home/data/datasources/curent_year_resturent_list_datasource.dart'
    as _i4;
import 'home/data/datasources/exclusive_resturents_list_datasource.dart' as _i5;
import 'home/data/datasources/new_opening_resturent_datasource.dart' as _i13;
import 'home/data/datasources/restaurant_details_datasource.dart' as _i17;
import 'home/data/datasources/resturent_with_perks_datasource.dart' as _i21;
import 'home/data/datasources/top_10_resturents_datasource.dart' as _i31;
import 'home/data/repositories/ads_repository_impl.dart' as _i35;
import 'home/data/repositories/all_tags_resturent_list.dart' as _i52;
import 'home/data/repositories/current_year_resturent_repositoryimpl.dart'
    as _i40;
import 'home/data/repositories/exclusive_resturent_list.dart' as _i43;
import 'home/data/repositories/new_opening_resturent_repositoryimpl.dart'
    as _i15;
import 'home/data/repositories/restaurant_details_repositoryimpl.dart' as _i19;
import 'home/data/repositories/resturent_with_perks_repositoryimpl.dart'
    as _i46;
import 'home/data/repositories/top_10_repository_impl.dart' as _i49;
import 'home/domain/repositories/ads_repository.dart' as _i34;
import 'home/domain/repositories/all_tags_restaurent_repository.dart' as _i51;
import 'home/domain/repositories/current_year_resturent_repository.dart'
    as _i39;
import 'home/domain/repositories/exclusive_resturent_repository.dart' as _i42;
import 'home/domain/repositories/new_restaurent_repository.dart' as _i14;
import 'home/domain/repositories/perks_resturent_repository.dart' as _i45;
import 'home/domain/repositories/restaurant_details_entity.dart' as _i18;
import 'home/domain/repositories/top_10_resurents_repository.dart' as _i48;
import 'home/domain/usecases/ads_usecase.dart' as _i36;
import 'home/domain/usecases/all_tag_restaurent_usecase.dart' as _i53;
import 'home/domain/usecases/current_year_resturents_usecase.dart' as _i41;
import 'home/domain/usecases/exclusive_resturent_usecase.dart' as _i44;
import 'home/domain/usecases/new_opening_restaurent_usecase.dart' as _i16;
import 'home/domain/usecases/perks_resturent_usecase.dart' as _i47;
import 'home/domain/usecases/resturant_details_usecase.dart' as _i20;
import 'home/domain/usecases/top_10_resturents_usecase.dart' as _i50;
import 'home/presentation/bloc/home_bloc.dart' as _i54;
import 'injectable.dart' as _i55;
import 'map/presentation/bloc/map_bloc.dart' as _i11;
import 'splash/presentation/bloc/splash_bloc.dart' as _i30;

extension GetItInjectableX on _i1.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i1.GetIt init({
    String? environment,
    _i2.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i2.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    final injectableModule = _$InjectableModule();
    gh.singleton<_i3.Client>(injectableModule.httpClient);
    gh.lazySingleton<_i4.CurrentYearResturentRemoteDatasource>(() =>
        _i4.CurrentYearResturentRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i5.ExclusiveResturentRemoteDatasource>(() =>
        _i5.ExclusiveResturentRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i6.GetCommentsRemoteDatasource>(
        () => _i6.GetCommentsRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i7.GetCommentsRepository>(() => _i8.GetCommentsRepoImpl(
        sigInRemoteDatasource: gh<_i6.GetCommentsRemoteDatasource>()));
    gh.lazySingleton<_i9.GetCommentsUsecase>(() => _i9.GetCommentsUsecase(
        getcommentsRepository: gh<_i7.GetCommentsRepository>()));
    gh.factory<_i10.LocationBloc>(() => _i10.LocationBloc());
    gh.factory<_i11.MapBloc>(() => _i11.MapBloc());
    gh.factory<_i12.NetworkBloc>(() => _i12.NetworkBloc());
    gh.lazySingleton<_i13.NewOpeningResturentRemoteDatasource>(() =>
        _i13.NewOpeningResturentRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i14.NewRestaurantRepository>(() =>
        _i15.NewOpeningResturentRepoImpl(
            newOpeningResturentRemoteDatasource:
                gh<_i13.NewOpeningResturentRemoteDatasource>()));
    gh.lazySingleton<_i16.NewRestaurantUsecase>(() => _i16.NewRestaurantUsecase(
        newRestaurantRepository: gh<_i14.NewRestaurantRepository>()));
    gh.lazySingleton<_i17.RestaurantDetailsRemoteDatasource>(() =>
        _i17.RestaurantDetailsRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i18.RestaurantDetailsRepository>(() =>
        _i19.RestaurantDetailsRepoImpl(
            sigInRemoteDatasource:
                gh<_i17.RestaurantDetailsRemoteDatasource>()));
    gh.lazySingleton<_i20.RestaurantDetailsUsecase>(() =>
        _i20.RestaurantDetailsUsecase(
            restaurantDetailsRepository:
                gh<_i18.RestaurantDetailsRepository>()));
    gh.lazySingleton<_i21.ResturentWithPerksRemoteDatasource>(() =>
        _i21.ResturentWithPerksRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i22.SigUpRemoteDatasource>(
        () => _i22.SigUpRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i23.SignInRemoteDatasource>(
        () => _i23.SignInRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i24.SignInRepository>(() => _i25.SignInRepoImpl(
        sigInRemoteDatasource: gh<_i23.SignInRemoteDatasource>()));
    gh.lazySingleton<_i26.SignInUsecase>(() =>
        _i26.SignInUsecase(signInRepository: gh<_i24.SignInRepository>()));
    gh.lazySingleton<_i27.SignUpRepository>(() => _i28.SignUpRepoImpl(
        sigUpRemoteDatasource: gh<_i22.SigUpRemoteDatasource>()));
    gh.lazySingleton<_i29.SignUpUsecase>(() =>
        _i29.SignUpUsecase(signUpRepository: gh<_i27.SignUpRepository>()));
    gh.factory<_i30.SplashBloc>(() => _i30.SplashBloc());
    gh.lazySingleton<_i31.TopTenResturentRemoteDatasource>(() =>
        _i31.TopTenResturentRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.factory<_i32.ActivityBloc>(() =>
        _i32.ActivityBloc(getCommentsUsecase: gh<_i9.GetCommentsUsecase>()));
    gh.lazySingleton<_i33.AdsRemoteDatasource>(
        () => _i33.AdsRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.lazySingleton<_i34.AdsRepository>(() => _i35.AdsRepoImpl(
        sigInRemoteDatasource: gh<_i33.AdsRemoteDatasource>()));
    gh.lazySingleton<_i36.AdsUsecase>(
        () => _i36.AdsUsecase(adsRepository: gh<_i34.AdsRepository>()));
    gh.lazySingleton<_i37.AllTagsResturentRemoteDatasource>(() =>
        _i37.AllTagsResturentRemoteDatasourceImpl(client: gh<_i3.Client>()));
    gh.factory<_i38.AuthBloc>(() => _i38.AuthBloc(
          signInUsecase: gh<_i26.SignInUsecase>(),
          signUpUsecase: gh<_i29.SignUpUsecase>(),
        ));
    gh.lazySingleton<_i39.CurrentYearRestaurantRepository>(() =>
        _i40.CurentyearResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i4.CurrentYearResturentRemoteDatasource>()));
    gh.lazySingleton<_i41.CurrentYearRestaurantUsecase>(() =>
        _i41.CurrentYearRestaurantUsecase(
            currentYearRestaurantRepository:
                gh<_i39.CurrentYearRestaurantRepository>()));
    gh.lazySingleton<_i42.ExclusiveRestaurantRepository>(() =>
        _i43.ExclusiveResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i5.ExclusiveResturentRemoteDatasource>()));
    gh.lazySingleton<_i44.ExclusiveRestaurantUsecase>(() =>
        _i44.ExclusiveRestaurantUsecase(
            exclusiveRestaurantRepository:
                gh<_i42.ExclusiveRestaurantRepository>()));
    gh.lazySingleton<_i45.PerksRestaurantRepository>(() =>
        _i46.ResturentWithPerksRepoImpl(
            resturentWithPerksRemoteDatasource:
                gh<_i21.ResturentWithPerksRemoteDatasource>()));
    gh.lazySingleton<_i47.PerksRestaurantUsecase>(() =>
        _i47.PerksRestaurantUsecase(
            perksRestaurantRepository: gh<_i45.PerksRestaurantRepository>()));
    gh.lazySingleton<_i48.TopTenRestaurantRepository>(() =>
        _i49.TopTenOpeningResturentRepoImpl(
            toptenOpeningResturentRemoteDatasource:
                gh<_i31.TopTenResturentRemoteDatasource>()));
    gh.lazySingleton<_i50.TopTenRestaurantUsecase>(() =>
        _i50.TopTenRestaurantUsecase(
            toptenRestaurantRepository: gh<_i48.TopTenRestaurantRepository>()));
    gh.lazySingleton<_i51.AllTagsRestaurantRepository>(() =>
        _i52.AllTagsResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i37.AllTagsResturentRemoteDatasource>()));
    gh.lazySingleton<_i53.AllTagsRestaurantUsecase>(() =>
        _i53.AllTagsRestaurantUsecase(
            allTagsRestaurantRepository:
                gh<_i51.AllTagsRestaurantRepository>()));
    gh.factory<_i54.HomeBloc>(() => _i54.HomeBloc(
          restaurantDetailsUsecase: gh<_i20.RestaurantDetailsUsecase>(),
          newRestaurantUsecase: gh<_i16.NewRestaurantUsecase>(),
          allTagsRestaurantUsecase: gh<_i53.AllTagsRestaurantUsecase>(),
          currentYearRestaurantUsecase: gh<_i41.CurrentYearRestaurantUsecase>(),
          exclusiveRestaurantUsecase: gh<_i44.ExclusiveRestaurantUsecase>(),
          perksRestaurantUsecase: gh<_i47.PerksRestaurantUsecase>(),
          tenRestaurantUsecase: gh<_i50.TopTenRestaurantUsecase>(),
          adsUsecase: gh<_i36.AdsUsecase>(),
        ));
    return this;
  }
}

class _$InjectableModule extends _i55.InjectableModule {}
