import 'package:gap/gap.dart';
import 'package:flutter/material.dart';

class ListWidget extends StatelessWidget {
  const ListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Gap(10),
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Chip(
              label: Text('Top'),
            ),
            Chip(
              label: Text('Cuisines'),
            ),
            Chip(
              label: Text('Occasions'),
            ),
            Chip(
              label: Text('Vibes'),
            ),
          ],
        ),
        Expanded(
          child: ListView.builder(
            itemCount: 10,
            itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading: const Icon(Icons.image),
                title: Text('category ${index + 1}'),
                subtitle: Text("${5 * index + 1} places"),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
