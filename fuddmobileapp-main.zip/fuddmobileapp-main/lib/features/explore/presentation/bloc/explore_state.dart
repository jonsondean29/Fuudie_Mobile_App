part of 'explore_bloc.dart';

abstract class ExploreState extends Equatable {
  const ExploreState();  

  @override
  List<Object> get props => [];
}
class ExploreInitial extends ExploreState {}
