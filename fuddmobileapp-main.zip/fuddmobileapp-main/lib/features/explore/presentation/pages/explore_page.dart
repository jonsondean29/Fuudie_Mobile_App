import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/features/explore/presentation/widgets/tab_screen.dart';
import 'package:fuud/features/explore/presentation/widgets/search_widget.dart';

@RoutePage()
class ExplorePage extends StatelessWidget {
  final searchControoler = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  ExplorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: customAppBar(
          title: 'Explore', scaffoldKey: _scaffoldKey, locationImage: true),
      endDrawer: const AppDrawer(),
      body: Container(
        margin: const EdgeInsets.all(5),
        child: Column(
          children: [
            SearchWidget(searchController: searchControoler),
            const Gap(10),
            const Expanded(child: TabViewWidget())
          ],
        ),
      ),
    );
  }
}
