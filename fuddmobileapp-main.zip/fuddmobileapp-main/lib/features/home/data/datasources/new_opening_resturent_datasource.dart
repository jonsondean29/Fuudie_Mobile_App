import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/new_opening_resturent_list.dart';
import 'package:fuud/features/home/domain/usecases/new_opening_restaurent_usecase.dart';

abstract class NewOpeningResturentRemoteDatasource {
  Future<List<NewOpeningrestrolist>> newOpeningResturentUser(
      NewRestaurantParams params);
}

@LazySingleton(as: NewOpeningResturentRemoteDatasource)
class NewOpeningResturentRemoteDatasourceImpl
    implements NewOpeningResturentRemoteDatasource {
  final Client client;
  NewOpeningResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<NewOpeningrestrolist>> newOpeningResturentUser(
      NewRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse(
            "${Apis.getnewopeningrestrolist}/${params.userId}/${params.count}"),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        log('newResturent ${response.statusCode}, : ${response.body} ');

        final user = newopeningrestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
