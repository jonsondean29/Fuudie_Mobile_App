import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/all_tags_resturant_list.dart';
import 'package:fuud/features/home/domain/usecases/all_tag_restaurent_usecase.dart';

abstract class AllTagsResturentRemoteDatasource {
  Future<List<Alltagsrestrolist>> allTagsResturentUser(
      AllTagsRestaurantParams params);
}

@LazySingleton(as: AllTagsResturentRemoteDatasource)
class AllTagsResturentRemoteDatasourceImpl
    implements AllTagsResturentRemoteDatasource {
  final Client client;
  AllTagsResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<Alltagsrestrolist>> allTagsResturentUser(
      AllTagsRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse(
            "${Apis.getAlltagsrestrolist}/${params.userId}/${params.count}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        final user = getAlltagsrestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
