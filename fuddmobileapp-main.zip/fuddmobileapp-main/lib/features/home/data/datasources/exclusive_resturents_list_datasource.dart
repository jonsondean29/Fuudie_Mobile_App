import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/exclusive_resturant_list.dart';
import 'package:fuud/features/home/domain/usecases/exclusive_resturent_usecase.dart';

abstract class ExclusiveResturentRemoteDatasource {
  Future<List<Exclusiverestrolist>> exclusiveResturentUser(
      ExclusiveRestaurantParams params);
}

@LazySingleton(as: ExclusiveResturentRemoteDatasource)
class ExclusiveResturentRemoteDatasourceImpl
    implements ExclusiveResturentRemoteDatasource {
  final Client client;
  ExclusiveResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<Exclusiverestrolist>> exclusiveResturentUser(
      ExclusiveRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse(
            "${Apis.getexclusiverestrolist}/${params.userId}/${params.count}"),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        log('myResponce ${response.statusCode}, : ${response.body} ');

        final user = exclusiverestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
