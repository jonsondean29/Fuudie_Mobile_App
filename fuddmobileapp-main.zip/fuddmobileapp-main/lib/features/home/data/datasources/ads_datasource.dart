import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/ads_model.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';

abstract class AdsRemoteDatasource {
  Future<List<AdsModel>> adsList(AdsParams params);
}

@LazySingleton(as: AdsRemoteDatasource)
class AdsRemoteDatasourceImpl implements AdsRemoteDatasource {
  final Client client;
  AdsRemoteDatasourceImpl({required this.client});

  @override
  Future<List<AdsModel>> adsList(AdsParams params) async {
    print('ads api called');
    try {
      final response = await client.get(
        Uri.parse("${Apis.getAds}/${params.adsposition}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myAdsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        final user = adsModelFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
