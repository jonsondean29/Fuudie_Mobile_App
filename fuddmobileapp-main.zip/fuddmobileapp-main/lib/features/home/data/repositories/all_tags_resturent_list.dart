import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/datasources/all_tag_resturents_datasource.dart';
import 'package:fuud/features/home/domain/entities/all_tags_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/all_tags_restaurent_repository.dart';

@LazySingleton(as: AllTagsRestaurantRepository)
class AllTagsResturentRepoImpl implements AllTagsRestaurantRepository {
  final AllTagsResturentRemoteDatasource sigInRemoteDatasource;

  AllTagsResturentRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, List<AllTagsrestrolistEntity>>> getAllTagsRestaurant(
      params) async {
    try {
      final result = await sigInRemoteDatasource.allTagsResturentUser(params);
      return right(result
          .map((e) =>
              AllTagsrestrolistEntity(restrolist: e.restrolist, tag: e.tag))
          .toList());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
