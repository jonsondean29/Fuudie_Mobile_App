import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/restaurant_details_entity.dart';
import 'package:fuud/features/home/domain/repositories/restaurant_details_entity.dart';
import 'package:fuud/features/home/data/datasources/restaurant_details_datasource.dart';

@LazySingleton(as: RestaurantDetailsRepository)
class RestaurantDetailsRepoImpl implements RestaurantDetailsRepository {
  final RestaurantDetailsRemoteDatasource sigInRemoteDatasource;

  RestaurantDetailsRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, RestaurantDetailsEntity>> getRestaurantdetails(
      params) async {
    try {
      final result = await sigInRemoteDatasource.restaurantDetailsUser(params);
      return right(RestaurantDetailsEntity(
          id: result.id,
          name: result.name,
          addedBy: result.addedBy,
          categoryid: result.categoryid,
          categoryname: result.categoryname,
          tags: result.tags,
          shortdescription: result.shortdescription,
          description: result.description,
          location: result.location,
          city: result.city,
          state: result.state,
          docuntry: result.docuntry,
          totfav: result.totfav,
          totbeen: result.totbeen,
          tottry: result.tottry,
          pincode: result.pincode,
          phone: result.phone,
          lat: result.lat,
          lng: result.lng,
          fblink: result.fblink,
          instalink: result.instalink,
          rating: result.rating,
          totreviews: result.totreviews,
          barcode: result.barcode,
          slug: result.slug,
          createdon: result.createdon,
          updatedon: result.updatedon,
          isactive: result.isactive,
          isperks: result.isperks,
          isexclusive: result.isexclusive,
          iswishlist: result.iswishlist,
          isbeenlist: result.isbeenlist,
          istrylist: result.istrylist,
          restroreviewlst: result.restroreviewlst,
          restrimglist: result.restrimglist));
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
