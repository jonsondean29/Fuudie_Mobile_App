import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/exclusive_resturent_repository.dart';
import 'package:fuud/features/home/data/datasources/exclusive_resturents_list_datasource.dart';

@LazySingleton(as: ExclusiveRestaurantRepository)
class ExclusiveResturentRepoImpl implements ExclusiveRestaurantRepository {
  final ExclusiveResturentRemoteDatasource sigInRemoteDatasource;

  ExclusiveResturentRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, List<ExclusiveResturantListEntity>>>
      getExclusiveRestaurant(params) async {
    try {
      final result = await sigInRemoteDatasource.exclusiveResturentUser(params);
      return right(result
          .map((e) => ExclusiveResturantListEntity(
              id: e.id,
              name: e.name,
              addedBy: e.addedBy,
              categoryid: e.categoryid,
              categoryname: e.categoryname,
              tags: e.tags,
              shortdescription: e.shortdescription,
              description: e.description,
              location: e.location,
              city: e.city,
              state: e.state,
              docuntry: e.docuntry,
              totfav: e.totfav,
              totbeen: e.totbeen,
              tottry: e.tottry,
              pincode: e.pincode,
              phone: e.phone,
              lat: e.lat,
              lng: e.lng,
              fblink: e.fblink,
              instalink: e.instalink,
              rating: e.rating,
              totreviews: e.totreviews,
              barcode: e.barcode,
              slug: e.slug,
              createdon: e.createdon,
              updatedon: e.updatedon,
              isactive: e.isactive,
              isperks: e.isperks,
              isexclusive: e.isexclusive,
              iswishlist: e.iswishlist,
              isbeenlist: e.isbeenlist,
              istrylist: e.istrylist,
              mainimg: e.mainimg,
              restrimglist: e.restrimglist,
              restroreviewlst: e.restroreviewlst))
          .toList());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
