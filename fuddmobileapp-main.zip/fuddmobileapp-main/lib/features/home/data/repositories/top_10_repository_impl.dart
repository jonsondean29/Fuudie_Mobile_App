import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/top_10_resturents_entity.dart';
import 'package:fuud/features/home/data/datasources/top_10_resturents_datasource.dart';
import 'package:fuud/features/home/domain/repositories/top_10_resurents_repository.dart';

@LazySingleton(as: TopTenRestaurantRepository)
class TopTenOpeningResturentRepoImpl implements TopTenRestaurantRepository {
  final TopTenResturentRemoteDatasource toptenOpeningResturentRemoteDatasource;

  TopTenOpeningResturentRepoImpl(
      {required this.toptenOpeningResturentRemoteDatasource});

  @override
  Future<Either<Failure, List<TopTenResturentEntity>>> getTopTenRestaurant(
      params) async {
    try {
      final result = await toptenOpeningResturentRemoteDatasource
          .topTenResturentUser(params);
      return right(result
          .map((e) => TopTenResturentEntity(
              id: e.id,
              name: e.name,
              addedBy: e.addedBy,
              categoryid: e.categoryid,
              categoryname: e.categoryname,
              tags: e.tags,
              shortdescription: e.shortdescription,
              description: e.description,
              location: e.location,
              city: e.city,
              state: e.state,
              docuntry: e.docuntry,
              totfav: e.totfav,
              totbeen: e.totbeen,
              tottry: e.tottry,
              pincode: e.pincode,
              phone: e.phone,
              lat: e.lat,
              lng: e.lng,
              fblink: e.fblink,
              instalink: e.instalink,
              rating: e.rating,
              totreviews: e.totreviews,
              barcode: e.barcode,
              slug: e.slug,
              createdon: e.createdon,
              updatedon: e.updatedon,
              isactive: e.isactive,
              isperks: e.isperks,
              iswishlist: e.iswishlist,
              isbeenlist: e.isbeenlist,
              istrylist: e.istrylist,
              mainimg: e.mainimg,
              restrimglist: e.restrimglist,
              restroreviewlst: e.restroreviewlst,
              isexclusive: e.isexclusive))
          .toList());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
