// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'restaurant_details_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RestaurantDetailsResponseImpl _$$RestaurantDetailsResponseImplFromJson(
        Map<String, dynamic> json) =>
    _$RestaurantDetailsResponseImpl(
      id: json['id'] as int?,
      name: json['name'] as String?,
      addedBy: json['added_by'] as int?,
      categoryid: json['categoryid'] as String?,
      categoryname: json['categoryname'] as String?,
      tags: json['tags'] as String?,
      shortdescription: json['shortdescription'] as String?,
      description: json['description'] as String?,
      location: json['location'] as String?,
      city: json['city'] as String?,
      state: json['state'] as String?,
      docuntry: json['docuntry'],
      totfav: json['totfav'] as int?,
      totbeen: json['totbeen'] as int?,
      tottry: json['tottry'] as int?,
      pincode: json['pincode'] as String?,
      phone: json['phone'],
      lat: json['lat'] as String?,
      lng: json['lng'] as String?,
      fblink: json['fblink'],
      instalink: json['instalink'] as String?,
      rating: (json['rating'] as num?)?.toDouble(),
      totreviews: json['totreviews'] as int?,
      barcode: json['barcode'],
      slug: json['slug'] as String?,
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
      updatedon: json['updatedon'],
      isactive: json['isactive'] as int?,
      isperks: json['isperks'] as int?,
      isexclusive: json['isexclusive'] as int?,
      iswishlist: json['iswishlist'] as int?,
      isbeenlist: json['isbeenlist'] as int?,
      istrylist: json['istrylist'] as int?,
      restrimglist: (json['restrimglist'] as List<dynamic>?)
          ?.map((e) => Restrimglist.fromJson(e as Map<String, dynamic>))
          .toList(),
      restroreviewlst: json['restroreviewlst'] as List<dynamic>?,
    );

Map<String, dynamic> _$$RestaurantDetailsResponseImplToJson(
        _$RestaurantDetailsResponseImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'added_by': instance.addedBy,
      'categoryid': instance.categoryid,
      'categoryname': instance.categoryname,
      'tags': instance.tags,
      'shortdescription': instance.shortdescription,
      'description': instance.description,
      'location': instance.location,
      'city': instance.city,
      'state': instance.state,
      'docuntry': instance.docuntry,
      'totfav': instance.totfav,
      'totbeen': instance.totbeen,
      'tottry': instance.tottry,
      'pincode': instance.pincode,
      'phone': instance.phone,
      'lat': instance.lat,
      'lng': instance.lng,
      'fblink': instance.fblink,
      'instalink': instance.instalink,
      'rating': instance.rating,
      'totreviews': instance.totreviews,
      'barcode': instance.barcode,
      'slug': instance.slug,
      'createdon': instance.createdon?.toIso8601String(),
      'updatedon': instance.updatedon,
      'isactive': instance.isactive,
      'isperks': instance.isperks,
      'isexclusive': instance.isexclusive,
      'iswishlist': instance.iswishlist,
      'isbeenlist': instance.isbeenlist,
      'istrylist': instance.istrylist,
      'restrimglist': instance.restrimglist,
      'restroreviewlst': instance.restroreviewlst,
    };

_$RestrimglistImpl _$$RestrimglistImplFromJson(Map<String, dynamic> json) =>
    _$RestrimglistImpl(
      id: json['id'] as int?,
      restroid: json['restroid'] as int?,
      imgfile: json['imgfile'] as String?,
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
    );

Map<String, dynamic> _$$RestrimglistImplToJson(_$RestrimglistImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'restroid': instance.restroid,
      'imgfile': instance.imgfile,
      'createdon': instance.createdon?.toIso8601String(),
    };
