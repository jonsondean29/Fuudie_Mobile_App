// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'all_tags_resturant_list.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Alltagsrestrolist _$AlltagsrestrolistFromJson(Map<String, dynamic> json) {
  return _Alltagsrestrolist.fromJson(json);
}

/// @nodoc
mixin _$Alltagsrestrolist {
  @JsonKey(name: "tag")
  String get tag => throw _privateConstructorUsedError;
  @JsonKey(name: "restrolist")
  List<Restrolist> get restrolist => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AlltagsrestrolistCopyWith<Alltagsrestrolist> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AlltagsrestrolistCopyWith<$Res> {
  factory $AlltagsrestrolistCopyWith(
          Alltagsrestrolist value, $Res Function(Alltagsrestrolist) then) =
      _$AlltagsrestrolistCopyWithImpl<$Res, Alltagsrestrolist>;
  @useResult
  $Res call(
      {@JsonKey(name: "tag") String tag,
      @JsonKey(name: "restrolist") List<Restrolist> restrolist});
}

/// @nodoc
class _$AlltagsrestrolistCopyWithImpl<$Res, $Val extends Alltagsrestrolist>
    implements $AlltagsrestrolistCopyWith<$Res> {
  _$AlltagsrestrolistCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? tag = null,
    Object? restrolist = null,
  }) {
    return _then(_value.copyWith(
      tag: null == tag
          ? _value.tag
          : tag // ignore: cast_nullable_to_non_nullable
              as String,
      restrolist: null == restrolist
          ? _value.restrolist
          : restrolist // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AlltagsrestrolistImplCopyWith<$Res>
    implements $AlltagsrestrolistCopyWith<$Res> {
  factory _$$AlltagsrestrolistImplCopyWith(_$AlltagsrestrolistImpl value,
          $Res Function(_$AlltagsrestrolistImpl) then) =
      __$$AlltagsrestrolistImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "tag") String tag,
      @JsonKey(name: "restrolist") List<Restrolist> restrolist});
}

/// @nodoc
class __$$AlltagsrestrolistImplCopyWithImpl<$Res>
    extends _$AlltagsrestrolistCopyWithImpl<$Res, _$AlltagsrestrolistImpl>
    implements _$$AlltagsrestrolistImplCopyWith<$Res> {
  __$$AlltagsrestrolistImplCopyWithImpl(_$AlltagsrestrolistImpl _value,
      $Res Function(_$AlltagsrestrolistImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? tag = null,
    Object? restrolist = null,
  }) {
    return _then(_$AlltagsrestrolistImpl(
      tag: null == tag
          ? _value.tag
          : tag // ignore: cast_nullable_to_non_nullable
              as String,
      restrolist: null == restrolist
          ? _value._restrolist
          : restrolist // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AlltagsrestrolistImpl implements _Alltagsrestrolist {
  const _$AlltagsrestrolistImpl(
      {@JsonKey(name: "tag") required this.tag,
      @JsonKey(name: "restrolist") required final List<Restrolist> restrolist})
      : _restrolist = restrolist;

  factory _$AlltagsrestrolistImpl.fromJson(Map<String, dynamic> json) =>
      _$$AlltagsrestrolistImplFromJson(json);

  @override
  @JsonKey(name: "tag")
  final String tag;
  final List<Restrolist> _restrolist;
  @override
  @JsonKey(name: "restrolist")
  List<Restrolist> get restrolist {
    if (_restrolist is EqualUnmodifiableListView) return _restrolist;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_restrolist);
  }

  @override
  String toString() {
    return 'Alltagsrestrolist(tag: $tag, restrolist: $restrolist)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AlltagsrestrolistImpl &&
            (identical(other.tag, tag) || other.tag == tag) &&
            const DeepCollectionEquality()
                .equals(other._restrolist, _restrolist));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, tag, const DeepCollectionEquality().hash(_restrolist));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AlltagsrestrolistImplCopyWith<_$AlltagsrestrolistImpl> get copyWith =>
      __$$AlltagsrestrolistImplCopyWithImpl<_$AlltagsrestrolistImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AlltagsrestrolistImplToJson(
      this,
    );
  }
}

abstract class _Alltagsrestrolist implements Alltagsrestrolist {
  const factory _Alltagsrestrolist(
      {@JsonKey(name: "tag") required final String tag,
      @JsonKey(name: "restrolist")
      required final List<Restrolist> restrolist}) = _$AlltagsrestrolistImpl;

  factory _Alltagsrestrolist.fromJson(Map<String, dynamic> json) =
      _$AlltagsrestrolistImpl.fromJson;

  @override
  @JsonKey(name: "tag")
  String get tag;
  @override
  @JsonKey(name: "restrolist")
  List<Restrolist> get restrolist;
  @override
  @JsonKey(ignore: true)
  _$$AlltagsrestrolistImplCopyWith<_$AlltagsrestrolistImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Restrolist _$RestrolistFromJson(Map<String, dynamic> json) {
  return _Restrolist.fromJson(json);
}

/// @nodoc
mixin _$Restrolist {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  String? get name => throw _privateConstructorUsedError;
  @JsonKey(name: "added_by")
  int? get addedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryid")
  String? get categoryid => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryname")
  String? get categoryname => throw _privateConstructorUsedError;
  @JsonKey(name: "tags")
  String? get tags => throw _privateConstructorUsedError;
  @JsonKey(name: "shortdescription")
  String? get shortdescription => throw _privateConstructorUsedError;
  @JsonKey(name: "description")
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: "location")
  String? get location => throw _privateConstructorUsedError;
  @JsonKey(name: "city")
  String? get city => throw _privateConstructorUsedError;
  @JsonKey(name: "state")
  String? get state => throw _privateConstructorUsedError;
  @JsonKey(name: "docuntry")
  dynamic get docuntry => throw _privateConstructorUsedError;
  @JsonKey(name: "totfav")
  int? get totfav => throw _privateConstructorUsedError;
  @JsonKey(name: "totbeen")
  int? get totbeen => throw _privateConstructorUsedError;
  @JsonKey(name: "tottry")
  int? get tottry => throw _privateConstructorUsedError;
  @JsonKey(name: "pincode")
  String? get pincode => throw _privateConstructorUsedError;
  @JsonKey(name: "phone")
  dynamic get phone => throw _privateConstructorUsedError;
  @JsonKey(name: "lat")
  String? get lat => throw _privateConstructorUsedError;
  @JsonKey(name: "lng")
  String? get lng => throw _privateConstructorUsedError;
  @JsonKey(name: "fblink")
  dynamic get fblink => throw _privateConstructorUsedError;
  @JsonKey(name: "instalink")
  String? get instalink => throw _privateConstructorUsedError;
  @JsonKey(name: "rating")
  double? get rating => throw _privateConstructorUsedError;
  @JsonKey(name: "totreviews")
  int? get totreviews => throw _privateConstructorUsedError;
  @JsonKey(name: "barcode")
  dynamic get barcode => throw _privateConstructorUsedError;
  @JsonKey(name: "slug")
  String? get slug => throw _privateConstructorUsedError;
  @JsonKey(name: "createdon")
  DateTime? get createdon => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedon")
  dynamic get updatedon => throw _privateConstructorUsedError;
  @JsonKey(name: "isactive")
  int? get isactive => throw _privateConstructorUsedError;
  @JsonKey(name: "isperks")
  int? get isperks => throw _privateConstructorUsedError;
  @JsonKey(name: "isexclusive")
  int? get isexclusive => throw _privateConstructorUsedError;
  @JsonKey(name: "iswishlist")
  int? get iswishlist => throw _privateConstructorUsedError;
  @JsonKey(name: "isbeenlist")
  int? get isbeenlist => throw _privateConstructorUsedError;
  @JsonKey(name: "istrylist")
  int? get istrylist => throw _privateConstructorUsedError;
  @JsonKey(name: "mainimg")
  String? get mainimg => throw _privateConstructorUsedError;
  @JsonKey(name: "restrimglist")
  dynamic get restrimglist => throw _privateConstructorUsedError;
  @JsonKey(name: "restroreviewlst")
  dynamic get restroreviewlst => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RestrolistCopyWith<Restrolist> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RestrolistCopyWith<$Res> {
  factory $RestrolistCopyWith(
          Restrolist value, $Res Function(Restrolist) then) =
      _$RestrolistCopyWithImpl<$Res, Restrolist>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "added_by") int? addedBy,
      @JsonKey(name: "categoryid") String? categoryid,
      @JsonKey(name: "categoryname") String? categoryname,
      @JsonKey(name: "tags") String? tags,
      @JsonKey(name: "shortdescription") String? shortdescription,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "location") String? location,
      @JsonKey(name: "city") String? city,
      @JsonKey(name: "state") String? state,
      @JsonKey(name: "docuntry") dynamic docuntry,
      @JsonKey(name: "totfav") int? totfav,
      @JsonKey(name: "totbeen") int? totbeen,
      @JsonKey(name: "tottry") int? tottry,
      @JsonKey(name: "pincode") String? pincode,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "lat") String? lat,
      @JsonKey(name: "lng") String? lng,
      @JsonKey(name: "fblink") dynamic fblink,
      @JsonKey(name: "instalink") String? instalink,
      @JsonKey(name: "rating") double? rating,
      @JsonKey(name: "totreviews") int? totreviews,
      @JsonKey(name: "barcode") dynamic barcode,
      @JsonKey(name: "slug") String? slug,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "isperks") int? isperks,
      @JsonKey(name: "isexclusive") int? isexclusive,
      @JsonKey(name: "iswishlist") int? iswishlist,
      @JsonKey(name: "isbeenlist") int? isbeenlist,
      @JsonKey(name: "istrylist") int? istrylist,
      @JsonKey(name: "mainimg") String? mainimg,
      @JsonKey(name: "restrimglist") dynamic restrimglist,
      @JsonKey(name: "restroreviewlst") dynamic restroreviewlst});
}

/// @nodoc
class _$RestrolistCopyWithImpl<$Res, $Val extends Restrolist>
    implements $RestrolistCopyWith<$Res> {
  _$RestrolistCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? addedBy = freezed,
    Object? categoryid = freezed,
    Object? categoryname = freezed,
    Object? tags = freezed,
    Object? shortdescription = freezed,
    Object? description = freezed,
    Object? location = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? docuntry = freezed,
    Object? totfav = freezed,
    Object? totbeen = freezed,
    Object? tottry = freezed,
    Object? pincode = freezed,
    Object? phone = freezed,
    Object? lat = freezed,
    Object? lng = freezed,
    Object? fblink = freezed,
    Object? instalink = freezed,
    Object? rating = freezed,
    Object? totreviews = freezed,
    Object? barcode = freezed,
    Object? slug = freezed,
    Object? createdon = freezed,
    Object? updatedon = freezed,
    Object? isactive = freezed,
    Object? isperks = freezed,
    Object? isexclusive = freezed,
    Object? iswishlist = freezed,
    Object? isbeenlist = freezed,
    Object? istrylist = freezed,
    Object? mainimg = freezed,
    Object? restrimglist = freezed,
    Object? restroreviewlst = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      addedBy: freezed == addedBy
          ? _value.addedBy
          : addedBy // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryid: freezed == categoryid
          ? _value.categoryid
          : categoryid // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryname: freezed == categoryname
          ? _value.categoryname
          : categoryname // ignore: cast_nullable_to_non_nullable
              as String?,
      tags: freezed == tags
          ? _value.tags
          : tags // ignore: cast_nullable_to_non_nullable
              as String?,
      shortdescription: freezed == shortdescription
          ? _value.shortdescription
          : shortdescription // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      location: freezed == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      docuntry: freezed == docuntry
          ? _value.docuntry
          : docuntry // ignore: cast_nullable_to_non_nullable
              as dynamic,
      totfav: freezed == totfav
          ? _value.totfav
          : totfav // ignore: cast_nullable_to_non_nullable
              as int?,
      totbeen: freezed == totbeen
          ? _value.totbeen
          : totbeen // ignore: cast_nullable_to_non_nullable
              as int?,
      tottry: freezed == tottry
          ? _value.tottry
          : tottry // ignore: cast_nullable_to_non_nullable
              as int?,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as String?,
      lng: freezed == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as String?,
      fblink: freezed == fblink
          ? _value.fblink
          : fblink // ignore: cast_nullable_to_non_nullable
              as dynamic,
      instalink: freezed == instalink
          ? _value.instalink
          : instalink // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: freezed == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double?,
      totreviews: freezed == totreviews
          ? _value.totreviews
          : totreviews // ignore: cast_nullable_to_non_nullable
              as int?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      slug: freezed == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      isperks: freezed == isperks
          ? _value.isperks
          : isperks // ignore: cast_nullable_to_non_nullable
              as int?,
      isexclusive: freezed == isexclusive
          ? _value.isexclusive
          : isexclusive // ignore: cast_nullable_to_non_nullable
              as int?,
      iswishlist: freezed == iswishlist
          ? _value.iswishlist
          : iswishlist // ignore: cast_nullable_to_non_nullable
              as int?,
      isbeenlist: freezed == isbeenlist
          ? _value.isbeenlist
          : isbeenlist // ignore: cast_nullable_to_non_nullable
              as int?,
      istrylist: freezed == istrylist
          ? _value.istrylist
          : istrylist // ignore: cast_nullable_to_non_nullable
              as int?,
      mainimg: freezed == mainimg
          ? _value.mainimg
          : mainimg // ignore: cast_nullable_to_non_nullable
              as String?,
      restrimglist: freezed == restrimglist
          ? _value.restrimglist
          : restrimglist // ignore: cast_nullable_to_non_nullable
              as dynamic,
      restroreviewlst: freezed == restroreviewlst
          ? _value.restroreviewlst
          : restroreviewlst // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RestrolistImplCopyWith<$Res>
    implements $RestrolistCopyWith<$Res> {
  factory _$$RestrolistImplCopyWith(
          _$RestrolistImpl value, $Res Function(_$RestrolistImpl) then) =
      __$$RestrolistImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "added_by") int? addedBy,
      @JsonKey(name: "categoryid") String? categoryid,
      @JsonKey(name: "categoryname") String? categoryname,
      @JsonKey(name: "tags") String? tags,
      @JsonKey(name: "shortdescription") String? shortdescription,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "location") String? location,
      @JsonKey(name: "city") String? city,
      @JsonKey(name: "state") String? state,
      @JsonKey(name: "docuntry") dynamic docuntry,
      @JsonKey(name: "totfav") int? totfav,
      @JsonKey(name: "totbeen") int? totbeen,
      @JsonKey(name: "tottry") int? tottry,
      @JsonKey(name: "pincode") String? pincode,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "lat") String? lat,
      @JsonKey(name: "lng") String? lng,
      @JsonKey(name: "fblink") dynamic fblink,
      @JsonKey(name: "instalink") String? instalink,
      @JsonKey(name: "rating") double? rating,
      @JsonKey(name: "totreviews") int? totreviews,
      @JsonKey(name: "barcode") dynamic barcode,
      @JsonKey(name: "slug") String? slug,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "isperks") int? isperks,
      @JsonKey(name: "isexclusive") int? isexclusive,
      @JsonKey(name: "iswishlist") int? iswishlist,
      @JsonKey(name: "isbeenlist") int? isbeenlist,
      @JsonKey(name: "istrylist") int? istrylist,
      @JsonKey(name: "mainimg") String? mainimg,
      @JsonKey(name: "restrimglist") dynamic restrimglist,
      @JsonKey(name: "restroreviewlst") dynamic restroreviewlst});
}

/// @nodoc
class __$$RestrolistImplCopyWithImpl<$Res>
    extends _$RestrolistCopyWithImpl<$Res, _$RestrolistImpl>
    implements _$$RestrolistImplCopyWith<$Res> {
  __$$RestrolistImplCopyWithImpl(
      _$RestrolistImpl _value, $Res Function(_$RestrolistImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? addedBy = freezed,
    Object? categoryid = freezed,
    Object? categoryname = freezed,
    Object? tags = freezed,
    Object? shortdescription = freezed,
    Object? description = freezed,
    Object? location = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? docuntry = freezed,
    Object? totfav = freezed,
    Object? totbeen = freezed,
    Object? tottry = freezed,
    Object? pincode = freezed,
    Object? phone = freezed,
    Object? lat = freezed,
    Object? lng = freezed,
    Object? fblink = freezed,
    Object? instalink = freezed,
    Object? rating = freezed,
    Object? totreviews = freezed,
    Object? barcode = freezed,
    Object? slug = freezed,
    Object? createdon = freezed,
    Object? updatedon = freezed,
    Object? isactive = freezed,
    Object? isperks = freezed,
    Object? isexclusive = freezed,
    Object? iswishlist = freezed,
    Object? isbeenlist = freezed,
    Object? istrylist = freezed,
    Object? mainimg = freezed,
    Object? restrimglist = freezed,
    Object? restroreviewlst = freezed,
  }) {
    return _then(_$RestrolistImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      addedBy: freezed == addedBy
          ? _value.addedBy
          : addedBy // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryid: freezed == categoryid
          ? _value.categoryid
          : categoryid // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryname: freezed == categoryname
          ? _value.categoryname
          : categoryname // ignore: cast_nullable_to_non_nullable
              as String?,
      tags: freezed == tags
          ? _value.tags
          : tags // ignore: cast_nullable_to_non_nullable
              as String?,
      shortdescription: freezed == shortdescription
          ? _value.shortdescription
          : shortdescription // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      location: freezed == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      docuntry: freezed == docuntry
          ? _value.docuntry
          : docuntry // ignore: cast_nullable_to_non_nullable
              as dynamic,
      totfav: freezed == totfav
          ? _value.totfav
          : totfav // ignore: cast_nullable_to_non_nullable
              as int?,
      totbeen: freezed == totbeen
          ? _value.totbeen
          : totbeen // ignore: cast_nullable_to_non_nullable
              as int?,
      tottry: freezed == tottry
          ? _value.tottry
          : tottry // ignore: cast_nullable_to_non_nullable
              as int?,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as String?,
      lng: freezed == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as String?,
      fblink: freezed == fblink
          ? _value.fblink
          : fblink // ignore: cast_nullable_to_non_nullable
              as dynamic,
      instalink: freezed == instalink
          ? _value.instalink
          : instalink // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: freezed == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double?,
      totreviews: freezed == totreviews
          ? _value.totreviews
          : totreviews // ignore: cast_nullable_to_non_nullable
              as int?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      slug: freezed == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      isperks: freezed == isperks
          ? _value.isperks
          : isperks // ignore: cast_nullable_to_non_nullable
              as int?,
      isexclusive: freezed == isexclusive
          ? _value.isexclusive
          : isexclusive // ignore: cast_nullable_to_non_nullable
              as int?,
      iswishlist: freezed == iswishlist
          ? _value.iswishlist
          : iswishlist // ignore: cast_nullable_to_non_nullable
              as int?,
      isbeenlist: freezed == isbeenlist
          ? _value.isbeenlist
          : isbeenlist // ignore: cast_nullable_to_non_nullable
              as int?,
      istrylist: freezed == istrylist
          ? _value.istrylist
          : istrylist // ignore: cast_nullable_to_non_nullable
              as int?,
      mainimg: freezed == mainimg
          ? _value.mainimg
          : mainimg // ignore: cast_nullable_to_non_nullable
              as String?,
      restrimglist: freezed == restrimglist
          ? _value.restrimglist
          : restrimglist // ignore: cast_nullable_to_non_nullable
              as dynamic,
      restroreviewlst: freezed == restroreviewlst
          ? _value.restroreviewlst
          : restroreviewlst // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RestrolistImpl implements _Restrolist {
  const _$RestrolistImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "name") required this.name,
      @JsonKey(name: "added_by") required this.addedBy,
      @JsonKey(name: "categoryid") required this.categoryid,
      @JsonKey(name: "categoryname") required this.categoryname,
      @JsonKey(name: "tags") required this.tags,
      @JsonKey(name: "shortdescription") required this.shortdescription,
      @JsonKey(name: "description") required this.description,
      @JsonKey(name: "location") required this.location,
      @JsonKey(name: "city") required this.city,
      @JsonKey(name: "state") required this.state,
      @JsonKey(name: "docuntry") required this.docuntry,
      @JsonKey(name: "totfav") required this.totfav,
      @JsonKey(name: "totbeen") required this.totbeen,
      @JsonKey(name: "tottry") required this.tottry,
      @JsonKey(name: "pincode") required this.pincode,
      @JsonKey(name: "phone") required this.phone,
      @JsonKey(name: "lat") required this.lat,
      @JsonKey(name: "lng") required this.lng,
      @JsonKey(name: "fblink") required this.fblink,
      @JsonKey(name: "instalink") required this.instalink,
      @JsonKey(name: "rating") required this.rating,
      @JsonKey(name: "totreviews") required this.totreviews,
      @JsonKey(name: "barcode") required this.barcode,
      @JsonKey(name: "slug") required this.slug,
      @JsonKey(name: "createdon") required this.createdon,
      @JsonKey(name: "updatedon") required this.updatedon,
      @JsonKey(name: "isactive") required this.isactive,
      @JsonKey(name: "isperks") required this.isperks,
      @JsonKey(name: "isexclusive") required this.isexclusive,
      @JsonKey(name: "iswishlist") required this.iswishlist,
      @JsonKey(name: "isbeenlist") required this.isbeenlist,
      @JsonKey(name: "istrylist") required this.istrylist,
      @JsonKey(name: "mainimg") required this.mainimg,
      @JsonKey(name: "restrimglist") required this.restrimglist,
      @JsonKey(name: "restroreviewlst") required this.restroreviewlst});

  factory _$RestrolistImpl.fromJson(Map<String, dynamic> json) =>
      _$$RestrolistImplFromJson(json);

  @override
  @JsonKey(name: "id")
  final int? id;
  @override
  @JsonKey(name: "name")
  final String? name;
  @override
  @JsonKey(name: "added_by")
  final int? addedBy;
  @override
  @JsonKey(name: "categoryid")
  final String? categoryid;
  @override
  @JsonKey(name: "categoryname")
  final String? categoryname;
  @override
  @JsonKey(name: "tags")
  final String? tags;
  @override
  @JsonKey(name: "shortdescription")
  final String? shortdescription;
  @override
  @JsonKey(name: "description")
  final String? description;
  @override
  @JsonKey(name: "location")
  final String? location;
  @override
  @JsonKey(name: "city")
  final String? city;
  @override
  @JsonKey(name: "state")
  final String? state;
  @override
  @JsonKey(name: "docuntry")
  final dynamic docuntry;
  @override
  @JsonKey(name: "totfav")
  final int? totfav;
  @override
  @JsonKey(name: "totbeen")
  final int? totbeen;
  @override
  @JsonKey(name: "tottry")
  final int? tottry;
  @override
  @JsonKey(name: "pincode")
  final String? pincode;
  @override
  @JsonKey(name: "phone")
  final dynamic phone;
  @override
  @JsonKey(name: "lat")
  final String? lat;
  @override
  @JsonKey(name: "lng")
  final String? lng;
  @override
  @JsonKey(name: "fblink")
  final dynamic fblink;
  @override
  @JsonKey(name: "instalink")
  final String? instalink;
  @override
  @JsonKey(name: "rating")
  final double? rating;
  @override
  @JsonKey(name: "totreviews")
  final int? totreviews;
  @override
  @JsonKey(name: "barcode")
  final dynamic barcode;
  @override
  @JsonKey(name: "slug")
  final String? slug;
  @override
  @JsonKey(name: "createdon")
  final DateTime? createdon;
  @override
  @JsonKey(name: "updatedon")
  final dynamic updatedon;
  @override
  @JsonKey(name: "isactive")
  final int? isactive;
  @override
  @JsonKey(name: "isperks")
  final int? isperks;
  @override
  @JsonKey(name: "isexclusive")
  final int? isexclusive;
  @override
  @JsonKey(name: "iswishlist")
  final int? iswishlist;
  @override
  @JsonKey(name: "isbeenlist")
  final int? isbeenlist;
  @override
  @JsonKey(name: "istrylist")
  final int? istrylist;
  @override
  @JsonKey(name: "mainimg")
  final String? mainimg;
  @override
  @JsonKey(name: "restrimglist")
  final dynamic restrimglist;
  @override
  @JsonKey(name: "restroreviewlst")
  final dynamic restroreviewlst;

  @override
  String toString() {
    return 'Restrolist(id: $id, name: $name, addedBy: $addedBy, categoryid: $categoryid, categoryname: $categoryname, tags: $tags, shortdescription: $shortdescription, description: $description, location: $location, city: $city, state: $state, docuntry: $docuntry, totfav: $totfav, totbeen: $totbeen, tottry: $tottry, pincode: $pincode, phone: $phone, lat: $lat, lng: $lng, fblink: $fblink, instalink: $instalink, rating: $rating, totreviews: $totreviews, barcode: $barcode, slug: $slug, createdon: $createdon, updatedon: $updatedon, isactive: $isactive, isperks: $isperks, isexclusive: $isexclusive, iswishlist: $iswishlist, isbeenlist: $isbeenlist, istrylist: $istrylist, mainimg: $mainimg, restrimglist: $restrimglist, restroreviewlst: $restroreviewlst)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RestrolistImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.addedBy, addedBy) || other.addedBy == addedBy) &&
            (identical(other.categoryid, categoryid) ||
                other.categoryid == categoryid) &&
            (identical(other.categoryname, categoryname) ||
                other.categoryname == categoryname) &&
            (identical(other.tags, tags) || other.tags == tags) &&
            (identical(other.shortdescription, shortdescription) ||
                other.shortdescription == shortdescription) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.state, state) || other.state == state) &&
            const DeepCollectionEquality().equals(other.docuntry, docuntry) &&
            (identical(other.totfav, totfav) || other.totfav == totfav) &&
            (identical(other.totbeen, totbeen) || other.totbeen == totbeen) &&
            (identical(other.tottry, tottry) || other.tottry == tottry) &&
            (identical(other.pincode, pincode) || other.pincode == pincode) &&
            const DeepCollectionEquality().equals(other.phone, phone) &&
            (identical(other.lat, lat) || other.lat == lat) &&
            (identical(other.lng, lng) || other.lng == lng) &&
            const DeepCollectionEquality().equals(other.fblink, fblink) &&
            (identical(other.instalink, instalink) ||
                other.instalink == instalink) &&
            (identical(other.rating, rating) || other.rating == rating) &&
            (identical(other.totreviews, totreviews) ||
                other.totreviews == totreviews) &&
            const DeepCollectionEquality().equals(other.barcode, barcode) &&
            (identical(other.slug, slug) || other.slug == slug) &&
            (identical(other.createdon, createdon) ||
                other.createdon == createdon) &&
            const DeepCollectionEquality().equals(other.updatedon, updatedon) &&
            (identical(other.isactive, isactive) ||
                other.isactive == isactive) &&
            (identical(other.isperks, isperks) || other.isperks == isperks) &&
            (identical(other.isexclusive, isexclusive) ||
                other.isexclusive == isexclusive) &&
            (identical(other.iswishlist, iswishlist) ||
                other.iswishlist == iswishlist) &&
            (identical(other.isbeenlist, isbeenlist) ||
                other.isbeenlist == isbeenlist) &&
            (identical(other.istrylist, istrylist) ||
                other.istrylist == istrylist) &&
            (identical(other.mainimg, mainimg) || other.mainimg == mainimg) &&
            const DeepCollectionEquality()
                .equals(other.restrimglist, restrimglist) &&
            const DeepCollectionEquality()
                .equals(other.restroreviewlst, restroreviewlst));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        name,
        addedBy,
        categoryid,
        categoryname,
        tags,
        shortdescription,
        description,
        location,
        city,
        state,
        const DeepCollectionEquality().hash(docuntry),
        totfav,
        totbeen,
        tottry,
        pincode,
        const DeepCollectionEquality().hash(phone),
        lat,
        lng,
        const DeepCollectionEquality().hash(fblink),
        instalink,
        rating,
        totreviews,
        const DeepCollectionEquality().hash(barcode),
        slug,
        createdon,
        const DeepCollectionEquality().hash(updatedon),
        isactive,
        isperks,
        isexclusive,
        iswishlist,
        isbeenlist,
        istrylist,
        mainimg,
        const DeepCollectionEquality().hash(restrimglist),
        const DeepCollectionEquality().hash(restroreviewlst)
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RestrolistImplCopyWith<_$RestrolistImpl> get copyWith =>
      __$$RestrolistImplCopyWithImpl<_$RestrolistImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RestrolistImplToJson(
      this,
    );
  }
}

abstract class _Restrolist implements Restrolist {
  const factory _Restrolist(
      {@JsonKey(name: "id") required final int? id,
      @JsonKey(name: "name") required final String? name,
      @JsonKey(name: "added_by") required final int? addedBy,
      @JsonKey(name: "categoryid") required final String? categoryid,
      @JsonKey(name: "categoryname") required final String? categoryname,
      @JsonKey(name: "tags") required final String? tags,
      @JsonKey(name: "shortdescription")
      required final String? shortdescription,
      @JsonKey(name: "description") required final String? description,
      @JsonKey(name: "location") required final String? location,
      @JsonKey(name: "city") required final String? city,
      @JsonKey(name: "state") required final String? state,
      @JsonKey(name: "docuntry") required final dynamic docuntry,
      @JsonKey(name: "totfav") required final int? totfav,
      @JsonKey(name: "totbeen") required final int? totbeen,
      @JsonKey(name: "tottry") required final int? tottry,
      @JsonKey(name: "pincode") required final String? pincode,
      @JsonKey(name: "phone") required final dynamic phone,
      @JsonKey(name: "lat") required final String? lat,
      @JsonKey(name: "lng") required final String? lng,
      @JsonKey(name: "fblink") required final dynamic fblink,
      @JsonKey(name: "instalink") required final String? instalink,
      @JsonKey(name: "rating") required final double? rating,
      @JsonKey(name: "totreviews") required final int? totreviews,
      @JsonKey(name: "barcode") required final dynamic barcode,
      @JsonKey(name: "slug") required final String? slug,
      @JsonKey(name: "createdon") required final DateTime? createdon,
      @JsonKey(name: "updatedon") required final dynamic updatedon,
      @JsonKey(name: "isactive") required final int? isactive,
      @JsonKey(name: "isperks") required final int? isperks,
      @JsonKey(name: "isexclusive") required final int? isexclusive,
      @JsonKey(name: "iswishlist") required final int? iswishlist,
      @JsonKey(name: "isbeenlist") required final int? isbeenlist,
      @JsonKey(name: "istrylist") required final int? istrylist,
      @JsonKey(name: "mainimg") required final String? mainimg,
      @JsonKey(name: "restrimglist") required final dynamic restrimglist,
      @JsonKey(name: "restroreviewlst")
      required final dynamic restroreviewlst}) = _$RestrolistImpl;

  factory _Restrolist.fromJson(Map<String, dynamic> json) =
      _$RestrolistImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @override
  @JsonKey(name: "name")
  String? get name;
  @override
  @JsonKey(name: "added_by")
  int? get addedBy;
  @override
  @JsonKey(name: "categoryid")
  String? get categoryid;
  @override
  @JsonKey(name: "categoryname")
  String? get categoryname;
  @override
  @JsonKey(name: "tags")
  String? get tags;
  @override
  @JsonKey(name: "shortdescription")
  String? get shortdescription;
  @override
  @JsonKey(name: "description")
  String? get description;
  @override
  @JsonKey(name: "location")
  String? get location;
  @override
  @JsonKey(name: "city")
  String? get city;
  @override
  @JsonKey(name: "state")
  String? get state;
  @override
  @JsonKey(name: "docuntry")
  dynamic get docuntry;
  @override
  @JsonKey(name: "totfav")
  int? get totfav;
  @override
  @JsonKey(name: "totbeen")
  int? get totbeen;
  @override
  @JsonKey(name: "tottry")
  int? get tottry;
  @override
  @JsonKey(name: "pincode")
  String? get pincode;
  @override
  @JsonKey(name: "phone")
  dynamic get phone;
  @override
  @JsonKey(name: "lat")
  String? get lat;
  @override
  @JsonKey(name: "lng")
  String? get lng;
  @override
  @JsonKey(name: "fblink")
  dynamic get fblink;
  @override
  @JsonKey(name: "instalink")
  String? get instalink;
  @override
  @JsonKey(name: "rating")
  double? get rating;
  @override
  @JsonKey(name: "totreviews")
  int? get totreviews;
  @override
  @JsonKey(name: "barcode")
  dynamic get barcode;
  @override
  @JsonKey(name: "slug")
  String? get slug;
  @override
  @JsonKey(name: "createdon")
  DateTime? get createdon;
  @override
  @JsonKey(name: "updatedon")
  dynamic get updatedon;
  @override
  @JsonKey(name: "isactive")
  int? get isactive;
  @override
  @JsonKey(name: "isperks")
  int? get isperks;
  @override
  @JsonKey(name: "isexclusive")
  int? get isexclusive;
  @override
  @JsonKey(name: "iswishlist")
  int? get iswishlist;
  @override
  @JsonKey(name: "isbeenlist")
  int? get isbeenlist;
  @override
  @JsonKey(name: "istrylist")
  int? get istrylist;
  @override
  @JsonKey(name: "mainimg")
  String? get mainimg;
  @override
  @JsonKey(name: "restrimglist")
  dynamic get restrimglist;
  @override
  @JsonKey(name: "restroreviewlst")
  dynamic get restroreviewlst;
  @override
  @JsonKey(ignore: true)
  _$$RestrolistImplCopyWith<_$RestrolistImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
