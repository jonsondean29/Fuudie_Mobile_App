// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'restaurant_details_response_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RestaurantDetailsResponse _$RestaurantDetailsResponseFromJson(
    Map<String, dynamic> json) {
  return _RestaurantDetailsResponse.fromJson(json);
}

/// @nodoc
mixin _$RestaurantDetailsResponse {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  String? get name => throw _privateConstructorUsedError;
  @JsonKey(name: "added_by")
  int? get addedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryid")
  String? get categoryid => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryname")
  String? get categoryname => throw _privateConstructorUsedError;
  @JsonKey(name: "tags")
  String? get tags => throw _privateConstructorUsedError;
  @JsonKey(name: "shortdescription")
  String? get shortdescription => throw _privateConstructorUsedError;
  @JsonKey(name: "description")
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: "location")
  String? get location => throw _privateConstructorUsedError;
  @JsonKey(name: "city")
  String? get city => throw _privateConstructorUsedError;
  @JsonKey(name: "state")
  String? get state => throw _privateConstructorUsedError;
  @JsonKey(name: "docuntry")
  dynamic get docuntry => throw _privateConstructorUsedError;
  @JsonKey(name: "totfav")
  int? get totfav => throw _privateConstructorUsedError;
  @JsonKey(name: "totbeen")
  int? get totbeen => throw _privateConstructorUsedError;
  @JsonKey(name: "tottry")
  int? get tottry => throw _privateConstructorUsedError;
  @JsonKey(name: "pincode")
  String? get pincode => throw _privateConstructorUsedError;
  @JsonKey(name: "phone")
  dynamic get phone => throw _privateConstructorUsedError;
  @JsonKey(name: "lat")
  String? get lat => throw _privateConstructorUsedError;
  @JsonKey(name: "lng")
  String? get lng => throw _privateConstructorUsedError;
  @JsonKey(name: "fblink")
  dynamic get fblink => throw _privateConstructorUsedError;
  @JsonKey(name: "instalink")
  String? get instalink => throw _privateConstructorUsedError;
  @JsonKey(name: "rating")
  double? get rating => throw _privateConstructorUsedError;
  @JsonKey(name: "totreviews")
  int? get totreviews => throw _privateConstructorUsedError;
  @JsonKey(name: "barcode")
  dynamic get barcode => throw _privateConstructorUsedError;
  @JsonKey(name: "slug")
  String? get slug => throw _privateConstructorUsedError;
  @JsonKey(name: "createdon")
  DateTime? get createdon => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedon")
  dynamic get updatedon => throw _privateConstructorUsedError;
  @JsonKey(name: "isactive")
  int? get isactive => throw _privateConstructorUsedError;
  @JsonKey(name: "isperks")
  int? get isperks => throw _privateConstructorUsedError;
  @JsonKey(name: "isexclusive")
  int? get isexclusive => throw _privateConstructorUsedError;
  @JsonKey(name: "iswishlist")
  int? get iswishlist => throw _privateConstructorUsedError;
  @JsonKey(name: "isbeenlist")
  int? get isbeenlist => throw _privateConstructorUsedError;
  @JsonKey(name: "istrylist")
  int? get istrylist => throw _privateConstructorUsedError;
  @JsonKey(name: "restrimglist")
  List<Restrimglist>? get restrimglist => throw _privateConstructorUsedError;
  @JsonKey(name: "restroreviewlst")
  List<dynamic>? get restroreviewlst => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RestaurantDetailsResponseCopyWith<RestaurantDetailsResponse> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RestaurantDetailsResponseCopyWith<$Res> {
  factory $RestaurantDetailsResponseCopyWith(RestaurantDetailsResponse value,
          $Res Function(RestaurantDetailsResponse) then) =
      _$RestaurantDetailsResponseCopyWithImpl<$Res, RestaurantDetailsResponse>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "added_by") int? addedBy,
      @JsonKey(name: "categoryid") String? categoryid,
      @JsonKey(name: "categoryname") String? categoryname,
      @JsonKey(name: "tags") String? tags,
      @JsonKey(name: "shortdescription") String? shortdescription,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "location") String? location,
      @JsonKey(name: "city") String? city,
      @JsonKey(name: "state") String? state,
      @JsonKey(name: "docuntry") dynamic docuntry,
      @JsonKey(name: "totfav") int? totfav,
      @JsonKey(name: "totbeen") int? totbeen,
      @JsonKey(name: "tottry") int? tottry,
      @JsonKey(name: "pincode") String? pincode,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "lat") String? lat,
      @JsonKey(name: "lng") String? lng,
      @JsonKey(name: "fblink") dynamic fblink,
      @JsonKey(name: "instalink") String? instalink,
      @JsonKey(name: "rating") double? rating,
      @JsonKey(name: "totreviews") int? totreviews,
      @JsonKey(name: "barcode") dynamic barcode,
      @JsonKey(name: "slug") String? slug,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "isperks") int? isperks,
      @JsonKey(name: "isexclusive") int? isexclusive,
      @JsonKey(name: "iswishlist") int? iswishlist,
      @JsonKey(name: "isbeenlist") int? isbeenlist,
      @JsonKey(name: "istrylist") int? istrylist,
      @JsonKey(name: "restrimglist") List<Restrimglist>? restrimglist,
      @JsonKey(name: "restroreviewlst") List<dynamic>? restroreviewlst});
}

/// @nodoc
class _$RestaurantDetailsResponseCopyWithImpl<$Res,
        $Val extends RestaurantDetailsResponse>
    implements $RestaurantDetailsResponseCopyWith<$Res> {
  _$RestaurantDetailsResponseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? addedBy = freezed,
    Object? categoryid = freezed,
    Object? categoryname = freezed,
    Object? tags = freezed,
    Object? shortdescription = freezed,
    Object? description = freezed,
    Object? location = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? docuntry = freezed,
    Object? totfav = freezed,
    Object? totbeen = freezed,
    Object? tottry = freezed,
    Object? pincode = freezed,
    Object? phone = freezed,
    Object? lat = freezed,
    Object? lng = freezed,
    Object? fblink = freezed,
    Object? instalink = freezed,
    Object? rating = freezed,
    Object? totreviews = freezed,
    Object? barcode = freezed,
    Object? slug = freezed,
    Object? createdon = freezed,
    Object? updatedon = freezed,
    Object? isactive = freezed,
    Object? isperks = freezed,
    Object? isexclusive = freezed,
    Object? iswishlist = freezed,
    Object? isbeenlist = freezed,
    Object? istrylist = freezed,
    Object? restrimglist = freezed,
    Object? restroreviewlst = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      addedBy: freezed == addedBy
          ? _value.addedBy
          : addedBy // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryid: freezed == categoryid
          ? _value.categoryid
          : categoryid // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryname: freezed == categoryname
          ? _value.categoryname
          : categoryname // ignore: cast_nullable_to_non_nullable
              as String?,
      tags: freezed == tags
          ? _value.tags
          : tags // ignore: cast_nullable_to_non_nullable
              as String?,
      shortdescription: freezed == shortdescription
          ? _value.shortdescription
          : shortdescription // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      location: freezed == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      docuntry: freezed == docuntry
          ? _value.docuntry
          : docuntry // ignore: cast_nullable_to_non_nullable
              as dynamic,
      totfav: freezed == totfav
          ? _value.totfav
          : totfav // ignore: cast_nullable_to_non_nullable
              as int?,
      totbeen: freezed == totbeen
          ? _value.totbeen
          : totbeen // ignore: cast_nullable_to_non_nullable
              as int?,
      tottry: freezed == tottry
          ? _value.tottry
          : tottry // ignore: cast_nullable_to_non_nullable
              as int?,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as String?,
      lng: freezed == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as String?,
      fblink: freezed == fblink
          ? _value.fblink
          : fblink // ignore: cast_nullable_to_non_nullable
              as dynamic,
      instalink: freezed == instalink
          ? _value.instalink
          : instalink // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: freezed == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double?,
      totreviews: freezed == totreviews
          ? _value.totreviews
          : totreviews // ignore: cast_nullable_to_non_nullable
              as int?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      slug: freezed == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      isperks: freezed == isperks
          ? _value.isperks
          : isperks // ignore: cast_nullable_to_non_nullable
              as int?,
      isexclusive: freezed == isexclusive
          ? _value.isexclusive
          : isexclusive // ignore: cast_nullable_to_non_nullable
              as int?,
      iswishlist: freezed == iswishlist
          ? _value.iswishlist
          : iswishlist // ignore: cast_nullable_to_non_nullable
              as int?,
      isbeenlist: freezed == isbeenlist
          ? _value.isbeenlist
          : isbeenlist // ignore: cast_nullable_to_non_nullable
              as int?,
      istrylist: freezed == istrylist
          ? _value.istrylist
          : istrylist // ignore: cast_nullable_to_non_nullable
              as int?,
      restrimglist: freezed == restrimglist
          ? _value.restrimglist
          : restrimglist // ignore: cast_nullable_to_non_nullable
              as List<Restrimglist>?,
      restroreviewlst: freezed == restroreviewlst
          ? _value.restroreviewlst
          : restroreviewlst // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RestaurantDetailsResponseImplCopyWith<$Res>
    implements $RestaurantDetailsResponseCopyWith<$Res> {
  factory _$$RestaurantDetailsResponseImplCopyWith(
          _$RestaurantDetailsResponseImpl value,
          $Res Function(_$RestaurantDetailsResponseImpl) then) =
      __$$RestaurantDetailsResponseImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "added_by") int? addedBy,
      @JsonKey(name: "categoryid") String? categoryid,
      @JsonKey(name: "categoryname") String? categoryname,
      @JsonKey(name: "tags") String? tags,
      @JsonKey(name: "shortdescription") String? shortdescription,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "location") String? location,
      @JsonKey(name: "city") String? city,
      @JsonKey(name: "state") String? state,
      @JsonKey(name: "docuntry") dynamic docuntry,
      @JsonKey(name: "totfav") int? totfav,
      @JsonKey(name: "totbeen") int? totbeen,
      @JsonKey(name: "tottry") int? tottry,
      @JsonKey(name: "pincode") String? pincode,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "lat") String? lat,
      @JsonKey(name: "lng") String? lng,
      @JsonKey(name: "fblink") dynamic fblink,
      @JsonKey(name: "instalink") String? instalink,
      @JsonKey(name: "rating") double? rating,
      @JsonKey(name: "totreviews") int? totreviews,
      @JsonKey(name: "barcode") dynamic barcode,
      @JsonKey(name: "slug") String? slug,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "isperks") int? isperks,
      @JsonKey(name: "isexclusive") int? isexclusive,
      @JsonKey(name: "iswishlist") int? iswishlist,
      @JsonKey(name: "isbeenlist") int? isbeenlist,
      @JsonKey(name: "istrylist") int? istrylist,
      @JsonKey(name: "restrimglist") List<Restrimglist>? restrimglist,
      @JsonKey(name: "restroreviewlst") List<dynamic>? restroreviewlst});
}

/// @nodoc
class __$$RestaurantDetailsResponseImplCopyWithImpl<$Res>
    extends _$RestaurantDetailsResponseCopyWithImpl<$Res,
        _$RestaurantDetailsResponseImpl>
    implements _$$RestaurantDetailsResponseImplCopyWith<$Res> {
  __$$RestaurantDetailsResponseImplCopyWithImpl(
      _$RestaurantDetailsResponseImpl _value,
      $Res Function(_$RestaurantDetailsResponseImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? addedBy = freezed,
    Object? categoryid = freezed,
    Object? categoryname = freezed,
    Object? tags = freezed,
    Object? shortdescription = freezed,
    Object? description = freezed,
    Object? location = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? docuntry = freezed,
    Object? totfav = freezed,
    Object? totbeen = freezed,
    Object? tottry = freezed,
    Object? pincode = freezed,
    Object? phone = freezed,
    Object? lat = freezed,
    Object? lng = freezed,
    Object? fblink = freezed,
    Object? instalink = freezed,
    Object? rating = freezed,
    Object? totreviews = freezed,
    Object? barcode = freezed,
    Object? slug = freezed,
    Object? createdon = freezed,
    Object? updatedon = freezed,
    Object? isactive = freezed,
    Object? isperks = freezed,
    Object? isexclusive = freezed,
    Object? iswishlist = freezed,
    Object? isbeenlist = freezed,
    Object? istrylist = freezed,
    Object? restrimglist = freezed,
    Object? restroreviewlst = freezed,
  }) {
    return _then(_$RestaurantDetailsResponseImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      addedBy: freezed == addedBy
          ? _value.addedBy
          : addedBy // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryid: freezed == categoryid
          ? _value.categoryid
          : categoryid // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryname: freezed == categoryname
          ? _value.categoryname
          : categoryname // ignore: cast_nullable_to_non_nullable
              as String?,
      tags: freezed == tags
          ? _value.tags
          : tags // ignore: cast_nullable_to_non_nullable
              as String?,
      shortdescription: freezed == shortdescription
          ? _value.shortdescription
          : shortdescription // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      location: freezed == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      docuntry: freezed == docuntry
          ? _value.docuntry
          : docuntry // ignore: cast_nullable_to_non_nullable
              as dynamic,
      totfav: freezed == totfav
          ? _value.totfav
          : totfav // ignore: cast_nullable_to_non_nullable
              as int?,
      totbeen: freezed == totbeen
          ? _value.totbeen
          : totbeen // ignore: cast_nullable_to_non_nullable
              as int?,
      tottry: freezed == tottry
          ? _value.tottry
          : tottry // ignore: cast_nullable_to_non_nullable
              as int?,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as String?,
      lng: freezed == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as String?,
      fblink: freezed == fblink
          ? _value.fblink
          : fblink // ignore: cast_nullable_to_non_nullable
              as dynamic,
      instalink: freezed == instalink
          ? _value.instalink
          : instalink // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: freezed == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double?,
      totreviews: freezed == totreviews
          ? _value.totreviews
          : totreviews // ignore: cast_nullable_to_non_nullable
              as int?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      slug: freezed == slug
          ? _value.slug
          : slug // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      isperks: freezed == isperks
          ? _value.isperks
          : isperks // ignore: cast_nullable_to_non_nullable
              as int?,
      isexclusive: freezed == isexclusive
          ? _value.isexclusive
          : isexclusive // ignore: cast_nullable_to_non_nullable
              as int?,
      iswishlist: freezed == iswishlist
          ? _value.iswishlist
          : iswishlist // ignore: cast_nullable_to_non_nullable
              as int?,
      isbeenlist: freezed == isbeenlist
          ? _value.isbeenlist
          : isbeenlist // ignore: cast_nullable_to_non_nullable
              as int?,
      istrylist: freezed == istrylist
          ? _value.istrylist
          : istrylist // ignore: cast_nullable_to_non_nullable
              as int?,
      restrimglist: freezed == restrimglist
          ? _value._restrimglist
          : restrimglist // ignore: cast_nullable_to_non_nullable
              as List<Restrimglist>?,
      restroreviewlst: freezed == restroreviewlst
          ? _value._restroreviewlst
          : restroreviewlst // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RestaurantDetailsResponseImpl implements _RestaurantDetailsResponse {
  const _$RestaurantDetailsResponseImpl(
      {@JsonKey(name: "id") this.id,
      @JsonKey(name: "name") this.name,
      @JsonKey(name: "added_by") this.addedBy,
      @JsonKey(name: "categoryid") this.categoryid,
      @JsonKey(name: "categoryname") this.categoryname,
      @JsonKey(name: "tags") this.tags,
      @JsonKey(name: "shortdescription") this.shortdescription,
      @JsonKey(name: "description") this.description,
      @JsonKey(name: "location") this.location,
      @JsonKey(name: "city") this.city,
      @JsonKey(name: "state") this.state,
      @JsonKey(name: "docuntry") this.docuntry,
      @JsonKey(name: "totfav") this.totfav,
      @JsonKey(name: "totbeen") this.totbeen,
      @JsonKey(name: "tottry") this.tottry,
      @JsonKey(name: "pincode") this.pincode,
      @JsonKey(name: "phone") this.phone,
      @JsonKey(name: "lat") this.lat,
      @JsonKey(name: "lng") this.lng,
      @JsonKey(name: "fblink") this.fblink,
      @JsonKey(name: "instalink") this.instalink,
      @JsonKey(name: "rating") this.rating,
      @JsonKey(name: "totreviews") this.totreviews,
      @JsonKey(name: "barcode") this.barcode,
      @JsonKey(name: "slug") this.slug,
      @JsonKey(name: "createdon") this.createdon,
      @JsonKey(name: "updatedon") this.updatedon,
      @JsonKey(name: "isactive") this.isactive,
      @JsonKey(name: "isperks") this.isperks,
      @JsonKey(name: "isexclusive") this.isexclusive,
      @JsonKey(name: "iswishlist") this.iswishlist,
      @JsonKey(name: "isbeenlist") this.isbeenlist,
      @JsonKey(name: "istrylist") this.istrylist,
      @JsonKey(name: "restrimglist") final List<Restrimglist>? restrimglist,
      @JsonKey(name: "restroreviewlst") final List<dynamic>? restroreviewlst})
      : _restrimglist = restrimglist,
        _restroreviewlst = restroreviewlst;

  factory _$RestaurantDetailsResponseImpl.fromJson(Map<String, dynamic> json) =>
      _$$RestaurantDetailsResponseImplFromJson(json);

  @override
  @JsonKey(name: "id")
  final int? id;
  @override
  @JsonKey(name: "name")
  final String? name;
  @override
  @JsonKey(name: "added_by")
  final int? addedBy;
  @override
  @JsonKey(name: "categoryid")
  final String? categoryid;
  @override
  @JsonKey(name: "categoryname")
  final String? categoryname;
  @override
  @JsonKey(name: "tags")
  final String? tags;
  @override
  @JsonKey(name: "shortdescription")
  final String? shortdescription;
  @override
  @JsonKey(name: "description")
  final String? description;
  @override
  @JsonKey(name: "location")
  final String? location;
  @override
  @JsonKey(name: "city")
  final String? city;
  @override
  @JsonKey(name: "state")
  final String? state;
  @override
  @JsonKey(name: "docuntry")
  final dynamic docuntry;
  @override
  @JsonKey(name: "totfav")
  final int? totfav;
  @override
  @JsonKey(name: "totbeen")
  final int? totbeen;
  @override
  @JsonKey(name: "tottry")
  final int? tottry;
  @override
  @JsonKey(name: "pincode")
  final String? pincode;
  @override
  @JsonKey(name: "phone")
  final dynamic phone;
  @override
  @JsonKey(name: "lat")
  final String? lat;
  @override
  @JsonKey(name: "lng")
  final String? lng;
  @override
  @JsonKey(name: "fblink")
  final dynamic fblink;
  @override
  @JsonKey(name: "instalink")
  final String? instalink;
  @override
  @JsonKey(name: "rating")
  final double? rating;
  @override
  @JsonKey(name: "totreviews")
  final int? totreviews;
  @override
  @JsonKey(name: "barcode")
  final dynamic barcode;
  @override
  @JsonKey(name: "slug")
  final String? slug;
  @override
  @JsonKey(name: "createdon")
  final DateTime? createdon;
  @override
  @JsonKey(name: "updatedon")
  final dynamic updatedon;
  @override
  @JsonKey(name: "isactive")
  final int? isactive;
  @override
  @JsonKey(name: "isperks")
  final int? isperks;
  @override
  @JsonKey(name: "isexclusive")
  final int? isexclusive;
  @override
  @JsonKey(name: "iswishlist")
  final int? iswishlist;
  @override
  @JsonKey(name: "isbeenlist")
  final int? isbeenlist;
  @override
  @JsonKey(name: "istrylist")
  final int? istrylist;
  final List<Restrimglist>? _restrimglist;
  @override
  @JsonKey(name: "restrimglist")
  List<Restrimglist>? get restrimglist {
    final value = _restrimglist;
    if (value == null) return null;
    if (_restrimglist is EqualUnmodifiableListView) return _restrimglist;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<dynamic>? _restroreviewlst;
  @override
  @JsonKey(name: "restroreviewlst")
  List<dynamic>? get restroreviewlst {
    final value = _restroreviewlst;
    if (value == null) return null;
    if (_restroreviewlst is EqualUnmodifiableListView) return _restroreviewlst;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'RestaurantDetailsResponse(id: $id, name: $name, addedBy: $addedBy, categoryid: $categoryid, categoryname: $categoryname, tags: $tags, shortdescription: $shortdescription, description: $description, location: $location, city: $city, state: $state, docuntry: $docuntry, totfav: $totfav, totbeen: $totbeen, tottry: $tottry, pincode: $pincode, phone: $phone, lat: $lat, lng: $lng, fblink: $fblink, instalink: $instalink, rating: $rating, totreviews: $totreviews, barcode: $barcode, slug: $slug, createdon: $createdon, updatedon: $updatedon, isactive: $isactive, isperks: $isperks, isexclusive: $isexclusive, iswishlist: $iswishlist, isbeenlist: $isbeenlist, istrylist: $istrylist, restrimglist: $restrimglist, restroreviewlst: $restroreviewlst)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RestaurantDetailsResponseImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.addedBy, addedBy) || other.addedBy == addedBy) &&
            (identical(other.categoryid, categoryid) ||
                other.categoryid == categoryid) &&
            (identical(other.categoryname, categoryname) ||
                other.categoryname == categoryname) &&
            (identical(other.tags, tags) || other.tags == tags) &&
            (identical(other.shortdescription, shortdescription) ||
                other.shortdescription == shortdescription) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.state, state) || other.state == state) &&
            const DeepCollectionEquality().equals(other.docuntry, docuntry) &&
            (identical(other.totfav, totfav) || other.totfav == totfav) &&
            (identical(other.totbeen, totbeen) || other.totbeen == totbeen) &&
            (identical(other.tottry, tottry) || other.tottry == tottry) &&
            (identical(other.pincode, pincode) || other.pincode == pincode) &&
            const DeepCollectionEquality().equals(other.phone, phone) &&
            (identical(other.lat, lat) || other.lat == lat) &&
            (identical(other.lng, lng) || other.lng == lng) &&
            const DeepCollectionEquality().equals(other.fblink, fblink) &&
            (identical(other.instalink, instalink) ||
                other.instalink == instalink) &&
            (identical(other.rating, rating) || other.rating == rating) &&
            (identical(other.totreviews, totreviews) ||
                other.totreviews == totreviews) &&
            const DeepCollectionEquality().equals(other.barcode, barcode) &&
            (identical(other.slug, slug) || other.slug == slug) &&
            (identical(other.createdon, createdon) ||
                other.createdon == createdon) &&
            const DeepCollectionEquality().equals(other.updatedon, updatedon) &&
            (identical(other.isactive, isactive) ||
                other.isactive == isactive) &&
            (identical(other.isperks, isperks) || other.isperks == isperks) &&
            (identical(other.isexclusive, isexclusive) ||
                other.isexclusive == isexclusive) &&
            (identical(other.iswishlist, iswishlist) ||
                other.iswishlist == iswishlist) &&
            (identical(other.isbeenlist, isbeenlist) ||
                other.isbeenlist == isbeenlist) &&
            (identical(other.istrylist, istrylist) ||
                other.istrylist == istrylist) &&
            const DeepCollectionEquality()
                .equals(other._restrimglist, _restrimglist) &&
            const DeepCollectionEquality()
                .equals(other._restroreviewlst, _restroreviewlst));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        name,
        addedBy,
        categoryid,
        categoryname,
        tags,
        shortdescription,
        description,
        location,
        city,
        state,
        const DeepCollectionEquality().hash(docuntry),
        totfav,
        totbeen,
        tottry,
        pincode,
        const DeepCollectionEquality().hash(phone),
        lat,
        lng,
        const DeepCollectionEquality().hash(fblink),
        instalink,
        rating,
        totreviews,
        const DeepCollectionEquality().hash(barcode),
        slug,
        createdon,
        const DeepCollectionEquality().hash(updatedon),
        isactive,
        isperks,
        isexclusive,
        iswishlist,
        isbeenlist,
        istrylist,
        const DeepCollectionEquality().hash(_restrimglist),
        const DeepCollectionEquality().hash(_restroreviewlst)
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RestaurantDetailsResponseImplCopyWith<_$RestaurantDetailsResponseImpl>
      get copyWith => __$$RestaurantDetailsResponseImplCopyWithImpl<
          _$RestaurantDetailsResponseImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RestaurantDetailsResponseImplToJson(
      this,
    );
  }
}

abstract class _RestaurantDetailsResponse implements RestaurantDetailsResponse {
  const factory _RestaurantDetailsResponse(
      {@JsonKey(name: "id") final int? id,
      @JsonKey(name: "name") final String? name,
      @JsonKey(name: "added_by") final int? addedBy,
      @JsonKey(name: "categoryid") final String? categoryid,
      @JsonKey(name: "categoryname") final String? categoryname,
      @JsonKey(name: "tags") final String? tags,
      @JsonKey(name: "shortdescription") final String? shortdescription,
      @JsonKey(name: "description") final String? description,
      @JsonKey(name: "location") final String? location,
      @JsonKey(name: "city") final String? city,
      @JsonKey(name: "state") final String? state,
      @JsonKey(name: "docuntry") final dynamic docuntry,
      @JsonKey(name: "totfav") final int? totfav,
      @JsonKey(name: "totbeen") final int? totbeen,
      @JsonKey(name: "tottry") final int? tottry,
      @JsonKey(name: "pincode") final String? pincode,
      @JsonKey(name: "phone") final dynamic phone,
      @JsonKey(name: "lat") final String? lat,
      @JsonKey(name: "lng") final String? lng,
      @JsonKey(name: "fblink") final dynamic fblink,
      @JsonKey(name: "instalink") final String? instalink,
      @JsonKey(name: "rating") final double? rating,
      @JsonKey(name: "totreviews") final int? totreviews,
      @JsonKey(name: "barcode") final dynamic barcode,
      @JsonKey(name: "slug") final String? slug,
      @JsonKey(name: "createdon") final DateTime? createdon,
      @JsonKey(name: "updatedon") final dynamic updatedon,
      @JsonKey(name: "isactive") final int? isactive,
      @JsonKey(name: "isperks") final int? isperks,
      @JsonKey(name: "isexclusive") final int? isexclusive,
      @JsonKey(name: "iswishlist") final int? iswishlist,
      @JsonKey(name: "isbeenlist") final int? isbeenlist,
      @JsonKey(name: "istrylist") final int? istrylist,
      @JsonKey(name: "restrimglist") final List<Restrimglist>? restrimglist,
      @JsonKey(name: "restroreviewlst")
      final List<dynamic>? restroreviewlst}) = _$RestaurantDetailsResponseImpl;

  factory _RestaurantDetailsResponse.fromJson(Map<String, dynamic> json) =
      _$RestaurantDetailsResponseImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @override
  @JsonKey(name: "name")
  String? get name;
  @override
  @JsonKey(name: "added_by")
  int? get addedBy;
  @override
  @JsonKey(name: "categoryid")
  String? get categoryid;
  @override
  @JsonKey(name: "categoryname")
  String? get categoryname;
  @override
  @JsonKey(name: "tags")
  String? get tags;
  @override
  @JsonKey(name: "shortdescription")
  String? get shortdescription;
  @override
  @JsonKey(name: "description")
  String? get description;
  @override
  @JsonKey(name: "location")
  String? get location;
  @override
  @JsonKey(name: "city")
  String? get city;
  @override
  @JsonKey(name: "state")
  String? get state;
  @override
  @JsonKey(name: "docuntry")
  dynamic get docuntry;
  @override
  @JsonKey(name: "totfav")
  int? get totfav;
  @override
  @JsonKey(name: "totbeen")
  int? get totbeen;
  @override
  @JsonKey(name: "tottry")
  int? get tottry;
  @override
  @JsonKey(name: "pincode")
  String? get pincode;
  @override
  @JsonKey(name: "phone")
  dynamic get phone;
  @override
  @JsonKey(name: "lat")
  String? get lat;
  @override
  @JsonKey(name: "lng")
  String? get lng;
  @override
  @JsonKey(name: "fblink")
  dynamic get fblink;
  @override
  @JsonKey(name: "instalink")
  String? get instalink;
  @override
  @JsonKey(name: "rating")
  double? get rating;
  @override
  @JsonKey(name: "totreviews")
  int? get totreviews;
  @override
  @JsonKey(name: "barcode")
  dynamic get barcode;
  @override
  @JsonKey(name: "slug")
  String? get slug;
  @override
  @JsonKey(name: "createdon")
  DateTime? get createdon;
  @override
  @JsonKey(name: "updatedon")
  dynamic get updatedon;
  @override
  @JsonKey(name: "isactive")
  int? get isactive;
  @override
  @JsonKey(name: "isperks")
  int? get isperks;
  @override
  @JsonKey(name: "isexclusive")
  int? get isexclusive;
  @override
  @JsonKey(name: "iswishlist")
  int? get iswishlist;
  @override
  @JsonKey(name: "isbeenlist")
  int? get isbeenlist;
  @override
  @JsonKey(name: "istrylist")
  int? get istrylist;
  @override
  @JsonKey(name: "restrimglist")
  List<Restrimglist>? get restrimglist;
  @override
  @JsonKey(name: "restroreviewlst")
  List<dynamic>? get restroreviewlst;
  @override
  @JsonKey(ignore: true)
  _$$RestaurantDetailsResponseImplCopyWith<_$RestaurantDetailsResponseImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Restrimglist _$RestrimglistFromJson(Map<String, dynamic> json) {
  return _Restrimglist.fromJson(json);
}

/// @nodoc
mixin _$Restrimglist {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "restroid")
  int? get restroid => throw _privateConstructorUsedError;
  @JsonKey(name: "imgfile")
  String? get imgfile => throw _privateConstructorUsedError;
  @JsonKey(name: "createdon")
  DateTime? get createdon => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RestrimglistCopyWith<Restrimglist> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RestrimglistCopyWith<$Res> {
  factory $RestrimglistCopyWith(
          Restrimglist value, $Res Function(Restrimglist) then) =
      _$RestrimglistCopyWithImpl<$Res, Restrimglist>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "restroid") int? restroid,
      @JsonKey(name: "imgfile") String? imgfile,
      @JsonKey(name: "createdon") DateTime? createdon});
}

/// @nodoc
class _$RestrimglistCopyWithImpl<$Res, $Val extends Restrimglist>
    implements $RestrimglistCopyWith<$Res> {
  _$RestrimglistCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? restroid = freezed,
    Object? imgfile = freezed,
    Object? createdon = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      restroid: freezed == restroid
          ? _value.restroid
          : restroid // ignore: cast_nullable_to_non_nullable
              as int?,
      imgfile: freezed == imgfile
          ? _value.imgfile
          : imgfile // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RestrimglistImplCopyWith<$Res>
    implements $RestrimglistCopyWith<$Res> {
  factory _$$RestrimglistImplCopyWith(
          _$RestrimglistImpl value, $Res Function(_$RestrimglistImpl) then) =
      __$$RestrimglistImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "restroid") int? restroid,
      @JsonKey(name: "imgfile") String? imgfile,
      @JsonKey(name: "createdon") DateTime? createdon});
}

/// @nodoc
class __$$RestrimglistImplCopyWithImpl<$Res>
    extends _$RestrimglistCopyWithImpl<$Res, _$RestrimglistImpl>
    implements _$$RestrimglistImplCopyWith<$Res> {
  __$$RestrimglistImplCopyWithImpl(
      _$RestrimglistImpl _value, $Res Function(_$RestrimglistImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? restroid = freezed,
    Object? imgfile = freezed,
    Object? createdon = freezed,
  }) {
    return _then(_$RestrimglistImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      restroid: freezed == restroid
          ? _value.restroid
          : restroid // ignore: cast_nullable_to_non_nullable
              as int?,
      imgfile: freezed == imgfile
          ? _value.imgfile
          : imgfile // ignore: cast_nullable_to_non_nullable
              as String?,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RestrimglistImpl implements _Restrimglist {
  const _$RestrimglistImpl(
      {@JsonKey(name: "id") this.id,
      @JsonKey(name: "restroid") this.restroid,
      @JsonKey(name: "imgfile") this.imgfile,
      @JsonKey(name: "createdon") this.createdon});

  factory _$RestrimglistImpl.fromJson(Map<String, dynamic> json) =>
      _$$RestrimglistImplFromJson(json);

  @override
  @JsonKey(name: "id")
  final int? id;
  @override
  @JsonKey(name: "restroid")
  final int? restroid;
  @override
  @JsonKey(name: "imgfile")
  final String? imgfile;
  @override
  @JsonKey(name: "createdon")
  final DateTime? createdon;

  @override
  String toString() {
    return 'Restrimglist(id: $id, restroid: $restroid, imgfile: $imgfile, createdon: $createdon)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RestrimglistImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.restroid, restroid) ||
                other.restroid == restroid) &&
            (identical(other.imgfile, imgfile) || other.imgfile == imgfile) &&
            (identical(other.createdon, createdon) ||
                other.createdon == createdon));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, restroid, imgfile, createdon);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RestrimglistImplCopyWith<_$RestrimglistImpl> get copyWith =>
      __$$RestrimglistImplCopyWithImpl<_$RestrimglistImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RestrimglistImplToJson(
      this,
    );
  }
}

abstract class _Restrimglist implements Restrimglist {
  const factory _Restrimglist(
          {@JsonKey(name: "id") final int? id,
          @JsonKey(name: "restroid") final int? restroid,
          @JsonKey(name: "imgfile") final String? imgfile,
          @JsonKey(name: "createdon") final DateTime? createdon}) =
      _$RestrimglistImpl;

  factory _Restrimglist.fromJson(Map<String, dynamic> json) =
      _$RestrimglistImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @override
  @JsonKey(name: "restroid")
  int? get restroid;
  @override
  @JsonKey(name: "imgfile")
  String? get imgfile;
  @override
  @JsonKey(name: "createdon")
  DateTime? get createdon;
  @override
  @JsonKey(ignore: true)
  _$$RestrimglistImplCopyWith<_$RestrimglistImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
