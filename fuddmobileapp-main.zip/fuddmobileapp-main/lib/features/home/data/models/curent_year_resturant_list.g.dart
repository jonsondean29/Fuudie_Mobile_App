// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'curent_year_resturant_list.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CurryearrestrolistImpl _$$CurryearrestrolistImplFromJson(
        Map<String, dynamic> json) =>
    _$CurryearrestrolistImpl(
      id: json['id'] as int?,
      name: json['name'] as String?,
      addedBy: json['added_by'] as int?,
      categoryid: json['categoryid'] as String?,
      categoryname: json['categoryname'] as String?,
      tags: json['tags'] as String?,
      shortdescription: json['shortdescription'] as String?,
      description: json['description'] as String?,
      location: json['location'] as String?,
      city: json['city'] as String?,
      state: json['state'] as String?,
      docuntry: json['docuntry'],
      totfav: json['totfav'] as int?,
      totbeen: json['totbeen'] as int?,
      tottry: json['tottry'] as int?,
      pincode: json['pincode'] as String?,
      phone: json['phone'],
      lat: json['lat'] as String?,
      lng: json['lng'] as String?,
      fblink: json['fblink'],
      instalink: json['instalink'] as String?,
      rating: (json['rating'] as num?)?.toDouble(),
      totreviews: json['totreviews'] as int?,
      barcode: json['barcode'],
      slug: json['slug'] as String?,
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
      updatedon: json['updatedon'],
      isactive: json['isactive'] as int?,
      isperks: json['isperks'] as int?,
      isexclusive: json['isexclusive'] as int?,
      iswishlist: json['iswishlist'] as int?,
      isbeenlist: json['isbeenlist'] as int?,
      istrylist: json['istrylist'] as int?,
      mainimg: json['mainimg'],
      restrimglist: json['restrimglist'],
      restroreviewlst: json['restroreviewlst'],
    );

Map<String, dynamic> _$$CurryearrestrolistImplToJson(
        _$CurryearrestrolistImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'added_by': instance.addedBy,
      'categoryid': instance.categoryid,
      'categoryname': instance.categoryname,
      'tags': instance.tags,
      'shortdescription': instance.shortdescription,
      'description': instance.description,
      'location': instance.location,
      'city': instance.city,
      'state': instance.state,
      'docuntry': instance.docuntry,
      'totfav': instance.totfav,
      'totbeen': instance.totbeen,
      'tottry': instance.tottry,
      'pincode': instance.pincode,
      'phone': instance.phone,
      'lat': instance.lat,
      'lng': instance.lng,
      'fblink': instance.fblink,
      'instalink': instance.instalink,
      'rating': instance.rating,
      'totreviews': instance.totreviews,
      'barcode': instance.barcode,
      'slug': instance.slug,
      'createdon': instance.createdon?.toIso8601String(),
      'updatedon': instance.updatedon,
      'isactive': instance.isactive,
      'isperks': instance.isperks,
      'isexclusive': instance.isexclusive,
      'iswishlist': instance.iswishlist,
      'isbeenlist': instance.isbeenlist,
      'istrylist': instance.istrylist,
      'mainimg': instance.mainimg,
      'restrimglist': instance.restrimglist,
      'restroreviewlst': instance.restroreviewlst,
    };
