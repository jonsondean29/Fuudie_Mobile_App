import 'dart:convert';
import 'package:freezed_annotation/freezed_annotation.dart';
// ignore_for_file: invalid_annotation_target

// To parse this JSON data, do
//
//     final restaurantDetailsResponse = restaurantDetailsResponseFromJson(jsonString);

part 'restaurant_details_response_model.freezed.dart';
part 'restaurant_details_response_model.g.dart';

RestaurantDetailsResponse restaurantDetailsResponseFromJson(String str) =>
    RestaurantDetailsResponse.fromJson(json.decode(str));

String restaurantDetailsResponseToJson(RestaurantDetailsResponse data) =>
    json.encode(data.toJson());

@freezed
class RestaurantDetailsResponse with _$RestaurantDetailsResponse {
  const factory RestaurantDetailsResponse({
    @JsonKey(name: "id") int? id,
    @JsonKey(name: "name") String? name,
    @JsonKey(name: "added_by") int? addedBy,
    @JsonKey(name: "categoryid") String? categoryid,
    @JsonKey(name: "categoryname") String? categoryname,
    @JsonKey(name: "tags") String? tags,
    @JsonKey(name: "shortdescription") String? shortdescription,
    @JsonKey(name: "description") String? description,
    @JsonKey(name: "location") String? location,
    @JsonKey(name: "city") String? city,
    @JsonKey(name: "state") String? state,
    @JsonKey(name: "docuntry") dynamic docuntry,
    @JsonKey(name: "totfav") int? totfav,
    @JsonKey(name: "totbeen") int? totbeen,
    @JsonKey(name: "tottry") int? tottry,
    @JsonKey(name: "pincode") String? pincode,
    @JsonKey(name: "phone") dynamic phone,
    @JsonKey(name: "lat") String? lat,
    @JsonKey(name: "lng") String? lng,
    @JsonKey(name: "fblink") dynamic fblink,
    @JsonKey(name: "instalink") String? instalink,
    @JsonKey(name: "rating") double? rating,
    @JsonKey(name: "totreviews") int? totreviews,
    @JsonKey(name: "barcode") dynamic barcode,
    @JsonKey(name: "slug") String? slug,
    @JsonKey(name: "createdon") DateTime? createdon,
    @JsonKey(name: "updatedon") dynamic updatedon,
    @JsonKey(name: "isactive") int? isactive,
    @JsonKey(name: "isperks") int? isperks,
    @JsonKey(name: "isexclusive") int? isexclusive,
    @JsonKey(name: "iswishlist") int? iswishlist,
    @JsonKey(name: "isbeenlist") int? isbeenlist,
    @JsonKey(name: "istrylist") int? istrylist,
    @JsonKey(name: "restrimglist") List<Restrimglist>? restrimglist,
    @JsonKey(name: "restroreviewlst") List<dynamic>? restroreviewlst,
  }) = _RestaurantDetailsResponse;

  factory RestaurantDetailsResponse.fromJson(Map<String, dynamic> json) =>
      _$RestaurantDetailsResponseFromJson(json);
}

@freezed
class Restrimglist with _$Restrimglist {
  const factory Restrimglist({
    @JsonKey(name: "id") int? id,
    @JsonKey(name: "restroid") int? restroid,
    @JsonKey(name: "imgfile") String? imgfile,
    @JsonKey(name: "createdon") DateTime? createdon,
  }) = _Restrimglist;

  factory Restrimglist.fromJson(Map<String, dynamic> json) =>
      _$RestrimglistFromJson(json);
}
