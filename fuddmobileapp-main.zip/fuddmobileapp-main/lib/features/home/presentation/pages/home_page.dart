import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/banner_widget.dart';
import 'package:fuud/features/home/presentation/widgets/search_widget.dart';
import 'package:fuud/features/home/presentation/widgets/wine_bars_widget.dart';
import 'package:fuud/features/home/presentation/widgets/top_10_resturents.dart';
import 'package:fuud/features/home/presentation/widgets/kids_friendly_widget.dart';
import 'package:fuud/features/home/presentation/widgets/new_open_restro_list.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_with_perks.dart';
import 'package:fuud/features/home/presentation/widgets/current_year_restro_list.dart';
import 'package:fuud/features/home/presentation/widgets/exclusive_restaurent_list.dart';
import 'package:fuud/features/home/presentation/widgets/rooftop_and_terraces_widget.dart';
import 'package:fuud/features/home/presentation/widgets/perfect_place_for_dates_widget.dart';
import 'package:fuud/features/home/presentation/widgets/dogs_friendly_resturents_widget.dart';

@RoutePage()
class HomePage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  HomePage({super.key});
  static const routeName = 'home';
  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HomeBloc>().add(const HomeEvent.featch());
    });
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.black,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      endDrawer: const AppDrawer(),
      body: Column(
        children: [
          Container(
              margin: const EdgeInsets.only(left: 8, right: 8, top: 10),
              child: SerachWidget()),
          const Gap(10),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                // borderRadius:
                //     BorderRadius.only(topLeft: Radius.circular(55))
              ),
              padding: const EdgeInsets.all(8),
              child: BlocBuilder<HomeBloc, HomeState>(
                builder: (context, state) {
                  if (state.isLoading) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return ListView(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Gap(10),
                          BannerSlider(
                            bannerAdsList: state.bannerAdsEntityList,
                          ),
                          const Gap(20),
                          TopTenResturent(
                            topTenResturantListEntity:
                                state.topTenResturentEntity,
                          ),
                          const Gap(20),
                          NewOpenedResturent(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),
                          const Gap(20),

                          RestaurantsWithPerks(
                              perksResturentEntityList:
                                  state.perksResturentEntityList),
                          // const Gap(5),
                          const Gap(20),
                          ExclusiveResturent(
                              exclusiveResturantListEntity:
                                  state.exclusiveResturantListEntityList),
                          const Gap(20),
                          WineBarResturent(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),
                          const Gap(20),
                          RooftopandTerraces(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),
                          const Gap(20),
                          PerfectPlaceForDates(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),
                          const Gap(20),
                          KidsFriendlyResturent(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),
                          const Gap(20),
                          DogsFriendlyResturent(
                            newOpenedResturantListEntity:
                                state.newOpeningResturentEntityList,
                          ),

                          const Gap(20),
                          CurrentYearResturent(
                              currentYearResturantListEntity:
                                  state.curryearrestrolistEntityList),
                          // const Gap(5),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          )
        ],
      ),
    );
  }
}
