import 'package:injectable/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/domain/usecases/perks_resturent_usecase.dart';
import 'package:fuud/features/home/domain/entities/top_10_resturents_entity.dart';
import 'package:fuud/features/home/domain/usecases/top_10_resturents_usecase.dart';
import 'package:fuud/features/home/domain/entities/restaurant_details_entity.dart';
import 'package:fuud/features/home/domain/usecases/resturant_details_usecase.dart';
import 'package:fuud/features/home/domain/usecases/all_tag_restaurent_usecase.dart';
import 'package:fuud/features/home/domain/entities/perks_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/usecases/exclusive_resturent_usecase.dart';
import 'package:fuud/features/home/domain/entities/new_opening_resturent_entity.dart';
import 'package:fuud/features/home/domain/entities/all_tags_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/usecases/new_opening_restaurent_usecase.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/usecases/current_year_resturents_usecase.dart';
import 'package:fuud/features/home/domain/entities/current_year_resturent_list_entity.dart';

part 'home_event.dart';
part 'home_state.dart';
part 'home_bloc.freezed.dart';

@injectable
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final RestaurantDetailsUsecase restaurantDetailsUsecase;
  final AllTagsRestaurantUsecase allTagsRestaurantUsecase;
  final CurrentYearRestaurantUsecase currentYearRestaurantUsecase;
  final ExclusiveRestaurantUsecase exclusiveRestaurantUsecase;
  final PerksRestaurantUsecase perksRestaurantUsecase;
  final NewRestaurantUsecase newRestaurantUsecase;
  final TopTenRestaurantUsecase tenRestaurantUsecase;
  final AdsUsecase adsUsecase;
  List<AllTagsrestrolistEntity> allTagsrestrolistEntityList = [];
  List<TopTenResturentEntity> topTenResturantListEntityList = [];
  List<ExclusiveResturantListEntity> exclusiveResturantListEntityList = [];
  List<NewOpeningResturentEntity> newOpeningResturentEntityList = [];
  List<PerksResturentEntity> perksResturentEntityList = [];
  List<CurryearrestrolistEntity> curryearrestrolistEntityList = [];
  List<AdsEntity> bannerAdsList = [];
  HomeBloc(
      {required this.restaurantDetailsUsecase,
      required this.newRestaurantUsecase,
      required this.allTagsRestaurantUsecase,
      required this.currentYearRestaurantUsecase,
      required this.exclusiveRestaurantUsecase,
      required this.perksRestaurantUsecase,
      required this.tenRestaurantUsecase,
      required this.adsUsecase})
      : super(HomeState.initial()) {
    on<HomeFeatchDetails>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await restaurantDetailsUsecase.call(
          RestaurantDetailsParams(id: event.resturentId, userId: event.id));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        print(
            'function Details rid: ${event.resturentId} uid: ${event.id} name: ${r.name}');
        emit(state.copyWith(restaurantDetailsEntity: r, isLoading: false));
      });
    });
    on<HomeFeatch>((event, emit) async {
      emit(state.copyWith(isLoading: true));

      final bannerAds =
          await adsUsecase.call(const AdsParams(adsposition: 'banner'));
      bannerAds.fold((l) => null, (r) => bannerAdsList = r);
      final userId = await getIntValue('id') ?? 0;
      final allTagResturentList = await allTagsRestaurantUsecase
          .call(AllTagsRestaurantParams(count: 10, userId: userId));
      allTagResturentList.fold((l) {}, (r) {
        allTagsrestrolistEntityList = r;
        for (var element in r) {
          print('banner object ${element.restrolist!.first.mainimg}');
        }
      });

      final currentYearRestaurantList = await currentYearRestaurantUsecase
          .call(CurrentYearRestaurantParams(count: 10, userId: userId));
      currentYearRestaurantList.fold((l) {}, (r) {
        curryearrestrolistEntityList = r;
      });
      final topTenResturents = await tenRestaurantUsecase
          .call(TopTenRestaurantParams(count: 10, userId: userId));
      topTenResturents.fold((l) => null, (r) {
        topTenResturantListEntityList = r;
      });
      final exclusiveRestaurantList = await exclusiveRestaurantUsecase
          .call(ExclusiveRestaurantParams(count: 10, userId: userId));
      exclusiveRestaurantList.fold((l) {}, (r) {
        exclusiveResturantListEntityList = r;
      });

      final perksRestaurantList = await perksRestaurantUsecase
          .call(PerksRestaurantParams(count: 10, userId: userId));
      perksRestaurantList.fold((l) {
        print('perks resturent error');
      }, (r) {
        print('perks resturent sucess');
        perksResturentEntityList = r;
      });

      final newRestaurantList = await newRestaurantUsecase
          .call(NewRestaurantParams(count: 10, userId: userId));
      newRestaurantList.fold((l) {}, (r) {
        newOpeningResturentEntityList = r;
      });
      emit(state.copyWith(
        bannerAdsEntityList: bannerAdsList,
        newOpeningResturentEntityList: newOpeningResturentEntityList,
        allTagsrestrolistEntityList: allTagsrestrolistEntityList,
        curryearrestrolistEntityList: curryearrestrolistEntityList,
        exclusiveResturantListEntityList: exclusiveResturantListEntityList,
        perksResturentEntityList: perksResturentEntityList,
        topTenResturentEntity: topTenResturantListEntityList,
        isLoading: false,
      ));
    });
  }
}
