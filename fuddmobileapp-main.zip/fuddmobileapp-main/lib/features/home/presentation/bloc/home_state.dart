part of 'home_bloc.dart';

@freezed
class HomeState with _$HomeState {
  factory HomeState({
    required RestaurantDetailsEntity? restaurantDetailsEntity,
    required bool isLoading,
    required List<AllTagsrestrolistEntity> allTagsrestrolistEntityList,
    required List<CurryearrestrolistEntity> curryearrestrolistEntityList,
    required List<ExclusiveResturantListEntity>
        exclusiveResturantListEntityList,
    required List<TopTenResturentEntity> topTenResturentEntity,
    required List<NewOpeningResturentEntity> newOpeningResturentEntityList,
    required List<PerksResturentEntity> perksResturentEntityList,
    required List<AdsEntity> bannerAdsEntityList,
  }) = _HomeState;
  factory HomeState.initial() => HomeState(
      restaurantDetailsEntity: null,
      isLoading: false,
      allTagsrestrolistEntityList: [],
      curryearrestrolistEntityList: [],
      exclusiveResturantListEntityList: [],
      newOpeningResturentEntityList: [],
      perksResturentEntityList: [],
      bannerAdsEntityList: [],
      topTenResturentEntity: []);
}
