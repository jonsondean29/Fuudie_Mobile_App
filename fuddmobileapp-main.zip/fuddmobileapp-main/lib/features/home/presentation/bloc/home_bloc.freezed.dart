// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$HomeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeEventCopyWith<$Res> {
  factory $HomeEventCopyWith(HomeEvent value, $Res Function(HomeEvent) then) =
      _$HomeEventCopyWithImpl<$Res, HomeEvent>;
}

/// @nodoc
class _$HomeEventCopyWithImpl<$Res, $Val extends HomeEvent>
    implements $HomeEventCopyWith<$Res> {
  _$HomeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'HomeEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements HomeEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$HomeFeatchDetailsImplCopyWith<$Res> {
  factory _$$HomeFeatchDetailsImplCopyWith(_$HomeFeatchDetailsImpl value,
          $Res Function(_$HomeFeatchDetailsImpl) then) =
      __$$HomeFeatchDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int id, int resturentId});
}

/// @nodoc
class __$$HomeFeatchDetailsImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$HomeFeatchDetailsImpl>
    implements _$$HomeFeatchDetailsImplCopyWith<$Res> {
  __$$HomeFeatchDetailsImplCopyWithImpl(_$HomeFeatchDetailsImpl _value,
      $Res Function(_$HomeFeatchDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? resturentId = null,
  }) {
    return _then(_$HomeFeatchDetailsImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      resturentId: null == resturentId
          ? _value.resturentId
          : resturentId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$HomeFeatchDetailsImpl implements HomeFeatchDetails {
  const _$HomeFeatchDetailsImpl({required this.id, required this.resturentId});

  @override
  final int id;
  @override
  final int resturentId;

  @override
  String toString() {
    return 'HomeEvent.featchDetails(id: $id, resturentId: $resturentId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HomeFeatchDetailsImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.resturentId, resturentId) ||
                other.resturentId == resturentId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, resturentId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HomeFeatchDetailsImplCopyWith<_$HomeFeatchDetailsImpl> get copyWith =>
      __$$HomeFeatchDetailsImplCopyWithImpl<_$HomeFeatchDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
  }) {
    return featchDetails(id, resturentId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
  }) {
    return featchDetails?.call(id, resturentId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    required TResult orElse(),
  }) {
    if (featchDetails != null) {
      return featchDetails(id, resturentId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
  }) {
    return featchDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
  }) {
    return featchDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    required TResult orElse(),
  }) {
    if (featchDetails != null) {
      return featchDetails(this);
    }
    return orElse();
  }
}

abstract class HomeFeatchDetails implements HomeEvent {
  const factory HomeFeatchDetails(
      {required final int id,
      required final int resturentId}) = _$HomeFeatchDetailsImpl;

  int get id;
  int get resturentId;
  @JsonKey(ignore: true)
  _$$HomeFeatchDetailsImplCopyWith<_$HomeFeatchDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$HomeFeatchImplCopyWith<$Res> {
  factory _$$HomeFeatchImplCopyWith(
          _$HomeFeatchImpl value, $Res Function(_$HomeFeatchImpl) then) =
      __$$HomeFeatchImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$HomeFeatchImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$HomeFeatchImpl>
    implements _$$HomeFeatchImplCopyWith<$Res> {
  __$$HomeFeatchImplCopyWithImpl(
      _$HomeFeatchImpl _value, $Res Function(_$HomeFeatchImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$HomeFeatchImpl implements HomeFeatch {
  const _$HomeFeatchImpl();

  @override
  String toString() {
    return 'HomeEvent.featch()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$HomeFeatchImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
  }) {
    return featch();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
  }) {
    return featch?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
  }) {
    return featch(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
  }) {
    return featch?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch(this);
    }
    return orElse();
  }
}

abstract class HomeFeatch implements HomeEvent {
  const factory HomeFeatch() = _$HomeFeatchImpl;
}

/// @nodoc
mixin _$HomeState {
  RestaurantDetailsEntity? get restaurantDetailsEntity =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  List<AllTagsrestrolistEntity> get allTagsrestrolistEntityList =>
      throw _privateConstructorUsedError;
  List<CurryearrestrolistEntity> get curryearrestrolistEntityList =>
      throw _privateConstructorUsedError;
  List<ExclusiveResturantListEntity> get exclusiveResturantListEntityList =>
      throw _privateConstructorUsedError;
  List<TopTenResturentEntity> get topTenResturentEntity =>
      throw _privateConstructorUsedError;
  List<NewOpeningResturentEntity> get newOpeningResturentEntityList =>
      throw _privateConstructorUsedError;
  List<PerksResturentEntity> get perksResturentEntityList =>
      throw _privateConstructorUsedError;
  List<AdsEntity> get bannerAdsEntityList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $HomeStateCopyWith<HomeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeStateCopyWith<$Res> {
  factory $HomeStateCopyWith(HomeState value, $Res Function(HomeState) then) =
      _$HomeStateCopyWithImpl<$Res, HomeState>;
  @useResult
  $Res call(
      {RestaurantDetailsEntity? restaurantDetailsEntity,
      bool isLoading,
      List<AllTagsrestrolistEntity> allTagsrestrolistEntityList,
      List<CurryearrestrolistEntity> curryearrestrolistEntityList,
      List<ExclusiveResturantListEntity> exclusiveResturantListEntityList,
      List<TopTenResturentEntity> topTenResturentEntity,
      List<NewOpeningResturentEntity> newOpeningResturentEntityList,
      List<PerksResturentEntity> perksResturentEntityList,
      List<AdsEntity> bannerAdsEntityList});
}

/// @nodoc
class _$HomeStateCopyWithImpl<$Res, $Val extends HomeState>
    implements $HomeStateCopyWith<$Res> {
  _$HomeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? restaurantDetailsEntity = freezed,
    Object? isLoading = null,
    Object? allTagsrestrolistEntityList = null,
    Object? curryearrestrolistEntityList = null,
    Object? exclusiveResturantListEntityList = null,
    Object? topTenResturentEntity = null,
    Object? newOpeningResturentEntityList = null,
    Object? perksResturentEntityList = null,
    Object? bannerAdsEntityList = null,
  }) {
    return _then(_value.copyWith(
      restaurantDetailsEntity: freezed == restaurantDetailsEntity
          ? _value.restaurantDetailsEntity
          : restaurantDetailsEntity // ignore: cast_nullable_to_non_nullable
              as RestaurantDetailsEntity?,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      allTagsrestrolistEntityList: null == allTagsrestrolistEntityList
          ? _value.allTagsrestrolistEntityList
          : allTagsrestrolistEntityList // ignore: cast_nullable_to_non_nullable
              as List<AllTagsrestrolistEntity>,
      curryearrestrolistEntityList: null == curryearrestrolistEntityList
          ? _value.curryearrestrolistEntityList
          : curryearrestrolistEntityList // ignore: cast_nullable_to_non_nullable
              as List<CurryearrestrolistEntity>,
      exclusiveResturantListEntityList: null == exclusiveResturantListEntityList
          ? _value.exclusiveResturantListEntityList
          : exclusiveResturantListEntityList // ignore: cast_nullable_to_non_nullable
              as List<ExclusiveResturantListEntity>,
      topTenResturentEntity: null == topTenResturentEntity
          ? _value.topTenResturentEntity
          : topTenResturentEntity // ignore: cast_nullable_to_non_nullable
              as List<TopTenResturentEntity>,
      newOpeningResturentEntityList: null == newOpeningResturentEntityList
          ? _value.newOpeningResturentEntityList
          : newOpeningResturentEntityList // ignore: cast_nullable_to_non_nullable
              as List<NewOpeningResturentEntity>,
      perksResturentEntityList: null == perksResturentEntityList
          ? _value.perksResturentEntityList
          : perksResturentEntityList // ignore: cast_nullable_to_non_nullable
              as List<PerksResturentEntity>,
      bannerAdsEntityList: null == bannerAdsEntityList
          ? _value.bannerAdsEntityList
          : bannerAdsEntityList // ignore: cast_nullable_to_non_nullable
              as List<AdsEntity>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HomeStateImplCopyWith<$Res>
    implements $HomeStateCopyWith<$Res> {
  factory _$$HomeStateImplCopyWith(
          _$HomeStateImpl value, $Res Function(_$HomeStateImpl) then) =
      __$$HomeStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {RestaurantDetailsEntity? restaurantDetailsEntity,
      bool isLoading,
      List<AllTagsrestrolistEntity> allTagsrestrolistEntityList,
      List<CurryearrestrolistEntity> curryearrestrolistEntityList,
      List<ExclusiveResturantListEntity> exclusiveResturantListEntityList,
      List<TopTenResturentEntity> topTenResturentEntity,
      List<NewOpeningResturentEntity> newOpeningResturentEntityList,
      List<PerksResturentEntity> perksResturentEntityList,
      List<AdsEntity> bannerAdsEntityList});
}

/// @nodoc
class __$$HomeStateImplCopyWithImpl<$Res>
    extends _$HomeStateCopyWithImpl<$Res, _$HomeStateImpl>
    implements _$$HomeStateImplCopyWith<$Res> {
  __$$HomeStateImplCopyWithImpl(
      _$HomeStateImpl _value, $Res Function(_$HomeStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? restaurantDetailsEntity = freezed,
    Object? isLoading = null,
    Object? allTagsrestrolistEntityList = null,
    Object? curryearrestrolistEntityList = null,
    Object? exclusiveResturantListEntityList = null,
    Object? topTenResturentEntity = null,
    Object? newOpeningResturentEntityList = null,
    Object? perksResturentEntityList = null,
    Object? bannerAdsEntityList = null,
  }) {
    return _then(_$HomeStateImpl(
      restaurantDetailsEntity: freezed == restaurantDetailsEntity
          ? _value.restaurantDetailsEntity
          : restaurantDetailsEntity // ignore: cast_nullable_to_non_nullable
              as RestaurantDetailsEntity?,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      allTagsrestrolistEntityList: null == allTagsrestrolistEntityList
          ? _value._allTagsrestrolistEntityList
          : allTagsrestrolistEntityList // ignore: cast_nullable_to_non_nullable
              as List<AllTagsrestrolistEntity>,
      curryearrestrolistEntityList: null == curryearrestrolistEntityList
          ? _value._curryearrestrolistEntityList
          : curryearrestrolistEntityList // ignore: cast_nullable_to_non_nullable
              as List<CurryearrestrolistEntity>,
      exclusiveResturantListEntityList: null == exclusiveResturantListEntityList
          ? _value._exclusiveResturantListEntityList
          : exclusiveResturantListEntityList // ignore: cast_nullable_to_non_nullable
              as List<ExclusiveResturantListEntity>,
      topTenResturentEntity: null == topTenResturentEntity
          ? _value._topTenResturentEntity
          : topTenResturentEntity // ignore: cast_nullable_to_non_nullable
              as List<TopTenResturentEntity>,
      newOpeningResturentEntityList: null == newOpeningResturentEntityList
          ? _value._newOpeningResturentEntityList
          : newOpeningResturentEntityList // ignore: cast_nullable_to_non_nullable
              as List<NewOpeningResturentEntity>,
      perksResturentEntityList: null == perksResturentEntityList
          ? _value._perksResturentEntityList
          : perksResturentEntityList // ignore: cast_nullable_to_non_nullable
              as List<PerksResturentEntity>,
      bannerAdsEntityList: null == bannerAdsEntityList
          ? _value._bannerAdsEntityList
          : bannerAdsEntityList // ignore: cast_nullable_to_non_nullable
              as List<AdsEntity>,
    ));
  }
}

/// @nodoc

class _$HomeStateImpl implements _HomeState {
  _$HomeStateImpl(
      {required this.restaurantDetailsEntity,
      required this.isLoading,
      required final List<AllTagsrestrolistEntity> allTagsrestrolistEntityList,
      required final List<CurryearrestrolistEntity>
          curryearrestrolistEntityList,
      required final List<ExclusiveResturantListEntity>
          exclusiveResturantListEntityList,
      required final List<TopTenResturentEntity> topTenResturentEntity,
      required final List<NewOpeningResturentEntity>
          newOpeningResturentEntityList,
      required final List<PerksResturentEntity> perksResturentEntityList,
      required final List<AdsEntity> bannerAdsEntityList})
      : _allTagsrestrolistEntityList = allTagsrestrolistEntityList,
        _curryearrestrolistEntityList = curryearrestrolistEntityList,
        _exclusiveResturantListEntityList = exclusiveResturantListEntityList,
        _topTenResturentEntity = topTenResturentEntity,
        _newOpeningResturentEntityList = newOpeningResturentEntityList,
        _perksResturentEntityList = perksResturentEntityList,
        _bannerAdsEntityList = bannerAdsEntityList;

  @override
  final RestaurantDetailsEntity? restaurantDetailsEntity;
  @override
  final bool isLoading;
  final List<AllTagsrestrolistEntity> _allTagsrestrolistEntityList;
  @override
  List<AllTagsrestrolistEntity> get allTagsrestrolistEntityList {
    if (_allTagsrestrolistEntityList is EqualUnmodifiableListView)
      return _allTagsrestrolistEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_allTagsrestrolistEntityList);
  }

  final List<CurryearrestrolistEntity> _curryearrestrolistEntityList;
  @override
  List<CurryearrestrolistEntity> get curryearrestrolistEntityList {
    if (_curryearrestrolistEntityList is EqualUnmodifiableListView)
      return _curryearrestrolistEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_curryearrestrolistEntityList);
  }

  final List<ExclusiveResturantListEntity> _exclusiveResturantListEntityList;
  @override
  List<ExclusiveResturantListEntity> get exclusiveResturantListEntityList {
    if (_exclusiveResturantListEntityList is EqualUnmodifiableListView)
      return _exclusiveResturantListEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_exclusiveResturantListEntityList);
  }

  final List<TopTenResturentEntity> _topTenResturentEntity;
  @override
  List<TopTenResturentEntity> get topTenResturentEntity {
    if (_topTenResturentEntity is EqualUnmodifiableListView)
      return _topTenResturentEntity;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_topTenResturentEntity);
  }

  final List<NewOpeningResturentEntity> _newOpeningResturentEntityList;
  @override
  List<NewOpeningResturentEntity> get newOpeningResturentEntityList {
    if (_newOpeningResturentEntityList is EqualUnmodifiableListView)
      return _newOpeningResturentEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_newOpeningResturentEntityList);
  }

  final List<PerksResturentEntity> _perksResturentEntityList;
  @override
  List<PerksResturentEntity> get perksResturentEntityList {
    if (_perksResturentEntityList is EqualUnmodifiableListView)
      return _perksResturentEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_perksResturentEntityList);
  }

  final List<AdsEntity> _bannerAdsEntityList;
  @override
  List<AdsEntity> get bannerAdsEntityList {
    if (_bannerAdsEntityList is EqualUnmodifiableListView)
      return _bannerAdsEntityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_bannerAdsEntityList);
  }

  @override
  String toString() {
    return 'HomeState(restaurantDetailsEntity: $restaurantDetailsEntity, isLoading: $isLoading, allTagsrestrolistEntityList: $allTagsrestrolistEntityList, curryearrestrolistEntityList: $curryearrestrolistEntityList, exclusiveResturantListEntityList: $exclusiveResturantListEntityList, topTenResturentEntity: $topTenResturentEntity, newOpeningResturentEntityList: $newOpeningResturentEntityList, perksResturentEntityList: $perksResturentEntityList, bannerAdsEntityList: $bannerAdsEntityList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HomeStateImpl &&
            (identical(
                    other.restaurantDetailsEntity, restaurantDetailsEntity) ||
                other.restaurantDetailsEntity == restaurantDetailsEntity) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            const DeepCollectionEquality().equals(
                other._allTagsrestrolistEntityList,
                _allTagsrestrolistEntityList) &&
            const DeepCollectionEquality().equals(
                other._curryearrestrolistEntityList,
                _curryearrestrolistEntityList) &&
            const DeepCollectionEquality().equals(
                other._exclusiveResturantListEntityList,
                _exclusiveResturantListEntityList) &&
            const DeepCollectionEquality()
                .equals(other._topTenResturentEntity, _topTenResturentEntity) &&
            const DeepCollectionEquality().equals(
                other._newOpeningResturentEntityList,
                _newOpeningResturentEntityList) &&
            const DeepCollectionEquality().equals(
                other._perksResturentEntityList, _perksResturentEntityList) &&
            const DeepCollectionEquality()
                .equals(other._bannerAdsEntityList, _bannerAdsEntityList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      restaurantDetailsEntity,
      isLoading,
      const DeepCollectionEquality().hash(_allTagsrestrolistEntityList),
      const DeepCollectionEquality().hash(_curryearrestrolistEntityList),
      const DeepCollectionEquality().hash(_exclusiveResturantListEntityList),
      const DeepCollectionEquality().hash(_topTenResturentEntity),
      const DeepCollectionEquality().hash(_newOpeningResturentEntityList),
      const DeepCollectionEquality().hash(_perksResturentEntityList),
      const DeepCollectionEquality().hash(_bannerAdsEntityList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      __$$HomeStateImplCopyWithImpl<_$HomeStateImpl>(this, _$identity);
}

abstract class _HomeState implements HomeState {
  factory _HomeState(
      {required final RestaurantDetailsEntity? restaurantDetailsEntity,
      required final bool isLoading,
      required final List<AllTagsrestrolistEntity> allTagsrestrolistEntityList,
      required final List<CurryearrestrolistEntity>
          curryearrestrolistEntityList,
      required final List<ExclusiveResturantListEntity>
          exclusiveResturantListEntityList,
      required final List<TopTenResturentEntity> topTenResturentEntity,
      required final List<NewOpeningResturentEntity>
          newOpeningResturentEntityList,
      required final List<PerksResturentEntity> perksResturentEntityList,
      required final List<AdsEntity> bannerAdsEntityList}) = _$HomeStateImpl;

  @override
  RestaurantDetailsEntity? get restaurantDetailsEntity;
  @override
  bool get isLoading;
  @override
  List<AllTagsrestrolistEntity> get allTagsrestrolistEntityList;
  @override
  List<CurryearrestrolistEntity> get curryearrestrolistEntityList;
  @override
  List<ExclusiveResturantListEntity> get exclusiveResturantListEntityList;
  @override
  List<TopTenResturentEntity> get topTenResturentEntity;
  @override
  List<NewOpeningResturentEntity> get newOpeningResturentEntityList;
  @override
  List<PerksResturentEntity> get perksResturentEntityList;
  @override
  List<AdsEntity> get bannerAdsEntityList;
  @override
  @JsonKey(ignore: true)
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
