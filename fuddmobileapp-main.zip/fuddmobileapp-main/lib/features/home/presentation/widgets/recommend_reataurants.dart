import 'package:flutter/material.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';

class RecommendRestaurants extends StatelessWidget {
  RecommendRestaurants({super.key});
  final List imageList = [
    'assets/images/images_10.jpeg',
    'assets/images/images_9.jpeg',
    'assets/images/images_8.jpeg',
    'assets/images/images_7.jpeg',
    'assets/images/images_6.jpeg',
    'assets/images/images_1.jpeg',
    'assets/images/images_2.jpeg',
    'assets/images/images_3.jpeg',
    'assets/images/images_4.jpeg',
    'assets/images/images_5.jpeg',
  ];
  final List<String> londonRestaurantsList1 = [
    "The Gourmet Grove",
    "Savory Seasons",
    "Culinary Canvas",
    "Epicurean Junction",
    "The Spice Route",
    "Bistro Bliss",
    "Gastronome's Haven",
    "Flavorsome Fusion",
    "The Artful Palate",
    "Piquant Piazza",
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Recommend (ads)'),
            TextButton(
                onPressed: () {},
                child: const Text(
                  'See More',
                  style: TextStyle(color: Colors.black),
                ))
          ],
        ),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: 10,
              itemBuilder: (context, index) {
                // final randomNumber = Random().nextInt(3);
                return RestaurantsCard(
                  resturentId: 0,
                  isPerksResturent: false,
                  // isNetworkImage: false,
                  name: londonRestaurantsList1[index],
                  image: imageList[index],
                );
              }),
        ),
      ],
    );
  }
}
