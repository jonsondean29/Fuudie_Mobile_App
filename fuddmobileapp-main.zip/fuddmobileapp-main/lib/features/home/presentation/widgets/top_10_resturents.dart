import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import 'package:fuud/features/home/domain/entities/top_10_resturents_entity.dart';

class TopTenResturent extends StatelessWidget {
  const TopTenResturent({super.key, required this.topTenResturantListEntity});
  final List<TopTenResturentEntity> topTenResturantListEntity;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                const Text(
                  'Top 10 in London',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Column(
                  children: [
                    Image.asset(
                      'assets/images/recipes.png',
                      height: 40,
                      color: const Color(0xff4123be),
                    ),
                    const Gap(10)
                  ],
                )
              ],
            ),
            const Text('See More',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))
          ],
        ),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: topTenResturantListEntity.length,
              itemBuilder: (context, index) {
                print('resturent len ${topTenResturantListEntity.length}');
                return RestaurantsCard(
                  resturentId: topTenResturantListEntity[index].id ?? 0,
                  isPerksResturent:
                      topTenResturantListEntity[index].isperks == 1,
                  // isNetworkImage: true,
                  name: topTenResturantListEntity[index].name ?? "",
                  image: topTenResturantListEntity[index].mainimg != null
                      ? "${Apis.baseUrl}/${topTenResturantListEntity[index].mainimg}"
                      : "assets/images/images_11.jpeg",
                );
              }),
        ),
      ],
    );
  }
}
