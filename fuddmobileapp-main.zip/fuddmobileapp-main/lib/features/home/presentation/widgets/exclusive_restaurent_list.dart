import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';

class ExclusiveResturent extends StatelessWidget {
  const ExclusiveResturent(
      {super.key, required this.exclusiveResturantListEntity});
  final List<ExclusiveResturantListEntity> exclusiveResturantListEntity;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Vegan Vibes',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('See More',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))
          ],
        ),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: exclusiveResturantListEntity.length,
              itemBuilder: (context, index) {
                print('resturent len ${exclusiveResturantListEntity.length}');
                return RestaurantsCard(
                  resturentId: exclusiveResturantListEntity[index].id ?? 0,
                  isPerksResturent:
                      exclusiveResturantListEntity[index].isperks == 1,
                  name: exclusiveResturantListEntity[index].name ?? "",
                  image: exclusiveResturantListEntity[index].mainimg != null
                      ? "${Apis.baseUrl}/${exclusiveResturantListEntity[index].mainimg}"
                      : "assets/images/images_11.jpeg",
                );
              }),
        ),
      ],
    );
  }
}
