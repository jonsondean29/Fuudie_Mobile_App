import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import 'package:fuud/features/home/domain/entities/new_opening_resturent_entity.dart';

class WineBarResturent extends StatelessWidget {
  const WineBarResturent(
      {super.key, required this.newOpenedResturantListEntity});
  final List<NewOpeningResturentEntity> newOpenedResturantListEntity;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Wine Bars',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text('See More',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))
          ],
        ),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: newOpenedResturantListEntity.length,
              itemBuilder: (context, index) {
                print('resturent len ${newOpenedResturantListEntity.length}');
                return RestaurantsCard(
                  resturentId: newOpenedResturantListEntity[index].id ?? 0,
                  isPerksResturent:
                      newOpenedResturantListEntity[index].isperks == 1,
                  // isNetworkImage: true,
                  name: newOpenedResturantListEntity[index].name ?? "",
                  image: newOpenedResturantListEntity[index].mainimg != null
                      ? "${Apis.baseUrl}/${newOpenedResturantListEntity[index].mainimg}"
                      : "assets/images/images_11.jpeg",
                );
              }),
        ),
      ],
    );
  }
}
