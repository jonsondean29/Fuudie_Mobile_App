import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';

@RoutePage()
class ResturantDetailsPage extends StatefulWidget {
  const ResturantDetailsPage({super.key});
  static const routeName = '/restuarantDetails';

  @override
  State<ResturantDetailsPage> createState() => _ResturantDetailsPageState();
}

class _ResturantDetailsPageState extends State<ResturantDetailsPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.black,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      endDrawer: const AppDrawer(),
      body: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          if (state.isLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          return state.restaurantDetailsEntity != null
              ? Column(
                  children: [
                    SizedBox(
                      height: 50,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const BackButton(
                            color: Colors.white,
                          ),
                          state.restaurantDetailsEntity != null
                              ? Text(
                                  state.restaurantDetailsEntity!.name ?? '',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18),
                                )
                              : const Text(''),
                          GestureDetector(
                            onTap: () {
                              context.router.push(MapRouteRoute(
                                  lat: double.parse(
                                      state.restaurantDetailsEntity!.lat ??
                                          "0"),
                                  long: double.parse(
                                      state.restaurantDetailsEntity!.lng ??
                                          "0")));
                            },
                            child: const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: ImageIcon(
                                AssetImage('assets/images/icon-ma.png'),
                                color: Colors.white,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        children: [
                          Column(
                            children: [
                              state.restaurantDetailsEntity == null
                                  ? Container()
                                  : Column(
                                      children: [
                                        CarouselSlider(
                                          options: CarouselOptions(
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.4,
                                            autoPlay: true,
                                            onPageChanged: (index, reason) {
                                              setState(() {
                                                currentIndex = index;
                                              });
                                            },
                                            enlargeCenterPage: true,
                                            viewportFraction: 1,
                                          ),
                                          items: state.restaurantDetailsEntity
                                              ?.restrimglist
                                              ?.map((i) {
                                            return Builder(
                                              builder: (BuildContext context) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: AppColors.black,
                                                  ),
                                                  height: 60,
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        const BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    40)),
                                                    child: Image.network(
                                                      '${Apis.baseUrl}/${i.imgfile}',
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                );
                                              },
                                            );
                                          }).toList(),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: state
                                              .restaurantDetailsEntity!
                                              .restrimglist!
                                              .asMap()
                                              .entries
                                              .map(
                                            (entry) {
                                              final int index = entry.key;
                                              return currentIndex == index
                                                  ? Container(
                                                      width: 8.0,
                                                      height: 8.0,
                                                      margin: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 10.0,
                                                          horizontal: 2.0),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: currentIndex ==
                                                                index
                                                            ? Colors.white
                                                            : Colors.grey,
                                                      ),
                                                    )
                                                  : Container(
                                                      width: 5.0,
                                                      height: 5.0,
                                                      margin: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 10.0,
                                                          horizontal: 2.0),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: currentIndex ==
                                                                index
                                                            ? AppColors.black
                                                            : Colors.grey,
                                                      ),
                                                    );
                                            },
                                          ).toList(),
                                        ),
                                      ],
                                    ),
                              // Container(
                              //   color: Colors.white,
                              //   child: Row(
                              //     mainAxisAlignment: MainAxisAlignment.center,
                              //     children: [1, 2, 3].asMap().entries.map((entry) {
                              //       final int index = entry.key;
                              //       return 1 == index
                              //           ? Container(
                              //               width: 8.0,
                              //               height: 8.0,
                              //               margin: const EdgeInsets.symmetric(
                              //                   vertical: 10.0, horizontal: 2.0),
                              //               decoration: BoxDecoration(
                              //                 shape: BoxShape.circle,
                              //                 color: 0 == index
                              //                     ? AppColors.whiteColor
                              //                     : Colors.grey,
                              //               ),
                              //             )
                              //           : Container(
                              //               width: 5.0,
                              //               height: 5.0,
                              //               margin: const EdgeInsets.symmetric(
                              //                   vertical: 10.0, horizontal: 2.0),
                              //               decoration: BoxDecoration(
                              //                 shape: BoxShape.circle,
                              //                 color: 1 == index
                              //                     ? AppColors.whiteColor
                              //                     : Colors.grey,
                              //               ),
                              //             );
                              //     }).toList(),
                              //   ),
                              // ),
                              Container(
                                padding: const EdgeInsets.all(10),
                                color: Colors.white,
                                child: Column(
                                  children: [
                                    const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Column(
                                              children: [
                                                ImageIcon(
                                                  AssetImage(
                                                    'assets/images/heart.png',
                                                  ),
                                                  size: 45,
                                                  color: AppColors.blueColor,
                                                ),
                                                Text('Favourite')
                                              ],
                                            ),
                                            Gap(20),
                                            Column(
                                              children: [
                                                ImageIcon(
                                                  AssetImage(
                                                      'assets/images/check.png'),
                                                  color: AppColors.blueColor,
                                                  size: 45,
                                                ),
                                                Text('Tested')
                                              ],
                                            ),
                                            Gap(20),
                                            Column(
                                              children: [
                                                ImageIcon(
                                                  AssetImage(
                                                    'assets/images/flag.png',
                                                  ),
                                                  size: 45,
                                                  color: AppColors.blueColor,
                                                ),
                                                Text('Go Try')
                                              ],
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                    const Gap(10),
                                    state.restaurantDetailsEntity != null
                                        ? Row(
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.totfav} '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: ' Favourite, ')
                                                  ],
                                                ),
                                              ),
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.isbeenlist}  '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: ' Tested, ')
                                                  ],
                                                ),
                                              ),
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.tottry} '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: 'Go Try')
                                                  ],
                                                ),
                                              ),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Gap(10),
                                    state.restaurantDetailsEntity != null
                                        ? Text(state.restaurantDetailsEntity!
                                                .description ??
                                            "")
                                        : const SizedBox(),
                                    const Divider(),
                                    const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Tags :',
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                    const Gap(5),
                                    state.restaurantDetailsEntity!.tags != null
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: Wrap(
                                                    alignment:
                                                        WrapAlignment.start,
                                                    spacing: 5,
                                                    direction: Axis.horizontal,
                                                    children: List.generate(
                                                      state
                                                          .restaurantDetailsEntity!
                                                          .tags!
                                                          .split(',')
                                                          .length,
                                                      (index) => tagWidget(state
                                                          .restaurantDetailsEntity!
                                                          .tags!
                                                          .split(',')[index]),
                                                    )),
                                              ),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Divider(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            const Gap(10),
                                            Text(
                                              "${state.restaurantDetailsEntity!.rating ?? 0}",
                                              style: const TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Gap(20),
                                            const Text(
                                                "Review aren't verified"),
                                          ],
                                        ),
                                        IconButton(
                                            onPressed: () {},
                                            icon:
                                                const Icon(Icons.info_outline))
                                      ],
                                    ),
                                    RatingBar.builder(
                                      initialRating: state
                                              .restaurantDetailsEntity!
                                              .rating ??
                                          0,
                                      minRating: 1,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 5,
                                      itemPadding: const EdgeInsets.symmetric(
                                          horizontal: 4.0),
                                      itemBuilder: (context, _) => const Icon(
                                        Icons.star,
                                        color: Colors.amber,
                                      ),
                                      onRatingUpdate: (rating) {
                                        print(rating);
                                      },
                                    ),
                                    // Image.asset('assets/images/details.png'),
                                    // const Gap(10),
                                    // const Text(
                                    //     "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"),
                                    const Gap(10),
                                    const Divider(),
                                    const Gap(10),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                            "Address: \n ${state.restaurantDetailsEntity!.location ?? ''}, ${state.restaurantDetailsEntity!.city ?? ''}, ${state.restaurantDetailsEntity!.state ?? ''}"),
                                      ],
                                    ),
                                    state.restaurantDetailsEntity!.phone != null
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(state
                                                      .restaurantDetailsEntity!
                                                      .phone ??
                                                  ''),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Gap(5),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            _launchURL(state
                                                    .restaurantDetailsEntity!
                                                    .instalink ??
                                                '');
                                          },
                                          child: const Text(
                                            'Check it out on instagram',
                                            style: TextStyle(
                                              decorationColor: Colors.blue,
                                              decoration:
                                                  TextDecoration.underline,
                                              color: Colors.blue,
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              // Container(
                              //     color: Colors.white,
                              //     height: 100,
                              //     child: const TabViewWidget()),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : const SizedBox();
        },
      ),
    );
  }
}

Widget tagWidget(String name) {
  return Padding(
    padding: const EdgeInsets.all(4.0),
    child: Container(
      decoration: BoxDecoration(
        border: Border.all(width: 1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Padding(
        padding: const EdgeInsets.only(top: 5, bottom: 5, left: 10, right: 10),
        child: Text(name),
      ),
    ),
  );
}

void _launchURL(String url) async {
  /*if (await canLaunchUrl(Uri.parse(url))) {
    await launchUrl(Uri.parse(url));
  } else {
    throw 'Could not launch $url';
  }*/
}
