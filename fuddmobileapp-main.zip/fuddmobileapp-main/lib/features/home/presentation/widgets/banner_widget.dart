import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';

class BannerSlider extends StatefulWidget {
  final List<AdsEntity> bannerAdsList;
  const BannerSlider({
    Key? key,
    required this.bannerAdsList,
  }) : super(key: key);

  @override
  BannerSliderState createState() => BannerSliderState();
}

class BannerSliderState extends State<BannerSlider> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          options: CarouselOptions(
            height: 250.0,
            autoPlay: true,
            onPageChanged: (index, reason) {
              setState(() {
                _currentIndex = index;
              });
            },
            enlargeCenterPage: true,
            viewportFraction: 0.8,
          ),
          items: widget.bannerAdsList.map(
            (i) {
              // print("Banner Image ${Apis.baseUrl}/${i.mainimg}");
              return GestureDetector(
                onTap: () async {
                  final userid = await getIntValue('id') ?? 0;
                  if (context.mounted) {
                    context.read<HomeBloc>().add(
                        HomeFeatchDetails(id: userid, resturentId: i.id ?? 0));
                    context.router.push(const ResturantDetailsRoute());
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.black,
                  ),
                  height: 60,
                  width: MediaQuery.of(context).size.width,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(0.0),
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: NetworkImage(
                            "${Apis.baseUrl}/${i.mainimg}",
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            color: Colors.black.withOpacity(0.6),
                            child: const Padding(
                              padding: EdgeInsets.all(2.0),
                              child: Text(
                                'Ad  ',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ).toList(),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: widget.bannerAdsList.asMap().entries.map(
            (entry) {
              final int index = entry.key;
              return _currentIndex == index
                  ? Container(
                      width: 8.0,
                      height: 8.0,
                      margin: const EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 2.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentIndex == index
                            ? AppColors.black
                            : Colors.grey,
                      ),
                    )
                  : Container(
                      width: 5.0,
                      height: 5.0,
                      margin: const EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 2.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentIndex == index
                            ? AppColors.black
                            : Colors.grey,
                      ),
                    );
            },
          ).toList(),
        ),
      ],
    );
  }
}
