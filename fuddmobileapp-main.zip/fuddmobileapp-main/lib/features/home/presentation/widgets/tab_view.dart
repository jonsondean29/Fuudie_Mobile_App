import 'package:flutter/material.dart';

class TabViewWidget extends StatefulWidget {
  const TabViewWidget({
    Key? key,
  }) : super(key: key);

  @override
  State<TabViewWidget> createState() => _TabViewWidgetState();
}

class _TabViewWidgetState extends State<TabViewWidget> {
  double rating = 0.0;

  final nameController = TextEditingController();
  // final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final reviewController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(
            tabs: [
              Tab(text: 'Menu'),
              Tab(text: 'Book'),
              Tab(text: 'Direction'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                Center(
                  child: Text(
                    '',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                Center(
                  child: Text(
                    '',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                Center(
                  child: Text(
                    '',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  onRatingChanged(double rating) {
    this.rating = rating;
  }
}
//43 cm w and 30cm h
//3.30 m
