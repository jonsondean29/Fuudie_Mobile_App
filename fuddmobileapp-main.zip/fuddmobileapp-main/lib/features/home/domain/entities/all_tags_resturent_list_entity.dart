import 'package:fuud/features/home/data/models/all_tags_resturant_list.dart';

class AllTagsrestrolistEntity {
  final String? tag;
  final List<Restrolist>? restrolist;

  AllTagsrestrolistEntity({
    required this.tag,
    required this.restrolist,
  });
}
