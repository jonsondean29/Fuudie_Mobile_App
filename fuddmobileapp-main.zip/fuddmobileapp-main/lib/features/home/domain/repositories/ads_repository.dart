import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';

abstract class AdsRepository {
  Future<Either<Failure, List<AdsEntity>>> getAds(AdsParams params);
}
