import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/entities/top_10_resturents_entity.dart';
import 'package:fuud/features/home/domain/usecases/top_10_resturents_usecase.dart';
// import 'package:fuud/features/home/domain/entities/topten_opening_resturent_entity.dart';

abstract class TopTenRestaurantRepository {
  Future<Either<Failure, List<TopTenResturentEntity>>> getTopTenRestaurant(
      TopTenRestaurantParams params);
}
