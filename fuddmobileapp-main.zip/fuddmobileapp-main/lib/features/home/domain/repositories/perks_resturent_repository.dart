import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/perks_resturent_usecase.dart';
import 'package:fuud/features/home/domain/entities/perks_resturent_list_entity.dart';

abstract class PerksRestaurantRepository {
  Future<Either<Failure, List<PerksResturentEntity>>> getPerksRestaurant(
      PerksRestaurantParams params);
}
