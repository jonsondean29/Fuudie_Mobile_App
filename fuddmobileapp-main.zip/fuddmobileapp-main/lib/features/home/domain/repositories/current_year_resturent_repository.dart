import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/current_year_resturents_usecase.dart';
import 'package:fuud/features/home/domain/entities/current_year_resturent_list_entity.dart';

abstract class CurrentYearRestaurantRepository {
  Future<Either<Failure, List<CurryearrestrolistEntity>>>
      getCurrentYearRestaurant(CurrentYearRestaurantParams params);
}
