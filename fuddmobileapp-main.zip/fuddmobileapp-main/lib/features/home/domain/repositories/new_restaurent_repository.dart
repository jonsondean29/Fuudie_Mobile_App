import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/entities/new_opening_resturent_entity.dart';
import 'package:fuud/features/home/domain/usecases/new_opening_restaurent_usecase.dart';

abstract class NewRestaurantRepository {
  Future<Either<Failure, List<NewOpeningResturentEntity>>> getNewRestaurant(
      NewRestaurantParams params);
}
