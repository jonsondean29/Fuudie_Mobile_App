import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/new_opening_resturent_entity.dart';
import 'package:fuud/features/home/domain/repositories/new_restaurent_repository.dart';

@LazySingleton()
class NewRestaurantUsecase
    implements UseCaseWithParams<void, NewRestaurantParams> {
  final NewRestaurantRepository newRestaurantRepository;

  NewRestaurantUsecase({required this.newRestaurantRepository});
  @override
  Future<Either<Failure, List<NewOpeningResturentEntity>>> call(params) {
    return newRestaurantRepository.getNewRestaurant(params);
  }
}

class NewRestaurantParams extends Equatable {
  final int count;
  final int userId;

  const NewRestaurantParams({required this.count, required this.userId});
  @override
  List<Object?> get props => [id, userId];
}
