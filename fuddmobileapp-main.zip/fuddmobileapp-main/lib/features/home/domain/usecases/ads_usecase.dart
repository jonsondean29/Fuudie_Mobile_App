import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/domain/repositories/ads_repository.dart';

@LazySingleton()
class AdsUsecase implements UseCaseWithParams<void, AdsParams> {
  final AdsRepository adsRepository;

  AdsUsecase({required this.adsRepository});
  @override
  Future<Either<Failure, List<AdsEntity>>> call(params) {
    return adsRepository.getAds(params);
  }
}

class AdsParams extends Equatable {
  final String adsposition;

  const AdsParams({required this.adsposition});
  @override
  List<Object?> get props => [adsposition];
}
