import 'package:flutter/material.dart';
import 'package:fuud/features/map/presentation/bloc/map_bloc.dart';
import 'package:fuud/firebase_options.dart';
import 'package:fuud/features/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:fuud/config/theme/app_themes.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/utls/network/bloc/network_bloc.dart';
import 'package:fuud/core/utls/location/bloc/location_bloc.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/splash/presentation/bloc/splash_bloc.dart';
import 'package:fuud/features/activity/presentation/bloc/activity_bloc.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await configureDependencies();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final _appRouter = AppRouter();

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => getIt<SplashBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<NetworkBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<LocationBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<AuthBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<HomeBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<ActivityBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<MapBloc>(),
        ),
      ],
      child: MaterialApp.router(
        debugShowCheckedModeBanner: false,
        title: 'Fuud',
        theme: AppTheme.getThemeData(),
        routeInformationParser: _appRouter.defaultRouteParser(),
        routerDelegate: _appRouter.delegate(),
      ),
    );
  }
}
