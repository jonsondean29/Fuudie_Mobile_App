import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';

import '../../features/home/presentation/widgets/network_image_widget.dart';
import '../constants/urls.dart';

PreferredSizeWidget customAppBar(
    {required String title,
    required GlobalKey<ScaffoldState> scaffoldKey,
    bool? locationImage, Function()?changeCity}) {
  return PreferredSize(
    preferredSize: locationImage != null
        ? const Size.fromHeight(90)
        : const Size.fromHeight(50),
    child: Container(
      height: 200,
      decoration: const BoxDecoration(
        // borderRadius: BorderRadius.only(bottomRight: Radius.circular(60)),
        color: Colors.white,
      ),
      child: Stack(
        children: [
          Image.asset(
            'assets/images/top-bg.png',
            height: 80,
          ),
          locationImage != null
              ? Align(
                  alignment: Alignment.bottomLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Image.asset(
                          'assets/images/logo3.png',
                          fit: BoxFit.cover,
                          height: 60,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            title,
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Row(
                          children: [
                            locationImage
                                ? FutureBuilder(future: getDefaultCountry(), builder: (context, snapshot) {
                                  if(snapshot.data==null||snapshot.data!.isEmpty){
                                    return InkWell(
                                      onTap: changeCity,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          NetworkImageWidget(url: '${Apis.baseUrl}/${auth.value!.selectedcountryflag}',width: 35,),
                                          Text(
                                            '${auth.value!.selectedcity}',
                                            style: const TextStyle(fontSize: 12),
                                          ),
                                          const Gap(10)
                                        ],
                                      ),
                                    );
                                  }
                                  return InkWell(
                                    onTap: changeCity,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        NetworkImageWidget(url: '${Apis.baseUrl}/${snapshot.data!['selectedcountryflag']}',width: 35,),
                                         Text(
                                          '${snapshot.data!['selectedcity']}',
                                          style: const TextStyle(fontSize: 12),
                                        ),
                                        const Gap(10)
                                      ],
                                    ),
                                  );
                                },)
                                : const SizedBox(),
                            const Gap(10),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                const Gap(10),
                                IconButton(
                                  padding: const EdgeInsets.only(top: 10),
                                  onPressed: () {
                                    scaffoldKey.currentState!.openEndDrawer();
                                  },
                                  icon: const Icon(Icons.menu),
                                  iconSize: 37,
                                ),
                                const Text(
                                  '',
                                  style: TextStyle(fontSize: 12),
                                ),
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                )
              : const SizedBox(),
        ],
      ),
    ),
  );
}
