import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/features/auth/presentation/pages/signin_page.dart';

import '../../config/theme/colors.dart';
import '../../features/account/presentation/bloc/account_bloc.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return  Drawer(child:
         ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            SizedBox(
              height: 150,
              child: DrawerHeader(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(
                      'assets/images/logo3.png',
                      height: 60,
                    ),
                  )),
            ),
            DrawerMenuItem(
              icon: Icons.home,
              text: 'Home',
              onPressed: () {
                context.router.push(HomeRoute());
              },
            ),
            DrawerMenuItem(
              icon: Icons.call,
              text: 'Contact Us',
              onPressed: () {
                context.router.push(const ContactUsRoute());
              },
            ),
            DrawerMenuItem(
              icon: Icons.support_agent,
              text: 'Support / FAQ',
              onPressed: () async {
                context.router.push(const SupportRoute());
              },
            ),
            DrawerMenuItem(
              icon: Icons.contact_mail,
              text: 'Terms and Conditions',
              onPressed: () async {
                context.router.push(const TermRoute());
              },
            ),
            DrawerMenuItem(
              icon: Icons.privacy_tip_outlined,
              text: 'Privacy Policy',
              onPressed: () async {
                context.router.push(const PrivacyPolicyRoute());
              },
            ),

            DrawerMenuItem(
              icon: Icons.exit_to_app,
              text: 'Logout',
              onPressed: () {
                clearStorage();
                context.router.replaceAll([const SigninRoute()]);
                },
            ),
            InkWell(
              child: Container(
                height: 40,
                margin: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: AppColors.black,
                    borderRadius:
                    BorderRadius.circular(50)),
                child:  const Center(
                  child: Text(
                    'Delete Account',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              onTap: (){
                deleteAccount(context);
              },
            ),
          ],
        ),
        );
  }
  void deleteAccount(context){
    showDialog(context: context, builder: (context) {
      return Container(
        alignment: AlignmentDirectional.center,
        child: Container(
          height: 200,
          padding: const EdgeInsets.all(10),
          width: MediaQuery.of(context).size.width-50,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            color: Colors.white
          ),
          child:  Column(
            children: [
              const Text("Warning: Delete Account",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.red
              ),),
              const SizedBox(height: 10,),
              const Text("Deleting your account will permanently erase all your data and cannot be undone. Are you sure you want to proceed?",
              textAlign: TextAlign.center,
                style: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 16,
              ),),
              const SizedBox(height: 10,),
              Row(
                children: [
                  Expanded(child: TextButton(onPressed: (){
                    Navigator.pop(context);
                    context.read<AccountBloc>().add(AccountEvent.DeleteAccount(context));
                  }, child: const Text("Delete",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.red
                    ),))),
                  Expanded(child: TextButton(onPressed: (){
                    Navigator.pop(context);
                  }, child: const Text("Cancel",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 16,
                    ),)))
                ],
              )
            ],
          ),
        )
      );
    },);
  }
}

class DrawerMenuItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onPressed;

  const DrawerMenuItem({
    super.key,
    required this.icon,
    required this.text,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon),
      title: Text(text),
      onTap: () {
        onPressed();
        Navigator.of(context)
            .pop(); // Close the drawer after the item is clicked
      },
    );
  }
}
