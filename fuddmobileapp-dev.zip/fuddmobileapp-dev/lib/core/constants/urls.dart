class Apis {
  static String baseUrl = 'https://fuddapi.galileosoft.com';
  static String signIn = '$baseUrl/api/user/login';
  static String generateOtp = '$baseUrl/api/user/generateOTP';
  static String verifyOTP = '$baseUrl/api/user/verifyOTP';
  static String resetpassword = '$baseUrl/api/user/resetpassword';
  static String signUp = '$baseUrl/api/user/secureregister';
  static String forgotPassword = '$baseUrl/api/user/resetpassword';
  static String updatePassword = '$baseUrl/api/user/changepassword';
  static String restaurantDetails = '$baseUrl/api/Restaurant/details';
  static String getcityrestolist =
      '$baseUrl/api/Restaurant/getcityrestolist/0/10/london';
  static String getexclusiverestrolist =
      '$baseUrl/api/restaurant/getexclusiverestrolist';
  static String getperkrestrolist = '$baseUrl/api/restaurant/getperkrestrolist';
  static String getcurryearrestrolist =
      '$baseUrl/api/restaurant/getcurryearrestrolist';
  static String getnewopeningrestrolist =
      '$baseUrl/api/restaurant/getnewopeningrestrolist';
  static String getAlltagsrestrolist = '$baseUrl/api/restaurant/getAlltagsrestrolist';
  static String getAllMapRestrolist = '$baseUrl/api/Restaurant/restrolistfromplaces';
  static String getAds = '$baseUrl/api/Restaurant/getrestroads';
  static String getComments = '$baseUrl/api/community/get';
  static String getCommentsReply = '$baseUrl/api/community/detailsfromslug';
  static String addPost = '$baseUrl/api/community/add';
  static String addReply = '$baseUrl/api/community/addreply';
  static String actionCommunityLike = '$baseUrl/api/community/liked';
  static String actionCommunityDislike = '$baseUrl/api/community/disliked';
  static String actionCommunityShare = '$baseUrl/api/community/share';
  static String getHomeRestoList = '$baseUrl/api/Restaurant/gethomerestolist';
  static String getCountry = '$baseUrl/api/Restaurant/getcountry';
  static String setCurrentCity = '$baseUrl/api/user/setcurrentcity';
  static String getHomeList = '$baseUrl/api/Restaurant/gethomerestolist';
  static String addorremovetowish = '$baseUrl/api/Restaurant/addorremovetowish';
  static String addorremovetotry = '$baseUrl/api/Restaurant/addorremovetotry';
  static String addorremovetotested = '$baseUrl/api/Restaurant/addorremovetotested';
  static String search = '$baseUrl/api/Restaurant/search';
  static String profileDetails = '$baseUrl/api/user/details';
  static String profileupdate = '$baseUrl/api/user/profileupdate';
  static String profiledelete = '$baseUrl/api/user/delete';
  static String contactUs = '$baseUrl/api/appsetting/contact';
  static String support = '$baseUrl/api/appsetting/faq';
  static String termsandconditions = '$baseUrl/api/appsetting/termsandconditions';
  static String privacypolicy = '$baseUrl/api/appsetting/privacypolicy';
  static String wishtestedandtrylist = '$baseUrl/api/Restaurant/wishtestedandtrylist';
}
