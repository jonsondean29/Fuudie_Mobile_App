import 'package:flutter/cupertino.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../features/home/data/models/country_response.dart';
import '../model/user_details.dart';
ValueNotifier<LatLng>location=ValueNotifier(LatLng(22.555525,75.35855));
ValueNotifier<CountryResponse?>countryResponse=ValueNotifier(null);
ValueNotifier<UserDetails?>auth=ValueNotifier(null);