import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:injectable/injectable.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'location_event.dart';
part 'location_state.dart';
part 'location_bloc.freezed.dart';

@injectable
class LocationBloc extends Bloc<LocationEvent, LocationState> {
  StreamSubscription<Position>? locationStream;
  LocationBloc() : super(LocationState.initial()) {
    locationStream = Geolocator.getPositionStream(
      locationSettings: AndroidSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 200,
      ),
    ).listen((position) {
      print('Location $position');
      add(NewLoactionUpdate(
          latitude: position.latitude, longitude: position.longitude));
    });
    on<NewLoactionUpdate>((event, emit) => emit(
        state.copyWith(latitude: event.latitude, longitude: event.longitude)));
  }
  @override
  Future<void> close() {
    if (locationStream != null) {
      locationStream!.cancel();
    }

    return super.close();
  }
}
