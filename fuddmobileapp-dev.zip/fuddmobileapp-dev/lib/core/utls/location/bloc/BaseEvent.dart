import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
class BaseEvent extends Equatable {
  // TODO: implement props
  List<Object> get props => [""];
}
