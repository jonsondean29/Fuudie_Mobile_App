import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
class BaseState extends Equatable {
  @override
  // TODO: implement props
  List<Object> get props => [""];
}
