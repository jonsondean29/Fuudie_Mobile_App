class UserDetails {
  UserDetails({
      this.id, 
      this.name, 
      this.email, 
      this.password, 
      this.token, 
      this.usertype, 
      this.refercode, 
      this.referbyid, 
      this.profileimg, 
      this.phone, 
      this.address, 
      this.city, 
      this.state, 
      this.country, 
      this.pincode, 
      this.createdon, 
      this.userrole, 
      this.isactive, 
      this.updatedon, 
      this.issubscribed, 
      this.totbooked, 
      this.lastbookedon, 
      this.mainimg, 
      this.adminmanage, 
      this.customermanage, 
      this.orderlist, 
      this.productmodule, 
      this.manufacturermodule, 
      this.recipemodule, 
      this.newslettermanage, 
      this.taxdiscountmanage, 
      this.couponmanage, 
      this.pagemanage, 
      this.generalsettings, 
      this.notifytolowstock, 
      this.userright, 
      this.selectedcity, 
      this.selectedcountry, 
      this.selectedcountryflag,});

  UserDetails.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    password = json['password'];
    token = json['token'];
    usertype = json['usertype'];
    refercode = json['refercode'];
    referbyid = json['referbyid'];
    profileimg = json['profileimg'];
    phone = json['phone']??"";
    address = json['address']??"";
    city = json['city']??"";
    state = json['state']??"";
    country = json['country']??"";
    pincode = json['pincode']??"";
    createdon = json['createdon'];
    userrole = json['userrole'];
    isactive = json['isactive'];
    updatedon = json['updatedon'];
    issubscribed = json['issubscribed'];
    totbooked = json['totbooked'];
    lastbookedon = json['lastbookedon'];
    mainimg = json['mainimg'];
    adminmanage = json['adminmanage'];
    customermanage = json['customermanage'];
    orderlist = json['orderlist'];
    productmodule = json['productmodule'];
    manufacturermodule = json['manufacturermodule'];
    recipemodule = json['recipemodule'];
    newslettermanage = json['newslettermanage'];
    taxdiscountmanage = json['taxdiscountmanage'];
    couponmanage = json['couponmanage'];
    pagemanage = json['pagemanage'];
    generalsettings = json['generalsettings'];
    notifytolowstock = json['notifytolowstock'];
    userright = json['userright'];
    selectedcity = json['selectedcity'];
    selectedcountry = json['selectedcountry'];
    selectedcountryflag = json['selectedcountryflag'];
  }
  dynamic id;
  String? name;
  String? email;
  dynamic password;
  dynamic token;
  dynamic usertype;
  String? refercode;
  dynamic referbyid;
  String? profileimg;
  dynamic phone;
  dynamic address;
  dynamic city;
  dynamic state;
  dynamic country;
  dynamic pincode;
  String? createdon;
  dynamic userrole;
  dynamic isactive;
  dynamic updatedon;
  dynamic issubscribed;
  dynamic totbooked;
  String? lastbookedon;
  dynamic mainimg;
  dynamic adminmanage;
  dynamic customermanage;
  dynamic orderlist;
  dynamic productmodule;
  dynamic manufacturermodule;
  dynamic recipemodule;
  dynamic newslettermanage;
  dynamic taxdiscountmanage;
  dynamic couponmanage;
  dynamic pagemanage;
  dynamic generalsettings;
  dynamic notifytolowstock;
  dynamic userright;
  dynamic selectedcity;
  dynamic selectedcountry;
  dynamic selectedcountryflag;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['email'] = email;
    map['password'] = password;
    map['token'] = token;
    map['usertype'] = usertype;
    map['refercode'] = refercode;
    map['referbyid'] = referbyid;
    map['profileimg'] = profileimg;
    map['phone'] = phone;
    map['address'] = address;
    map['city'] = city;
    map['state'] = state;
    map['country'] = country;
    map['pincode'] = pincode;
    map['createdon'] = createdon;
    map['userrole'] = userrole;
    map['isactive'] = isactive;
    map['updatedon'] = updatedon;
    map['issubscribed'] = issubscribed;
    map['totbooked'] = totbooked;
    map['lastbookedon'] = lastbookedon;
    map['mainimg'] = mainimg;
    map['adminmanage'] = adminmanage;
    map['customermanage'] = customermanage;
    map['orderlist'] = orderlist;
    map['productmodule'] = productmodule;
    map['manufacturermodule'] = manufacturermodule;
    map['recipemodule'] = recipemodule;
    map['newslettermanage'] = newslettermanage;
    map['taxdiscountmanage'] = taxdiscountmanage;
    map['couponmanage'] = couponmanage;
    map['pagemanage'] = pagemanage;
    map['generalsettings'] = generalsettings;
    map['notifytolowstock'] = notifytolowstock;
    map['userright'] = userright;
    map['selectedcity'] = selectedcity;
    map['selectedcountry'] = selectedcountry;
    map['selectedcountryflag'] = selectedcountryflag;
    return map;
  }
  Map<String, String> toUpdateProfile() {
    final map = <String, String>{};
    map['id'] = id.toString();
    map['name'] = name.toString();
    map['phone'] = phone;
    map['address'] = address;
    map['city'] = city;
    map['state'] = state;
    map['country'] = country;
    map['pincode'] = pincode;
    return map;
  }

}