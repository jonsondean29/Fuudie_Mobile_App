import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/map/presentation/bloc/map_bloc.dart';
import 'package:fuud/firebase_options.dart';
import 'package:fuud/features/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:fuud/config/theme/app_themes.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/utls/network/bloc/network_bloc.dart';
import 'package:fuud/core/utls/location/bloc/location_bloc.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/splash/presentation/bloc/splash_bloc.dart';
import 'package:fuud/features/activity/presentation/bloc/activity_bloc.dart';

Future<void> main() async { 
  WidgetsFlutterBinding.ensureInitialized();
  await configureDependencies();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await FirebaseMessaging.instance.setAutoInitEnabled(true);
  final notificationSettings = await FirebaseMessaging.instance.requestPermission(provisional: true);

// For apple platforms, ensure the APNS token is available before making any FCM plugin API calls
  final apnsToken = await FirebaseMessaging.instance.getAPNSToken();
  if (apnsToken != null) {
    // APNS token is available, make FCM plugin API requests...
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final _appRouter = AppRouter();

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => getIt<SplashBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<NetworkBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<LocationBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<AuthBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<HomeBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<ActivityBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<MapBloc>(),
        ),
        BlocProvider(
          create: (context) => getIt<AccountBloc>(),
        ),
      ],
      child: MaterialApp.router(
        debugShowCheckedModeBanner: false,
        title: 'Fuudie',
        theme: AppTheme.getThemeData(),
        routeInformationParser: _appRouter.defaultRouteParser(),
        routerDelegate: _appRouter.delegate(),
      ),
    );
  }
}
