import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/features/auth/presentation/pages/forget_passwrod_page.dart';
import 'package:fuud/features/map/presentation/pages/map_page.dart';
import 'package:fuud/features/home/presentation/pages/home_page.dart';
import 'package:fuud/features/auth/presentation/pages/signin_page.dart';
import 'package:fuud/features/auth/presentation/pages/signup_page.dart';
import 'package:fuud/features/map/presentation/widgets/map_route_page.dart';
import 'package:fuud/features/splash/presentation/pages/splash_page.dart';
import 'package:fuud/features/explore/presentation/pages/explore_page.dart';
import 'package:fuud/features/account/presentation/pages/account_page.dart';
import 'package:fuud/features/activity/presentation/pages/activity_page.dart';
import 'package:fuud/features/home/presentation/widgets/resturant_details.dart';
import 'package:fuud/features/dashboard/presentation/pages/dashboard_page.dart';
import 'package:fuud/features/home/presentation/pages/home_navigation_screen.dart';
import '../../features/account/presentation/pages/contact_us_page.dart';
import '../../features/account/presentation/pages/edit_profile_page.dart';
import '../../features/account/presentation/pages/privacy_policy_page.dart';
import '../../features/account/presentation/pages/support_page.dart';
import '../../features/account/presentation/pages/term_page.dart';
import '../../features/account/presentation/pages/web_view_page.dart';
import '../../features/auth/presentation/pages/forget_passwrod_otp_page.dart';
import '../../features/auth/presentation/pages/reset_passwrod_page.dart';
import '../../features/home/data/models/home_response.dart';
import '../../features/home/presentation/pages/city_page.dart';
import '../../features/home/presentation/pages/restaurent_list_page.dart';
import '../../features/home/presentation/pages/search_page.dart';
part 'app_router.gr.dart';

@AutoRouterConfig(replaceInRouteName: 'Page,Route')
class AppRouter extends _$AppRouter {
  @override
  List<CustomRoute> get routes => [
        CustomRoute(
          transitionsBuilder: (context, animation, secondaryAnimation, child) =>
              FadeTransition(
            opacity: CurveTween(curve: Curves.easeInOutCirc).animate(animation),
            child: child,
          ),
          page: SigninRoute.page,
          path: SigninPage.routeName,
        ),
        CustomRoute(
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(
                      opacity: CurveTween(curve: Curves.easeInOutCirc)
                          .animate(animation),
                      child: child,
                    ),
            page: DashboardRoute.page,
            // path: DashboardPage.routeName,
            guards: [
              AuthGuard()
            ],
            children: [
              CustomRoute(
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                  page: HomeWrapperRoute.page,
                  path: HomeWrapperPage.routeName,
                  children: [
                    CustomRoute(
                      transitionsBuilder:
                          (context, animation, secondaryAnimation, child) =>
                              FadeTransition(
                        opacity: CurveTween(curve: Curves.easeInOutCirc)
                            .animate(animation),
                        child: child,
                      ),
                      page: HomeRoute.page,
                    ),
                    CustomRoute(
                        transitionsBuilder: (context, animation,
                                secondaryAnimation, child) =>
                            FadeTransition(
                              opacity: CurveTween(curve: Curves.easeInOutCirc)
                                  .animate(animation),
                              child: child,
                            ),
                        page: ResturantDetailsRoute.page),
                    CustomRoute(
                        transitionsBuilder: (context, animation,
                                secondaryAnimation, child) =>
                            FadeTransition(
                              opacity: CurveTween(curve: Curves.easeInOutCirc)
                                  .animate(animation),
                              child: child,
                            ),
                        page: CityRoute.page),
                    CustomRoute(
                        transitionsBuilder: (context, animation,
                                secondaryAnimation, child) =>
                            FadeTransition(
                              opacity: CurveTween(curve: Curves.easeInOutCirc)
                                  .animate(animation),
                              child: child,
                            ),
                        page: RestaurentListRoute.page,
                    ),
                    CustomRoute(
                        transitionsBuilder: (context, animation,
                                secondaryAnimation, child) =>
                            FadeTransition(
                              opacity: CurveTween(curve: Curves.easeInOutCirc)
                                  .animate(animation),
                              child: child,
                            ),
                        page: SearchRoute.page,
                    ),
                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: EditProfileRoute.page,
                    ),

                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: ContactUsRoute.page,
                    ),
                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: WebViewRoute.page,
                    ),
                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: SupportRoute.page,
                    ),
                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: PrivacyPolicyRoute.page,
                    ),
                    CustomRoute(
                      transitionsBuilder: (context, animation,
                          secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                      page: TermRoute.page,
                    ),
                  ]),
              CustomRoute(
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                  page: AccountRoute.page,
                  path: AccountPage.routeName,
              ),

              CustomRoute(
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          FadeTransition(
                            opacity: CurveTween(curve: Curves.easeInOutCirc)
                                .animate(animation),
                            child: child,
                          ),
                  page: ActivityRoute.page,
                  path: ActivityPage.routeName),
              CustomRoute(
                transitionsBuilder:
                    (context, animation, secondaryAnimation, child) =>
                        FadeTransition(
                  opacity: CurveTween(curve: Curves.easeInOutCirc)
                      .animate(animation),
                  child: child,
                ),
                page: MapRoute.page,
                path: MapPage.routeName,
              ),
              CustomRoute(
                transitionsBuilder:
                    (context, animation, secondaryAnimation, child) =>
                        FadeTransition(
                  opacity: CurveTween(curve: Curves.easeInOutCirc)
                      .animate(animation),
                  child: child,
                ),
                page: ExploreRoute.page,
              ),
            ]),
        CustomRoute(
          transitionsBuilder: (context, animation, secondaryAnimation, child) =>
              FadeTransition(
            opacity: CurveTween(curve: Curves.easeInOutCirc).animate(animation),
            child: child,
          ),
          page: MapRouteRoute.page,
        ),
        CustomRoute(
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(
                      opacity: CurveTween(curve: Curves.easeInOutCirc)
                          .animate(animation),
                      child: child,
                    ),
            page: SignupRoute.page,
            path: SignupPage.routeName),
        CustomRoute(
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(
                      opacity: CurveTween(curve: Curves.easeInOutCirc)
                          .animate(animation),
                      child: child,
                    ),
            page: ForgetPasswrodRoute.page,
            path: ForgetPasswrodPage.routeName),
        CustomRoute(
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(
                      opacity: CurveTween(curve: Curves.easeInOutCirc)
                          .animate(animation),
                      child: child,
                    ),
            page: ForgetPasswrodOtpRoute.page,
            path: ForgetPasswrodOtpPage.routeName),
        CustomRoute(
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(
                      opacity: CurveTween(curve: Curves.easeInOutCirc)
                          .animate(animation),
                      child: child,
                    ),
            page: ResetPasswrodRoute.page,
            path: ResetPasswrodPage.routeName),
        CustomRoute(
          transitionsBuilder: (context, animation, secondaryAnimation, child) =>
              FadeTransition(
            opacity: CurveTween(curve: Curves.easeInOutCirc).animate(animation),
            child: child,
          ),
          page: SplashRoute.page,
          initial: true,
          path: SplashPage.routeName,
        ),
      ];
}

class AuthGuard extends AutoRouteGuard {
  @override
  void onNavigation(NavigationResolver resolver, StackRouter router) async {
    final int? id = await getIntValue('id');
    if (id != null) {
      // User is authenticated, redirect to HomeScreen
      resolver.next(true);
    } else {
      // User is not authenticated, redirect to SigninScreen
      router.replace(const SigninRoute());
    }
  }
}

class $AppRouter {}
