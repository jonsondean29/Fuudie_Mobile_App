// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'app_router.dart';

abstract class _$AppRouter extends RootStackRouter {
  // ignore: unused_element
  _$AppRouter({super.navigatorKey});

  @override
  final Map<String, PageFactory> pagesMap = {
    AccountRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const AccountPage(),
      );
    },
    ActivityRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ActivityPage(),
      );
    },
    CityRoute.name: (routeData) {
      final args =
          routeData.argsAs<CityRouteArgs>(orElse: () => const CityRouteArgs());
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: CityPage(key: args.key),
      );
    },
    ContactUsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ContactUsPage(),
      );
    },
    DashboardRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const DashboardPage(),
      );
    },
    EditProfileRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const EditProfilePage(),
      );
    },
    ExploreRoute.name: (routeData) {
      final args = routeData.argsAs<ExploreRouteArgs>(
          orElse: () => const ExploreRouteArgs());
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: ExplorePage(key: args.key),
      );
    },
    ForgetPasswrodOtpRoute.name: (routeData) {
      final args = routeData.argsAs<ForgetPasswrodOtpRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: ForgetPasswrodOtpPage(
          key: args.key,
          email: args.email,
        ),
      );
    },
    ForgetPasswrodRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ForgetPasswrodPage(),
      );
    },
    HomeRoute.name: (routeData) {
      final args =
          routeData.argsAs<HomeRouteArgs>(orElse: () => const HomeRouteArgs());
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: HomePage(key: args.key),
      );
    },
    HomeWrapperRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const HomeWrapperPage(),
      );
    },
    MapRoute.name: (routeData) {
      final args = routeData.argsAs<MapRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: MapPage(
          key: args.key,
          isRouteView: args.isRouteView,
          lng: args.lng,
          lat: args.lat,
        ),
      );
    },
    MapRouteRoute.name: (routeData) {
      final args = routeData.argsAs<MapRouteRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: MapRoutePage(
          key: args.key,
          lat: args.lat,
          long: args.long,
        ),
      );
    },
    PrivacyPolicyRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const PrivacyPolicyPage(),
      );
    },
    ResetPasswrodRoute.name: (routeData) {
      final args = routeData.argsAs<ResetPasswrodRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: ResetPasswrodPage(
          key: args.key,
          email: args.email,
        ),
      );
    },
    RestaurentListRoute.name: (routeData) {
      final args = routeData.argsAs<RestaurentListRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: RestaurentListPage(
          key: args.key,
          data: args.data,
        ),
      );
    },
    ResturantDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ResturantDetailsPage(),
      );
    },
    SearchRoute.name: (routeData) {
      final args = routeData.argsAs<SearchRouteArgs>(
          orElse: () => const SearchRouteArgs());
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: SearchPage(key: args.key),
      );
    },
    SigninRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SigninPage(),
      );
    },
    SignupRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SignupPage(),
      );
    },
    SplashRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SplashPage(),
      );
    },
    SupportRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SupportPage(),
      );
    },
    TermRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const TermPage(),
      );
    },
    WebViewRoute.name: (routeData) {
      final args = routeData.argsAs<WebViewRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: WebViewPage(
          key: args.key,
          url: args.url,
        ),
      );
    },
  };
}

/// generated route for
/// [AccountPage]
class AccountRoute extends PageRouteInfo<void> {
  const AccountRoute({List<PageRouteInfo>? children})
      : super(
          AccountRoute.name,
          initialChildren: children,
        );

  static const String name = 'AccountRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ActivityPage]
class ActivityRoute extends PageRouteInfo<void> {
  const ActivityRoute({List<PageRouteInfo>? children})
      : super(
          ActivityRoute.name,
          initialChildren: children,
        );

  static const String name = 'ActivityRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CityPage]
class CityRoute extends PageRouteInfo<CityRouteArgs> {
  CityRoute({
    Key? key,
    List<PageRouteInfo>? children,
  }) : super(
          CityRoute.name,
          args: CityRouteArgs(key: key),
          initialChildren: children,
        );

  static const String name = 'CityRoute';

  static const PageInfo<CityRouteArgs> page = PageInfo<CityRouteArgs>(name);
}

class CityRouteArgs {
  const CityRouteArgs({this.key});

  final Key? key;

  @override
  String toString() {
    return 'CityRouteArgs{key: $key}';
  }
}

/// generated route for
/// [ContactUsPage]
class ContactUsRoute extends PageRouteInfo<void> {
  const ContactUsRoute({List<PageRouteInfo>? children})
      : super(
          ContactUsRoute.name,
          initialChildren: children,
        );

  static const String name = 'ContactUsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [DashboardPage]
class DashboardRoute extends PageRouteInfo<void> {
  const DashboardRoute({List<PageRouteInfo>? children})
      : super(
          DashboardRoute.name,
          initialChildren: children,
        );

  static const String name = 'DashboardRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [EditProfilePage]
class EditProfileRoute extends PageRouteInfo<void> {
  const EditProfileRoute({List<PageRouteInfo>? children})
      : super(
          EditProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'EditProfileRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ExplorePage]
class ExploreRoute extends PageRouteInfo<ExploreRouteArgs> {
  ExploreRoute({
    Key? key,
    List<PageRouteInfo>? children,
  }) : super(
          ExploreRoute.name,
          args: ExploreRouteArgs(key: key),
          initialChildren: children,
        );

  static const String name = 'ExploreRoute';

  static const PageInfo<ExploreRouteArgs> page =
      PageInfo<ExploreRouteArgs>(name);
}

class ExploreRouteArgs {
  const ExploreRouteArgs({this.key});

  final Key? key;

  @override
  String toString() {
    return 'ExploreRouteArgs{key: $key}';
  }
}

/// generated route for
/// [ForgetPasswrodOtpPage]
class ForgetPasswrodOtpRoute extends PageRouteInfo<ForgetPasswrodOtpRouteArgs> {
  ForgetPasswrodOtpRoute({
    Key? key,
    required String email,
    List<PageRouteInfo>? children,
  }) : super(
          ForgetPasswrodOtpRoute.name,
          args: ForgetPasswrodOtpRouteArgs(
            key: key,
            email: email,
          ),
          initialChildren: children,
        );

  static const String name = 'ForgetPasswrodOtpRoute';

  static const PageInfo<ForgetPasswrodOtpRouteArgs> page =
      PageInfo<ForgetPasswrodOtpRouteArgs>(name);
}

class ForgetPasswrodOtpRouteArgs {
  const ForgetPasswrodOtpRouteArgs({
    this.key,
    required this.email,
  });

  final Key? key;

  final String email;

  @override
  String toString() {
    return 'ForgetPasswrodOtpRouteArgs{key: $key, email: $email}';
  }
}

/// generated route for
/// [ForgetPasswrodPage]
class ForgetPasswrodRoute extends PageRouteInfo<void> {
  const ForgetPasswrodRoute({List<PageRouteInfo>? children})
      : super(
          ForgetPasswrodRoute.name,
          initialChildren: children,
        );

  static const String name = 'ForgetPasswrodRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [HomePage]
class HomeRoute extends PageRouteInfo<HomeRouteArgs> {
  HomeRoute({
    Key? key,
    List<PageRouteInfo>? children,
  }) : super(
          HomeRoute.name,
          args: HomeRouteArgs(key: key),
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const PageInfo<HomeRouteArgs> page = PageInfo<HomeRouteArgs>(name);
}

class HomeRouteArgs {
  const HomeRouteArgs({this.key});

  final Key? key;

  @override
  String toString() {
    return 'HomeRouteArgs{key: $key}';
  }
}

/// generated route for
/// [HomeWrapperPage]
class HomeWrapperRoute extends PageRouteInfo<void> {
  const HomeWrapperRoute({List<PageRouteInfo>? children})
      : super(
          HomeWrapperRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeWrapperRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [MapPage]
class MapRoute extends PageRouteInfo<MapRouteArgs> {
  MapRoute({
    Key? key,
    required bool isRouteView,
    required String? lng,
    required String? lat,
    List<PageRouteInfo>? children,
  }) : super(
          MapRoute.name,
          args: MapRouteArgs(
            key: key,
            isRouteView: isRouteView,
            lng: lng,
            lat: lat,
          ),
          initialChildren: children,
        );

  static const String name = 'MapRoute';

  static const PageInfo<MapRouteArgs> page = PageInfo<MapRouteArgs>(name);
}

class MapRouteArgs {
  const MapRouteArgs({
    this.key,
    required this.isRouteView,
    required this.lng,
    required this.lat,
  });

  final Key? key;

  final bool isRouteView;

  final String? lng;

  final String? lat;

  @override
  String toString() {
    return 'MapRouteArgs{key: $key, isRouteView: $isRouteView, lng: $lng, lat: $lat}';
  }
}

/// generated route for
/// [MapRoutePage]
class MapRouteRoute extends PageRouteInfo<MapRouteRouteArgs> {
  MapRouteRoute({
    Key? key,
    required double lat,
    required double long,
    List<PageRouteInfo>? children,
  }) : super(
          MapRouteRoute.name,
          args: MapRouteRouteArgs(
            key: key,
            lat: lat,
            long: long,
          ),
          initialChildren: children,
        );

  static const String name = 'MapRouteRoute';

  static const PageInfo<MapRouteRouteArgs> page =
      PageInfo<MapRouteRouteArgs>(name);
}

class MapRouteRouteArgs {
  const MapRouteRouteArgs({
    this.key,
    required this.lat,
    required this.long,
  });

  final Key? key;

  final double lat;

  final double long;

  @override
  String toString() {
    return 'MapRouteRouteArgs{key: $key, lat: $lat, long: $long}';
  }
}

/// generated route for
/// [PrivacyPolicyPage]
class PrivacyPolicyRoute extends PageRouteInfo<void> {
  const PrivacyPolicyRoute({List<PageRouteInfo>? children})
      : super(
          PrivacyPolicyRoute.name,
          initialChildren: children,
        );

  static const String name = 'PrivacyPolicyRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ResetPasswrodPage]
class ResetPasswrodRoute extends PageRouteInfo<ResetPasswrodRouteArgs> {
  ResetPasswrodRoute({
    Key? key,
    required String email,
    List<PageRouteInfo>? children,
  }) : super(
          ResetPasswrodRoute.name,
          args: ResetPasswrodRouteArgs(
            key: key,
            email: email,
          ),
          initialChildren: children,
        );

  static const String name = 'ResetPasswrodRoute';

  static const PageInfo<ResetPasswrodRouteArgs> page =
      PageInfo<ResetPasswrodRouteArgs>(name);
}

class ResetPasswrodRouteArgs {
  const ResetPasswrodRouteArgs({
    this.key,
    required this.email,
  });

  final Key? key;

  final String email;

  @override
  String toString() {
    return 'ResetPasswrodRouteArgs{key: $key, email: $email}';
  }
}

/// generated route for
/// [RestaurentListPage]
class RestaurentListRoute extends PageRouteInfo<RestaurentListRouteArgs> {
  RestaurentListRoute({
    Key? key,
    required Restaurantlist data,
    List<PageRouteInfo>? children,
  }) : super(
          RestaurentListRoute.name,
          args: RestaurentListRouteArgs(
            key: key,
            data: data,
          ),
          initialChildren: children,
        );

  static const String name = 'RestaurentListRoute';

  static const PageInfo<RestaurentListRouteArgs> page =
      PageInfo<RestaurentListRouteArgs>(name);
}

class RestaurentListRouteArgs {
  const RestaurentListRouteArgs({
    this.key,
    required this.data,
  });

  final Key? key;

  final Restaurantlist data;

  @override
  String toString() {
    return 'RestaurentListRouteArgs{key: $key, data: $data}';
  }
}

/// generated route for
/// [ResturantDetailsPage]
class ResturantDetailsRoute extends PageRouteInfo<void> {
  const ResturantDetailsRoute({List<PageRouteInfo>? children})
      : super(
          ResturantDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'ResturantDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SearchPage]
class SearchRoute extends PageRouteInfo<SearchRouteArgs> {
  SearchRoute({
    Key? key,
    List<PageRouteInfo>? children,
  }) : super(
          SearchRoute.name,
          args: SearchRouteArgs(key: key),
          initialChildren: children,
        );

  static const String name = 'SearchRoute';

  static const PageInfo<SearchRouteArgs> page = PageInfo<SearchRouteArgs>(name);
}

class SearchRouteArgs {
  const SearchRouteArgs({this.key});

  final Key? key;

  @override
  String toString() {
    return 'SearchRouteArgs{key: $key}';
  }
}

/// generated route for
/// [SigninPage]
class SigninRoute extends PageRouteInfo<void> {
  const SigninRoute({List<PageRouteInfo>? children})
      : super(
          SigninRoute.name,
          initialChildren: children,
        );

  static const String name = 'SigninRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SignupPage]
class SignupRoute extends PageRouteInfo<void> {
  const SignupRoute({List<PageRouteInfo>? children})
      : super(
          SignupRoute.name,
          initialChildren: children,
        );

  static const String name = 'SignupRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SplashPage]
class SplashRoute extends PageRouteInfo<void> {
  const SplashRoute({List<PageRouteInfo>? children})
      : super(
          SplashRoute.name,
          initialChildren: children,
        );

  static const String name = 'SplashRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SupportPage]
class SupportRoute extends PageRouteInfo<void> {
  const SupportRoute({List<PageRouteInfo>? children})
      : super(
          SupportRoute.name,
          initialChildren: children,
        );

  static const String name = 'SupportRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [TermPage]
class TermRoute extends PageRouteInfo<void> {
  const TermRoute({List<PageRouteInfo>? children})
      : super(
          TermRoute.name,
          initialChildren: children,
        );

  static const String name = 'TermRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [WebViewPage]
class WebViewRoute extends PageRouteInfo<WebViewRouteArgs> {
  WebViewRoute({
    Key? key,
    required String url,
    List<PageRouteInfo>? children,
  }) : super(
          WebViewRoute.name,
          args: WebViewRouteArgs(
            key: key,
            url: url,
          ),
          initialChildren: children,
        );

  static const String name = 'WebViewRoute';

  static const PageInfo<WebViewRouteArgs> page =
      PageInfo<WebViewRouteArgs>(name);
}

class WebViewRouteArgs {
  const WebViewRouteArgs({
    this.key,
    required this.url,
  });

  final Key? key;

  final String url;

  @override
  String toString() {
    return 'WebViewRouteArgs{key: $key, url: $url}';
  }
}
