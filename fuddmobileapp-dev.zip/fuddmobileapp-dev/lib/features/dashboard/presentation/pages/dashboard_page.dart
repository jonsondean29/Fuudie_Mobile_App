import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/storege.dart';

@RoutePage()
class DashboardPage extends StatelessWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    getSession();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: AutoTabsRouter(
        routes: [
          HomeRoute(),
          MapRoute(isRouteView: false, lat: '', lng: ''),
          const ActivityRoute(),
          const AccountRoute(),
        ],
        duration: const Duration(milliseconds: 500),
        builder: (context, child) {
          final tabsRouter = AutoTabsRouter.of(context);
          return Scaffold(
            backgroundColor: Colors.white,
            body: child,
            bottomNavigationBar: SizedBox(
              height: 70,
              child: Stack(
                children: [
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Image.asset(
                      'assets/images/footer-bg.png',
                      height: 60,
                      fit: BoxFit.cover,
                      alignment: Alignment.bottomRight,
                    ),
                  ),
                  BottomNavigationBar(
                    elevation: 0,
                    type: BottomNavigationBarType.fixed,
                    backgroundColor: Colors.transparent,
                    showSelectedLabels: true,
                    showUnselectedLabels: true,
                    unselectedLabelStyle: const TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.blue),
                    selectedLabelStyle: const TextStyle(
                        color: Color(0xff4123be),
                        fontWeight: FontWeight.bold),
                    currentIndex: tabsRouter.activeIndex,
                    selectedItemColor: const Color(0xff4123be),
                    selectedIconTheme:
                    const IconThemeData(color: Color(0xff4123be)),
                    unselectedIconTheme: const IconThemeData(
                      color: Colors.black,
                    ),
                    onTap: (value) {
                      context.router.replaceAll([HomeRoute()]);
                      tabsRouter.setActiveIndex(value);
                    },
                    items: const [
                      BottomNavigationBarItem(
                        label: 'Home',
                        icon: ImageIcon(
                          AssetImage('assets/images/download.png'),
                          size: 30,
                        ),
                      ),
                      BottomNavigationBarItem(
                        label: 'Map',
                        icon: ImageIcon(
                          AssetImage('assets/images/address.png'),
                          size: 30,
                        ),
                      ),
                      BottomNavigationBarItem(
                        label: 'Community',
                        icon: SizedBox(
                          height: 30,
                          child: ImageIcon(
                            AssetImage('assets/images/comunity2.png'),
                            size: 43,
                          ),
                        ),
                      ),
                      BottomNavigationBarItem(
                        label: 'Account',
                        icon: ImageIcon(
                          AssetImage('assets/images/profile.png'),
                          size: 30,
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
