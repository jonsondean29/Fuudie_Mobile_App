import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import '../../../home/domain/entities/exclusive_resturent_list_entity.dart';
import '../usecases/map_resturent_usecase.dart';

abstract class MapRestaurantRepository {
  Future<Either<Failure, List<ExclusiveResturantListEntity>>> getMapRestaurant(MapRestaurantParams params);
}
