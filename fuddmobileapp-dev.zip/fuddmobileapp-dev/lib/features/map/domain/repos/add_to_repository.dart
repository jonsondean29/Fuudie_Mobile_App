import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import '../usecases/add_to_usecase.dart';

abstract class AddToRepository {
  Future<Either<Failure, String>> addToList(AddToParams params);
}
