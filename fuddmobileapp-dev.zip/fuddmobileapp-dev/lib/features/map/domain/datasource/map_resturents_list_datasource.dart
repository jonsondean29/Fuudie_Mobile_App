import 'dart:developer';
import 'package:fuud/core/constants/constants.dart';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/exclusive_resturant_list.dart';
import '../usecases/map_resturent_usecase.dart';

abstract class MapResturentRemoteDatasource {

  Future<List<Exclusiverestrolist>> mapResturentUser(MapRestaurantParams params);
}

@LazySingleton(as: MapResturentRemoteDatasource)
class MapResturentRemoteDatasourceImpl implements MapResturentRemoteDatasource {
  final Client client;
  MapResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<Exclusiverestrolist>> mapResturentUser(MapRestaurantParams params) async {
    String api='${Apis.getAllMapRestrolist}/${params.qry}/${params.lat}/${params.lng}/${auth.value!.id}';
    print("mapApi==$api");
    try {
      final response = await client.get(
        Uri.parse(api),
        headers: {
          'content-type': 'application/json',
        },
      );
      if (response.statusCode == 200) {
        final user = exclusiverestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error ${e}');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
