import 'dart:convert';
import 'dart:developer';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/features/map/domain/usecases/add_to_usecase.dart';
import 'package:fuud/features/map/presentation/bloc/map_bloc.dart';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';

abstract class AddToDatasource {
  Future<String> addToList(AddToParams params);
}

@LazySingleton(as: AddToDatasource)
class AddToDatasourceImpl implements AddToDatasource {
  final Client client;
  AddToDatasourceImpl({required this.client});

  @override
  Future<String> addToList(AddToParams params) async {
    String api;
    switch(params.type){
      case AddToType.WISH:
        api="${Apis.addorremovetowish}/${auth.value!.id}/${params.resId}";
      case AddToType.TESTED:
        api="${Apis.addorremovetotested}/${auth.value!.id}/${params.resId}";
      case AddToType.TRY:
        api="${Apis.addorremovetotry}/${auth.value!.id}/${params.resId}";
    }
    print(api);
    try {
      final response = await client.post(
        Uri.parse(api),
        headers: {
          'content-type': 'application/json',
        },
      );
      print("response===>${response.body}");
      if (response.statusCode == 200) {
       return jsonDecode(response.body)['message'];
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error ${e}');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
