import 'package:dartz/dartz.dart';
import 'package:fuud/features/map/domain/datasource/add_to_datasource.dart';
import 'package:fuud/features/map/domain/repos/add_to_repository.dart';
import 'package:fuud/features/map/domain/usecases/add_to_usecase.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/data/datasources/ads_datasource.dart';
import 'package:fuud/features/home/domain/repositories/ads_repository.dart';

@LazySingleton(as: AddToRepository)
class AddToImpl implements AddToRepository {
  final AddToDatasource datasource;

  AddToImpl({required this.datasource});


  @override
  Future<Either<Failure, String>> addToList(AddToParams params) async {
    try {
      final result = await datasource.addToList(params);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

}
