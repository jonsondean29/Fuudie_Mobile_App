import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/exclusive_resturent_repository.dart';

import '../repos/add_to_repository.dart';
import '../repos/map_resturent_repository.dart';

@LazySingleton()
class AddToUsecase
    implements UseCaseWithParams<void, AddToParams> {
  final AddToRepository repository;
  AddToUsecase({required this.repository});
  @override
  Future<Either<Failure, String>> call(params) {
    return repository.addToList(params);
  }
}

class AddToParams extends Equatable {
  final int resId;
  AddToType type;

   AddToParams({required this.resId,required this.type});
  @override
  List<Object?> get props => [resId,type];
}
enum AddToType {
  WISH,TESTED,TRY
}
