import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/exclusive_resturent_repository.dart';

import '../repos/map_resturent_repository.dart';

@LazySingleton()
class MapRestaurantUsecase
    implements UseCaseWithParams<void, MapRestaurantParams> {
  final MapRestaurantRepository mapRestaurantRepository;
  MapRestaurantUsecase({required this.mapRestaurantRepository});
  @override
  Future<Either<Failure, List<ExclusiveResturantListEntity>>> call(params) {
    return mapRestaurantRepository.getMapRestaurant(params);
  }
}

class MapRestaurantParams extends Equatable {
  final String? qry;
  final double lat;
  final double lng;

  const MapRestaurantParams({this.qry, required this.lat, required this.lng});
  @override
  List<Object?> get props => [id, qry,lat,lng];
}
