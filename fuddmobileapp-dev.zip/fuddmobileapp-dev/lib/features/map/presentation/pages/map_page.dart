// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/ext/to_bit_description.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:fuud/generated/assets.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import '../../../../config/routes/app_router.dart';
import '../../../../core/constants/constants.dart';
import '../../../../core/constants/storege.dart';
import '../../../../core/constants/urls.dart';
import '../../../explore/presentation/widgets/search_widget.dart';
import '../../../home/domain/entities/exclusive_resturent_list_entity.dart';
import '../../../home/presentation/bloc/home_bloc.dart';
import '../bloc/map_bloc.dart';
import 'package:geocoding/geocoding.dart';
@RoutePage()
class MapPage extends StatefulWidget {
  final bool isRouteView;
  final String? lat, lng;

  MapPage(
      {Key? key,
      required this.isRouteView,
      required this.lng,
      required this.lat})
      : super(key: key);
  static const routeName = 'map';
  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<MapPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  ExclusiveResturantListEntity? data;
  final searchOnChange =  BehaviorSubject<String>();
  final markOnChange =  BehaviorSubject<int>();
  var searchCon=TextEditingController();
  bool isLoading=false;
  MarkerId? markerIdd;
  List<ExclusiveResturantListEntity>list=[];
  CarouselSliderController carouselSliderController=CarouselSliderController();
  @override
  void initState() {
    // TODO: implement initState
    initMap();
    InitSearch();
    context.read<MapBloc>().stream.listen((state) {
      print("isLoading====> ${state.isLoading}");
      if(isLoading!=state.isLoading){
        setState(() {
          isLoading=state.isLoading;
        });
      }
      if(state.mapRestaurantList!=null) {
        list=state.mapRestaurantList??[];
        Future.delayed(const Duration(seconds: 1),() {
          markers.clear();
          for (var element in list) {
            addMarker(element);
          }
          if(list.isNotEmpty){
            markOnChange.add(0);
          }
        },);
      }
      if(state.isLocationChange){
        initMap();
      }

    },);
    super.initState();
  }
  void InitSearch(){
    searchOnChange.debounceTime(const Duration(milliseconds: 300))
        .listen((queryString) async {
          markers.clear();
      context.read<MapBloc>().add(MapFeatch(latlng:location.value,q: queryString.isEmpty?null:queryString));
    });
    markOnChange.debounceTime(const Duration(milliseconds: 500)).listen((event) {
      updateMarkerData(list[event]);
    },);
  }


  Future<void> initMap() async {
    Map<String,dynamic>map =await getDefaultCountry();
    List<Location> locations = await locationFromAddress('${map['selectedcity']}, ${map['selectedcountry']}');
    _controller.future.then((value) {
      value.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
          target: LatLng(locations.first.latitude,locations.first.longitude),
        zoom: 14
      )));
    },);
    location.value=LatLng(locations.first.latitude,locations.first.longitude);
    context.read<MapBloc>().add(MapFeatch(latlng:location.value));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        body: Stack(
          children: [
            GoogleMap(
              mapType: MapType.terrain,
              initialCameraPosition: CameraPosition(
                target: location.value,
                zoom: 12.4746,
              ),
              markers: Set.of(markers.values),
              zoomControlsEnabled: false,
              compassEnabled: false,
              onMapCreated: (GoogleMapController controller) async {
                _controller.complete(controller);
              },
            ),
            Positioned(
              top: 50,
              left: 10,
              right: 10,
              child: SearchWidget(
                hintText: 'search for a place, area',
                searchController: searchCon,
                isLoading: isLoading,
                onChanged: (s) {
                  searchOnChange.add(s);
                },

              ),
            ),
            if(list.isNotEmpty)
            Positioned(bottom: 10,left: 0,right: 0,child: Container(
              width: MediaQuery.of(context).size.width,
              height: 130,
              child: CarouselSlider.builder(itemCount: list.length,
                  carouselController: carouselSliderController,
                  itemBuilder: (context, index, realIndex) {
                return  _card(list[index]);
              }, options: CarouselOptions(
                autoPlay: false,
                onPageChanged: (index, reason) {
                  markOnChange.add(index);
                },
              )),
            ),),
          ],
        )
    );
  }

  Future<void> updateMarkerData(ExclusiveResturantListEntity dd) async {
    MarkerId markerId = MarkerId("marker_${dd.id}");
    if(markerIdd!=null) {
      updateMarker(markerIdd,data!,reset: true);
    }
    data=dd;
    updateMarker(markerId,dd);
    markerIdd=markerId;
    _controller.future.then((value) {
      value.showMarkerInfoWindow(markerId);
      value.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target:
      LatLng(double.parse(dd.lat.toString()),double.parse(dd.lng.toString().replaceAll(",", ""))),
          zoom: 14
      ),
      ));
    },);
  }
  Future<void> addMarker(ExclusiveResturantListEntity dd) async {
    MarkerId markerId = MarkerId("marker_${dd.id}");
    var icon=await Image.asset(dd.isexclusive==1?Assets.imagesIconMain:Assets.imagesIconMain,
    height: 100,width: 100).toBitmapDescriptor(
      imageSize: Size(150, 150),
      logicalSize: Size(150, 150),
    );
    final Marker marker = Marker(
      markerId: markerId,
      infoWindow: InfoWindow(
        title: dd.name,
          snippet: '⭐ ${dd.rating}'
      ),
      position: LatLng(double.parse(dd.lat.toString()),double.parse(dd.lng.toString().replaceAll(",", ""))),
      icon: icon,
      onTap: () {
        updateMarkerData(dd);
        carouselSliderController.animateToPage(list.indexOf(dd));
      },
    );
    setState(() {
      markers.putIfAbsent(markerId, () => marker);
    });
  }
  Future<void> updateMarker(markerId,ExclusiveResturantListEntity dd,{bool reset=false}) async {
    var icon=await Container(
        height: 100,width: 100,
      padding: const EdgeInsets.all(8),
      child:reset? Image.asset(Assets.imagesIconMain,
      ):Image.asset(Assets.imagesSppon,),
    ).toBitmapDescriptor(
      imageSize: const Size(150, 150),
      logicalSize: const Size(150, 150),
    );
    final Marker marker = Marker(
      markerId: markerId,
      infoWindow: InfoWindow(
        title: dd.name,
          snippet: '⭐ ${dd.rating}'
      ),
      position: LatLng(double.parse(dd.lat.toString()),double.parse(dd.lng.toString().replaceAll(",", ""))),
      icon: icon,
      onTap: () {
        updateMarkerData(dd);
        carouselSliderController.animateToPage(list.indexOf(dd));
      },
    );
    markers[markerId]=marker;
    setState(() {});
  }
  Widget _card(ExclusiveResturantListEntity data){
    return Card(
      color: Colors.white,
      child: InkWell(
        onTap: () async {
          final userid = await getIntValue('id') ?? 0;
          if (context.mounted) {
            context
                .read<HomeBloc>()
                .add(HomeFeatchDetails(id: userid, resturentId: data!.id!));
            context.router.push(const ResturantDetailsRoute());
          }
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          width: 300,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: NetworkImageWidget(url: "${Apis.baseUrl}/${data!.mainimg}",
                  height: 100,
                  width: 100,),
              ),
              const SizedBox(width: 10,),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data.name!,
                    softWrap: true,
                    maxLines: 1,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    data!.location!,
                    softWrap: true,
                    maxLines: 1,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        color: Colors.grey,
                        fontSize: 12),
                  ),
                  Text(
                    data!.description!,
                    softWrap: true,
                    maxLines: 1,
                    style: const TextStyle(
                        overflow: TextOverflow.ellipsis,
                        color: Colors.grey,
                        fontSize: 12),
                  ),
                 Row(
                   children: [
                     IconButton(onPressed: () {
                       setState(() {
                         data!.iswishlist=data!.iswishlist==1?0:1;
                       });
                       context
                           .read<MapBloc>()
                           .add(MapEvent.addToWish(resId: data!.id!));
                     }, icon: data!.iswishlist==1?Image.asset(Assets.imagesWishSelected,width: 25,):
                     Image.asset(Assets.imagesWish,width: 25,)),

                     IconButton(onPressed: () {
                       setState(() {
                         data!.isbeenlist=data!.isbeenlist==1?0:1;
                       });
                       context
                           .read<MapBloc>()
                           .add(MapEvent.addToTested(resId: data!.id!));
                     }, icon: data!.isbeenlist==1?Image.asset(Assets.imagesBeenSelected,width: 25,):
                     Image.asset(Assets.imagesBeen,width: 25,)),

                     IconButton(onPressed: () {
                       setState(() {
                         data!.istrylist=data!.istrylist==1?0:1;
                       });
                       context
                           .read<MapBloc>()
                           .add(MapEvent.addToTry(resId: data!.id!));
                     }, icon: data!.istrylist==1? Image.asset(Assets.imagesFlagTrySelected,width: 20,):
                     Image.asset(Assets.imagesFlagTry,width: 20,)
                     ),
                   ],
                 )
                ],
              ))
            ],
          ),
        ),
      ),
    );
  }
}

