import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:injectable/injectable.dart';
import '../../../home/domain/entities/exclusive_resturent_list_entity.dart';
import '../../domain/usecases/add_to_usecase.dart';
import '../../domain/usecases/map_resturent_usecase.dart';
part 'map_event.dart';
part 'map_state.dart';
part 'map_bloc.freezed.dart';

@injectable
class MapBloc extends Bloc<MapEvent, MapState> {
  final MapRestaurantUsecase mapRestaurantUsecase;
  final AddToUsecase addToUsecase;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  MapBloc({required this.mapRestaurantUsecase,
    required this.addToUsecase,
  }) : super(MapState.initial()) {
    on<MapFeatch>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final mapRestaurantList =await mapRestaurantUsecase.call(MapRestaurantParams(lat: event.latlng.latitude,
          lng: event.latlng.longitude,
        qry: event.q
      ));
      mapRestaurantList.fold((l) {
        print(l);
        emit(state.copyWith(isLoading: false));
      }, (r) {
        emit(state.copyWith(isLoading: false,mapRestaurantList: r,isLocationChange: false));
      });
    },);
    on<UserMove>((event, emit) async {
      emit(state.copyWith(isLocationChange: true));

    },);
    on<addToWish>((event, emit) async {
      addToUsecase.call(AddToParams(resId: event.resId, type: AddToType.WISH)).then((value) {
        value.fold((l) {
        }, (r) {
          Fluttertoast.showToast(
              msg: r,
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.white,
              textColor: Colors.black,
              fontSize: 16.0);
        },);
      },);
    },);
    on<addToTested>((event, emit) async {
      addToUsecase.call(AddToParams(resId: event.resId, type: AddToType.TESTED)).then((value) {
        value.fold((l) {
        }, (r) {
          Fluttertoast.showToast(
              msg: r,
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.white,
              textColor: Colors.black,
              fontSize: 16.0);
        },);
      },);
    },);
    on<addToTry>((event, emit) async {
      addToUsecase.call(AddToParams(resId: event.resId, type: AddToType.TRY)).then((value) {
        value.fold((l) {
        }, (r) {
          Fluttertoast.showToast(
              msg: r,
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.white,
              textColor: Colors.black,
              fontSize: 16.0);
        },);
      },);
    },);
  }
  }
