part of 'map_bloc.dart';

@freezed
class MapEvent with _$MapEvent {
  const factory MapEvent.started() = _Started;
  const factory MapEvent.userMove() = UserMove;
  const factory MapEvent.featch({required LatLng latlng,String? q}) = MapFeatch;
  const factory MapEvent.addToWish({required int resId}) = addToWish;
  const factory MapEvent.addToTested({required int resId}) = addToTested;
  const factory MapEvent.addToTry({required int resId}) = addToTry;
}
