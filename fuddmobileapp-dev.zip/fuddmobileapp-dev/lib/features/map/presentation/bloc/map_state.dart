part of 'map_bloc.dart';

@freezed
class MapState with _$MapState {
  factory MapState(
      {
        required bool isLoading,
        required bool isLocationChange,
      LatLng? currentLocation,
      List<ExclusiveResturantListEntity>? mapRestaurantList}) = _MapState;

  factory MapState.initial() =>
      MapState(isLoading: false,
          isLocationChange:false,
          currentLocation: null,
        mapRestaurantList: []
      );
}
