// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'map_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MapEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MapEventCopyWith<$Res> {
  factory $MapEventCopyWith(MapEvent value, $Res Function(MapEvent) then) =
      _$MapEventCopyWithImpl<$Res, MapEvent>;
}

/// @nodoc
class _$MapEventCopyWithImpl<$Res, $Val extends MapEvent>
    implements $MapEventCopyWith<$Res> {
  _$MapEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'MapEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements MapEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$UserMoveImplCopyWith<$Res> {
  factory _$$UserMoveImplCopyWith(
          _$UserMoveImpl value, $Res Function(_$UserMoveImpl) then) =
      __$$UserMoveImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$UserMoveImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$UserMoveImpl>
    implements _$$UserMoveImplCopyWith<$Res> {
  __$$UserMoveImplCopyWithImpl(
      _$UserMoveImpl _value, $Res Function(_$UserMoveImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$UserMoveImpl implements UserMove {
  const _$UserMoveImpl();

  @override
  String toString() {
    return 'MapEvent.userMove()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$UserMoveImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return userMove();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return userMove?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (userMove != null) {
      return userMove();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return userMove(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return userMove?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (userMove != null) {
      return userMove(this);
    }
    return orElse();
  }
}

abstract class UserMove implements MapEvent {
  const factory UserMove() = _$UserMoveImpl;
}

/// @nodoc
abstract class _$$MapFeatchImplCopyWith<$Res> {
  factory _$$MapFeatchImplCopyWith(
          _$MapFeatchImpl value, $Res Function(_$MapFeatchImpl) then) =
      __$$MapFeatchImplCopyWithImpl<$Res>;
  @useResult
  $Res call({LatLng latlng, String? q});
}

/// @nodoc
class __$$MapFeatchImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$MapFeatchImpl>
    implements _$$MapFeatchImplCopyWith<$Res> {
  __$$MapFeatchImplCopyWithImpl(
      _$MapFeatchImpl _value, $Res Function(_$MapFeatchImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? latlng = null,
    Object? q = freezed,
  }) {
    return _then(_$MapFeatchImpl(
      latlng: null == latlng
          ? _value.latlng
          : latlng // ignore: cast_nullable_to_non_nullable
              as LatLng,
      q: freezed == q
          ? _value.q
          : q // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$MapFeatchImpl implements MapFeatch {
  const _$MapFeatchImpl({required this.latlng, this.q});

  @override
  final LatLng latlng;
  @override
  final String? q;

  @override
  String toString() {
    return 'MapEvent.featch(latlng: $latlng, q: $q)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MapFeatchImpl &&
            (identical(other.latlng, latlng) || other.latlng == latlng) &&
            (identical(other.q, q) || other.q == q));
  }

  @override
  int get hashCode => Object.hash(runtimeType, latlng, q);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MapFeatchImplCopyWith<_$MapFeatchImpl> get copyWith =>
      __$$MapFeatchImplCopyWithImpl<_$MapFeatchImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return featch(latlng, q);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return featch?.call(latlng, q);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch(latlng, q);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return featch(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return featch?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch(this);
    }
    return orElse();
  }
}

abstract class MapFeatch implements MapEvent {
  const factory MapFeatch({required final LatLng latlng, final String? q}) =
      _$MapFeatchImpl;

  LatLng get latlng;
  String? get q;
  @JsonKey(ignore: true)
  _$$MapFeatchImplCopyWith<_$MapFeatchImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$addToWishImplCopyWith<$Res> {
  factory _$$addToWishImplCopyWith(
          _$addToWishImpl value, $Res Function(_$addToWishImpl) then) =
      __$$addToWishImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int resId});
}

/// @nodoc
class __$$addToWishImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$addToWishImpl>
    implements _$$addToWishImplCopyWith<$Res> {
  __$$addToWishImplCopyWithImpl(
      _$addToWishImpl _value, $Res Function(_$addToWishImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resId = null,
  }) {
    return _then(_$addToWishImpl(
      resId: null == resId
          ? _value.resId
          : resId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$addToWishImpl implements addToWish {
  const _$addToWishImpl({required this.resId});

  @override
  final int resId;

  @override
  String toString() {
    return 'MapEvent.addToWish(resId: $resId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addToWishImpl &&
            (identical(other.resId, resId) || other.resId == resId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addToWishImplCopyWith<_$addToWishImpl> get copyWith =>
      __$$addToWishImplCopyWithImpl<_$addToWishImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return addToWish(resId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return addToWish?.call(resId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (addToWish != null) {
      return addToWish(resId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return addToWish(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return addToWish?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (addToWish != null) {
      return addToWish(this);
    }
    return orElse();
  }
}

abstract class addToWish implements MapEvent {
  const factory addToWish({required final int resId}) = _$addToWishImpl;

  int get resId;
  @JsonKey(ignore: true)
  _$$addToWishImplCopyWith<_$addToWishImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$addToTestedImplCopyWith<$Res> {
  factory _$$addToTestedImplCopyWith(
          _$addToTestedImpl value, $Res Function(_$addToTestedImpl) then) =
      __$$addToTestedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int resId});
}

/// @nodoc
class __$$addToTestedImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$addToTestedImpl>
    implements _$$addToTestedImplCopyWith<$Res> {
  __$$addToTestedImplCopyWithImpl(
      _$addToTestedImpl _value, $Res Function(_$addToTestedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resId = null,
  }) {
    return _then(_$addToTestedImpl(
      resId: null == resId
          ? _value.resId
          : resId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$addToTestedImpl implements addToTested {
  const _$addToTestedImpl({required this.resId});

  @override
  final int resId;

  @override
  String toString() {
    return 'MapEvent.addToTested(resId: $resId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addToTestedImpl &&
            (identical(other.resId, resId) || other.resId == resId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addToTestedImplCopyWith<_$addToTestedImpl> get copyWith =>
      __$$addToTestedImplCopyWithImpl<_$addToTestedImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return addToTested(resId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return addToTested?.call(resId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (addToTested != null) {
      return addToTested(resId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return addToTested(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return addToTested?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (addToTested != null) {
      return addToTested(this);
    }
    return orElse();
  }
}

abstract class addToTested implements MapEvent {
  const factory addToTested({required final int resId}) = _$addToTestedImpl;

  int get resId;
  @JsonKey(ignore: true)
  _$$addToTestedImplCopyWith<_$addToTestedImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$addToTryImplCopyWith<$Res> {
  factory _$$addToTryImplCopyWith(
          _$addToTryImpl value, $Res Function(_$addToTryImpl) then) =
      __$$addToTryImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int resId});
}

/// @nodoc
class __$$addToTryImplCopyWithImpl<$Res>
    extends _$MapEventCopyWithImpl<$Res, _$addToTryImpl>
    implements _$$addToTryImplCopyWith<$Res> {
  __$$addToTryImplCopyWithImpl(
      _$addToTryImpl _value, $Res Function(_$addToTryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resId = null,
  }) {
    return _then(_$addToTryImpl(
      resId: null == resId
          ? _value.resId
          : resId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$addToTryImpl implements addToTry {
  const _$addToTryImpl({required this.resId});

  @override
  final int resId;

  @override
  String toString() {
    return 'MapEvent.addToTry(resId: $resId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addToTryImpl &&
            (identical(other.resId, resId) || other.resId == resId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addToTryImplCopyWith<_$addToTryImpl> get copyWith =>
      __$$addToTryImplCopyWithImpl<_$addToTryImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() userMove,
    required TResult Function(LatLng latlng, String? q) featch,
    required TResult Function(int resId) addToWish,
    required TResult Function(int resId) addToTested,
    required TResult Function(int resId) addToTry,
  }) {
    return addToTry(resId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? userMove,
    TResult? Function(LatLng latlng, String? q)? featch,
    TResult? Function(int resId)? addToWish,
    TResult? Function(int resId)? addToTested,
    TResult? Function(int resId)? addToTry,
  }) {
    return addToTry?.call(resId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? userMove,
    TResult Function(LatLng latlng, String? q)? featch,
    TResult Function(int resId)? addToWish,
    TResult Function(int resId)? addToTested,
    TResult Function(int resId)? addToTry,
    required TResult orElse(),
  }) {
    if (addToTry != null) {
      return addToTry(resId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(UserMove value) userMove,
    required TResult Function(MapFeatch value) featch,
    required TResult Function(addToWish value) addToWish,
    required TResult Function(addToTested value) addToTested,
    required TResult Function(addToTry value) addToTry,
  }) {
    return addToTry(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(UserMove value)? userMove,
    TResult? Function(MapFeatch value)? featch,
    TResult? Function(addToWish value)? addToWish,
    TResult? Function(addToTested value)? addToTested,
    TResult? Function(addToTry value)? addToTry,
  }) {
    return addToTry?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(UserMove value)? userMove,
    TResult Function(MapFeatch value)? featch,
    TResult Function(addToWish value)? addToWish,
    TResult Function(addToTested value)? addToTested,
    TResult Function(addToTry value)? addToTry,
    required TResult orElse(),
  }) {
    if (addToTry != null) {
      return addToTry(this);
    }
    return orElse();
  }
}

abstract class addToTry implements MapEvent {
  const factory addToTry({required final int resId}) = _$addToTryImpl;

  int get resId;
  @JsonKey(ignore: true)
  _$$addToTryImplCopyWith<_$addToTryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MapState {
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isLocationChange => throw _privateConstructorUsedError;
  LatLng? get currentLocation => throw _privateConstructorUsedError;
  List<ExclusiveResturantListEntity>? get mapRestaurantList =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MapStateCopyWith<MapState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MapStateCopyWith<$Res> {
  factory $MapStateCopyWith(MapState value, $Res Function(MapState) then) =
      _$MapStateCopyWithImpl<$Res, MapState>;
  @useResult
  $Res call(
      {bool isLoading,
      bool isLocationChange,
      LatLng? currentLocation,
      List<ExclusiveResturantListEntity>? mapRestaurantList});
}

/// @nodoc
class _$MapStateCopyWithImpl<$Res, $Val extends MapState>
    implements $MapStateCopyWith<$Res> {
  _$MapStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isLocationChange = null,
    Object? currentLocation = freezed,
    Object? mapRestaurantList = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isLocationChange: null == isLocationChange
          ? _value.isLocationChange
          : isLocationChange // ignore: cast_nullable_to_non_nullable
              as bool,
      currentLocation: freezed == currentLocation
          ? _value.currentLocation
          : currentLocation // ignore: cast_nullable_to_non_nullable
              as LatLng?,
      mapRestaurantList: freezed == mapRestaurantList
          ? _value.mapRestaurantList
          : mapRestaurantList // ignore: cast_nullable_to_non_nullable
              as List<ExclusiveResturantListEntity>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MapStateImplCopyWith<$Res>
    implements $MapStateCopyWith<$Res> {
  factory _$$MapStateImplCopyWith(
          _$MapStateImpl value, $Res Function(_$MapStateImpl) then) =
      __$$MapStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoading,
      bool isLocationChange,
      LatLng? currentLocation,
      List<ExclusiveResturantListEntity>? mapRestaurantList});
}

/// @nodoc
class __$$MapStateImplCopyWithImpl<$Res>
    extends _$MapStateCopyWithImpl<$Res, _$MapStateImpl>
    implements _$$MapStateImplCopyWith<$Res> {
  __$$MapStateImplCopyWithImpl(
      _$MapStateImpl _value, $Res Function(_$MapStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isLocationChange = null,
    Object? currentLocation = freezed,
    Object? mapRestaurantList = freezed,
  }) {
    return _then(_$MapStateImpl(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isLocationChange: null == isLocationChange
          ? _value.isLocationChange
          : isLocationChange // ignore: cast_nullable_to_non_nullable
              as bool,
      currentLocation: freezed == currentLocation
          ? _value.currentLocation
          : currentLocation // ignore: cast_nullable_to_non_nullable
              as LatLng?,
      mapRestaurantList: freezed == mapRestaurantList
          ? _value._mapRestaurantList
          : mapRestaurantList // ignore: cast_nullable_to_non_nullable
              as List<ExclusiveResturantListEntity>?,
    ));
  }
}

/// @nodoc

class _$MapStateImpl implements _MapState {
  _$MapStateImpl(
      {required this.isLoading,
      required this.isLocationChange,
      this.currentLocation,
      final List<ExclusiveResturantListEntity>? mapRestaurantList})
      : _mapRestaurantList = mapRestaurantList;

  @override
  final bool isLoading;
  @override
  final bool isLocationChange;
  @override
  final LatLng? currentLocation;
  final List<ExclusiveResturantListEntity>? _mapRestaurantList;
  @override
  List<ExclusiveResturantListEntity>? get mapRestaurantList {
    final value = _mapRestaurantList;
    if (value == null) return null;
    if (_mapRestaurantList is EqualUnmodifiableListView)
      return _mapRestaurantList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'MapState(isLoading: $isLoading, isLocationChange: $isLocationChange, currentLocation: $currentLocation, mapRestaurantList: $mapRestaurantList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MapStateImpl &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isLocationChange, isLocationChange) ||
                other.isLocationChange == isLocationChange) &&
            (identical(other.currentLocation, currentLocation) ||
                other.currentLocation == currentLocation) &&
            const DeepCollectionEquality()
                .equals(other._mapRestaurantList, _mapRestaurantList));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading, isLocationChange,
      currentLocation, const DeepCollectionEquality().hash(_mapRestaurantList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MapStateImplCopyWith<_$MapStateImpl> get copyWith =>
      __$$MapStateImplCopyWithImpl<_$MapStateImpl>(this, _$identity);
}

abstract class _MapState implements MapState {
  factory _MapState(
          {required final bool isLoading,
          required final bool isLocationChange,
          final LatLng? currentLocation,
          final List<ExclusiveResturantListEntity>? mapRestaurantList}) =
      _$MapStateImpl;

  @override
  bool get isLoading;
  @override
  bool get isLocationChange;
  @override
  LatLng? get currentLocation;
  @override
  List<ExclusiveResturantListEntity>? get mapRestaurantList;
  @override
  @JsonKey(ignore: true)
  _$$MapStateImplCopyWith<_$MapStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
