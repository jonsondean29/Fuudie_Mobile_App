// ignore_for_file: depend_on_referenced_packages

import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/utls/location/bloc/location_bloc.dart';
import 'package:fuud/features/map/presentation/bloc/map_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

@RoutePage()
class MapRoutePage extends StatelessWidget {
  MapRoutePage({super.key, required this.lat, required this.long});
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  final double lat; // Example destination
  final double long;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<LocationBloc, LocationState>(
        builder: (context, state) {
          context
              .read<MapBloc>()
              .add(UserMove());
          return BlocBuilder<MapBloc, MapState>(
            builder: (context, state) {
              return state.currentLocation != null
                  ? SafeArea(
                      child: GoogleMap(
                      onMapCreated: (
                        GoogleMapController controller,
                      ) async {
                        _controller.complete(controller);

                        await controller.animateCamera(
                            CameraUpdate.newCameraPosition(CameraPosition(
                                target: state.currentLocation!, zoom: 16.5)));
                      },
                      initialCameraPosition: CameraPosition(
                        target: LatLng(lat, long),
                        zoom: 12.4746,
                      ),
                      markers: {
                        Marker(
                          markerId: const MarkerId('currentLocation'),
                          position: state.currentLocation!,
                        ),
                        Marker(
                          markerId: const MarkerId('destination'),
                          position: LatLng(lat, long),
                        )
                      },
                    ))
                  : const Center(
                      child: CircularProgressIndicator(),
                    );
            },
          );
        },
      ),
    );
  }
}
