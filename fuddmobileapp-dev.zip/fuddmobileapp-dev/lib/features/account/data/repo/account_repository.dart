import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import '../../../../core/model/user_details.dart';
import '../contact_us_usecase.dart';
import '../model/support_model.dart';

abstract class AccountRepository {
  Future<Either<Failure, UserDetails>> getProfile();
  Future<Either<Failure, List<Restrolist>>> getWttList();
  Future<Either<Failure, String>> updateProfile({File? file});
  Future<Either<Failure, String>> deleteAccount();
  Future<Either<Failure, String>> contactUs(ContactUsParams param);
  Future<Either<Failure, List<SupportModel>>> getSupport(countryId);
  Future<Either<Failure, String>> getPrivacyPolicy(countryId);
  Future<Either<Failure, String>> getTerm(countryId);
}
