import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/domain/repositories/ads_repository.dart';

import '../../../core/model/user_details.dart';
import '../../home/data/models/home_response.dart';

@LazySingleton()
class DeleteAccountUsecase implements UseCaseWithoutParams {
  final AccountRepository repository;
  DeleteAccountUsecase({required this.repository});
  @override
  Future<Either<Failure, String>> call() {
    return repository.deleteAccount();
  }
}
