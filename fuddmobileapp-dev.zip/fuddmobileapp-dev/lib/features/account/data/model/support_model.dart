class SupportModel {
  SupportModel({
      this.id, 
      this.title, 
      this.details, 
      this.language, 
      this.createdon, 
      this.updatedon, 
      this.isactive,});

  SupportModel.fromJson(dynamic json) {
    id = json['id'];
    title = json['title'];
    details = json['details'];
    language = json['language'];
    createdon = json['createdon'];
    updatedon = json['updatedon'];
    isactive = json['isactive'];
  }
  int? id;
  String? title;
  String? details;
  String? language;
  String? createdon;
  String? updatedon;
  int? isactive;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['title'] = title;
    map['details'] = details;
    map['language'] = language;
    map['createdon'] = createdon;
    map['updatedon'] = updatedon;
    map['isactive'] = isactive;
    return map;
  }

}