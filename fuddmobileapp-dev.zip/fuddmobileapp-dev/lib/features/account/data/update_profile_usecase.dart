import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/usecase/usecase.dart';
import '../../../core/error/failure.dart';

@LazySingleton()
class UpdateProfileUsecase implements UseCaseWithParams<void,ProfileParams> {
  final AccountRepository repository;
  UpdateProfileUsecase({required this.repository});
  @override
  Future<Either<Failure, String>> call(ProfileParams param) {
    return repository.updateProfile(file: param.file);
  }
}
class ProfileParams extends Equatable {
  File?file;
  ProfileParams({this.file});
  @override
  List<Object?> get props => [file];
}
