import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';

@LazySingleton()
class ContactUsUsecase implements UseCaseWithParams<void, ContactUsParams> {
  final AccountRepository accountRepository;

  ContactUsUsecase({required this.accountRepository});
  @override
  Future<Either<Failure, String>> call(params) {
    return accountRepository.contactUs(params);
  }
}

class ContactUsParams extends Equatable {
  final String name;
  final String email;
  final String phone;
  final String message;

  const ContactUsParams({required this.name,required this.email,required this.phone,required this.message});
  @override
  List<Object?> get props => [name,email,phone,message];
}
