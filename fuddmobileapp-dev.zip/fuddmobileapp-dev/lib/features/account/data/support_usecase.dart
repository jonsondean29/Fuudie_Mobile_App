import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';

import 'model/support_model.dart';

@LazySingleton()
class SupportUsecase implements UseCaseWithParams<void, String> {
  final AccountRepository accountRepository;

  SupportUsecase({required this.accountRepository});
  @override
  Future<Either<Failure, List<SupportModel>>> call(params) {
    return accountRepository.getSupport(params);
  }
}

