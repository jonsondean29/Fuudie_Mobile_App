import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:fuud/features/account/data/account_datasource.dart';
import 'package:fuud/features/account/data/contact_us_usecase.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import '../../../core/model/user_details.dart';
import 'model/support_model.dart';

@LazySingleton(as: AccountRepository)
class AccountRepositoryImpl implements AccountRepository {
  final AccountRemoteDatasource datasource;

  AccountRepositoryImpl({required this.datasource});

  @override
  Future<Either<Failure, UserDetails>> getProfile() async {
    try {
      final result = await datasource.getProfile();
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, List<Restrolist>>> getWttList() async {
    try {
      final result = await datasource.getWttList();
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> updateProfile({File?file}) async {
    try {
      final result = await datasource.updateProfile(file: file);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> deleteAccount() async {
    try {
      final result = await datasource.deleteAccount();
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> contactUs(ContactUsParams param) async {
    try {
      final result = await datasource.contactUs(param);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, List<SupportModel>>> getSupport(countryId) async {
    try {
      final result = await datasource.getSupport(countryId);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> getPrivacyPolicy(countryId) async {
    try {
      final result = await datasource.getPrivacyPolicy(countryId);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> getTerm(countryId) async {
    try {
      final result = await datasource.getTerm(countryId);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
