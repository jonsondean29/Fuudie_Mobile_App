import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import '../../../core/constants/constants.dart';
import '../../../core/model/user_details.dart';
import '../../home/data/models/home_response.dart';
import 'contact_us_usecase.dart';
import 'model/support_model.dart';

abstract class AccountRemoteDatasource {
  Future<UserDetails> getProfile();
  Future<String> updateProfile({File? file});
  Future<String> deleteAccount();
  Future<String> contactUs(ContactUsParams param);
  Future<List<SupportModel>> getSupport(param);
  Future<String> getPrivacyPolicy(param);
  Future<String> getTerm(param);
  Future<List<Restrolist>> getWttList();
}

@LazySingleton(as: AccountRemoteDatasource)
class AdsRemoteDatasourceImpl implements AccountRemoteDatasource {
  final Client client;
  AdsRemoteDatasourceImpl({required this.client});

  @override
  Future<UserDetails> getProfile() async {
    print('ads api called');
    try {
      final response = await client.get(
        Uri.parse("${Apis.profileDetails}/${auth.value!.id}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myAdsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return UserDetails.fromJson(jsonDecode(response.body));
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<List<Restrolist>> getWttList() async {
    try {
      final response = await client.get(
        Uri.parse("${Apis.wishtestedandtrylist}/${auth.value!.id}/10"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myAdsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        List<Restrolist>list=[];
        for(var v in jsonDecode(response.body)){
          list.add(Restrolist.fromJson(v));
        }
        return list;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> updateProfile({File? file}) async {
    try {
      var postUri = Uri.parse(Apis.profileupdate);

      var request =  MultipartRequest("POST", postUri);
      print("fields==?${auth.value!.toUpdateProfile()}");
      request.fields.addAll({
        'id': '${auth.value!.id}',
        'name': '${auth.value!.name}',
        'email': '${auth.value!.email}',
        'phone': '${auth.value!.phone}',
        'address': '${auth.value!.address}',
        'city': '${auth.value!.city}',
        'state': '${auth.value!.state}',
        'country': '${auth.value!.country}',
        'pincode': '${auth.value!.pincode}',
      });
      if(file!=null) {
        request.files.add(await MultipartFile.fromPath('profileimg', file.path));
      }
      StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        print(await response.stream.bytesToString());
        return "Profile Uploaded Successfully";
      }
      else {
        print(response.reasonPhrase);
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> deleteAccount() async {
    try {
      final response = await client.get(
        Uri.parse("${Apis.profiledelete}/${auth.value!.id}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('deleteAccount ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return "Account delete successfully";
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> contactUs(ContactUsParams param) async {
    try {
      final response = await client.post(
        Uri.parse(Apis.contactUs),
        headers: {
          'content-type': 'application/json',
        },
        body: jsonEncode({
          "name":param.name,
          "email":param.email,
          "phone":param.phone,
          "messages":param.message,
        })
      );
      log('contactUs ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return "Request submitted successfully";
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<List<SupportModel>> getSupport(param) async {
    try {
      final response = await client.get(
          Uri.parse('${Apis.support}/$param'),
          headers: {
            'content-type': 'application/json',
          },
      );
      log('contactUs ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        List<SupportModel>list=[];
        for(var v in jsonDecode(response.body)){
          list.add(SupportModel.fromJson(v));
        }
        return list;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> getPrivacyPolicy(param) async {
    try {
      final response = await client.get(
        Uri.parse('${Apis.privacypolicy}/$param'),
        headers: {
          'content-type': 'application/json',
        },
      );
      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> getTerm(param) async {
    try {
      final response = await client.get(
        Uri.parse('${Apis.termsandconditions}/$param'),
        headers: {
          'content-type': 'application/json',
        },
      );
      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

}
