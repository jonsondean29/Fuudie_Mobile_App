import 'package:dartz/dartz.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';

@LazySingleton()
class PrivacyPolicyUsecase implements UseCaseWithParams<void, String> {
  final AccountRepository accountRepository;

  PrivacyPolicyUsecase({required this.accountRepository});
  @override
  Future<Either<Failure, String>> call(params) {
    return accountRepository.getPrivacyPolicy(params);
  }
}

