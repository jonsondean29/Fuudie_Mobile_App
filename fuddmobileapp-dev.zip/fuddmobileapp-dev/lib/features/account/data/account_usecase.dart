import 'package:dartz/dartz.dart';
import 'package:fuud/features/account/data/repo/account_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import '../../../core/model/user_details.dart';

@LazySingleton()
class AccountUsecase implements UseCaseWithoutParams {
  final AccountRepository repository;

  AccountUsecase({required this.repository});
  @override
  Future<Either<Failure, UserDetails>> call() {
    return repository.getProfile();
  }
}
