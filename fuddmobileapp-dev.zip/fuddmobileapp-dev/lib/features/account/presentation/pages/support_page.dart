import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../../core/constants/storege.dart';
import '../../data/model/support_model.dart';
@RoutePage()
class SupportPage extends StatefulWidget {
  const SupportPage({super.key});
  static const routeName = 'support_page';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<SupportPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
   bool isLoading=false;

  List<SupportModel>list=[];
  @override
  void initState() {

    Future.delayed(Duration(milliseconds: 500),() async {
      Map<String,dynamic> res= await getDefaultCountry();
      context.read<AccountBloc>().add(getSupport(res['selectedcountry']));
    },);
    context.read<AccountBloc>().stream.listen((state) {
      if(isLoading!=state.isLoading) {
        setState(() {
          isLoading=state.isLoading;
        });
      }
      if(state.supportList!=null){
        setState(() {
          list=state.supportList??[];
        });
      }

    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: 'Support', scaffoldKey: _scaffoldKey, locationImage: true),
      body:_body(),
    );
  }
  Widget _body(){
    if(isLoading){
      return LoadingWidget(type: LoadingType.LIST,);
    }
    return ListView.builder(itemBuilder: (context, index) {
      return ExpansionTile(title: Text("${list[index].title}",style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold
      ),),
        children: [
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
            child: WebViewWidget(controller: WebViewController()..loadHtmlString('${list[index].details}'),),)
        ],);
    },itemCount: list.length,shrinkWrap: true,);
  }

}
