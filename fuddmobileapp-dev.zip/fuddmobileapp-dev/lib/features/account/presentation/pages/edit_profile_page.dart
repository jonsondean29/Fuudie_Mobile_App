import 'dart:io';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../config/theme/colors.dart';

@RoutePage()
class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});
  static const routeName = 'edit_profile';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<EditProfilePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  var nameCon=TextEditingController();
  var phoneCon=TextEditingController();
  var cityCon=TextEditingController();
  var stateCon=TextEditingController();
  var addressCon=TextEditingController();
  var countryCon=TextEditingController();
  var pincodeCon=TextEditingController();
  final formKey = GlobalKey<FormState>();
  final ImagePicker picker = ImagePicker();
   XFile? image;
   bool isLoading=false;
  @override
  void initState() {
    nameCon.text='${auth.value!.name}';
    phoneCon.text='${auth.value!.phone}';
    cityCon.text='${auth.value!.city}';
    stateCon.text='${auth.value!.state}';
    addressCon.text='${auth.value!.address}';
    countryCon.text='${auth.value!.country}';
    pincodeCon.text='${auth.value!.pincode}';
    context.read<AccountBloc>().stream.listen((state) {
      if(isLoading!=state.isLoading) {
        setState(() {
          isLoading=state.isLoading;
        });
      }
    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: false),
      body: AbsorbPointer(
        absorbing: isLoading,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Gap(10),
            InkWell(
              onTap: () {
                picker.pickImage(source: ImageSource.gallery).then((value) {
                  setState(() {
                    image=value;
                  });
                },);
              },
              child: _profile(),
            ),
            Text('${auth.value!.name}',style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold
            ),),
            const Divider(),
            Expanded(child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('Email',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: TextEditingController()..text='${auth.value!.email}',
                          readOnly: true,
                        ),),
                      ],
                    ),
                  ),
                  Form(key: formKey,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                      child: Row(
                        children: [
                          const Expanded(flex: 1,child: Text('Name',style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold
                          ),),),
                          Expanded(flex: 2,child: InputField(controller: nameCon,
                            hintText: "Enter name",
                            suffixIcon: const Icon(Icons.edit),
                          ),),
                        ],
                      ),
                    ),),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('Phone',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: phoneCon,
                          hintText: "Enter phone",
                          keyboardType: TextInputType.phone,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('City',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: cityCon,
                          hintText: "Enter city",
                          keyboardType: TextInputType.text,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('State',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: stateCon,
                          hintText: "Enter state",
                          keyboardType: TextInputType.text,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('Address',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: addressCon,
                          hintText: "Enter Address",
                          keyboardType: TextInputType.text,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('Country',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: countryCon,
                          hintText: "Enter Country",
                          keyboardType: TextInputType.text,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    child: Row(
                      children: [
                        const Expanded(flex: 1,child: Text('Pincode',style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold
                        ),),),
                        Expanded(flex: 2,child: InputField(controller: pincodeCon,
                          hintText: "Enter Pincode",
                          keyboardType: TextInputType.number,
                          suffixIcon: const Icon(Icons.edit),
                        ),),
                      ],
                    ),
                  ),
                  InkWell(
                    child: AnimatedContainer(
                      height: 50,
                      margin: const EdgeInsets.symmetric(horizontal: 30,vertical: 20),
                      width: isLoading?50:MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          color: AppColors.black,
                          borderRadius:
                          BorderRadius.circular(50)),
                      duration: const Duration(milliseconds: 500),
                      child:  Center(
                        child:isLoading?const CircularProgressIndicator(
                          color: Colors.white,
                        ): const Text(
                          'Update',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    onTap: (){
                      if(formKey.currentState!.validate()){
                        auth.value!.name=nameCon.text;
                        auth.value!.phone=phoneCon.text;
                        auth.value!.city=cityCon.text;
                        auth.value!.state=stateCon.text;
                        auth.value!.address=addressCon.text;
                        auth.value!.country=countryCon.text;
                        auth.value!.pincode=pincodeCon.text;
                        context.read<AccountBloc>().add(UpdateProfile(file: image!=null?File(image!.path):null));
                      }
                    },
                  )
                ],
              )
            ))

          ],
        ),
      ),
    );
  }
  Widget _profile(){
    if(image!=null){
      return Container(
        height: 80,
        width: 80,
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.black,width: 1)
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.all(Radius.circular(40)),
          child: Image.file(File(image!.path),height: 80,width: 80,fit: BoxFit.cover,),
        ),
      );
    }
    return Container(
      height: 80,
      width: 80,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black,width: 1)
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(40)),
        child: NetworkImageWidget(url: "${Apis.baseUrl}${auth.value!.profileimg}",height: 80,width: 80,),
      ),
    );
  }
}
