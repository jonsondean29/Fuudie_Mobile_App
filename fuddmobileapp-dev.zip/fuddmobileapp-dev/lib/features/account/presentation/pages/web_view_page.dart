import 'dart:io';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/account/data/contact_us_usecase.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:image_picker/image_picker.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../../config/theme/colors.dart';

@RoutePage()
class WebViewPage extends StatefulWidget {
   WebViewPage({super.key,required this.url});
  String url;
  static const routeName = 'web_view';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<WebViewPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  WebViewController? controller;
  int progress=0;
  @override
  void initState() {
    print("url==>${widget.url}");
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progresss) {
            setState(() {
              progress=progresss;
              print('progress${progress}');
            });
          },
          onPageStarted: (String url) {},
          onPageFinished: (String url) {},
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            if (request.url.startsWith('https://www.youtube.com/')) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      body:Stack(
        children: [
          Expanded(child: WebViewWidget(controller: controller!)),
          if(progress>0&&progress<100)
            LinearProgressIndicator(
              value: progress/100,
              backgroundColor: Colors.grey.shade200,
              color: Colors.grey.shade200,
              valueColor: const AlwaysStoppedAnimation(Colors.green),
            )
        ],
      ),
    );
  }

}
