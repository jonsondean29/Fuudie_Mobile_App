import 'dart:io';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/account/data/contact_us_usecase.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../config/theme/colors.dart';

@RoutePage()
class ContactUsPage extends StatefulWidget {
  const ContactUsPage({super.key});
  static const routeName = 'contact_us';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<ContactUsPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  var nameCon=TextEditingController();
  var phoneCon=TextEditingController();
  var emailCon=TextEditingController();
  var messageCon=TextEditingController();
  final formKey = GlobalKey<FormState>();
   bool isLoading=false;
  @override
  void initState() {
    nameCon.text=auth.value!.name??"";
    phoneCon.text=auth.value!.phone??"";
    emailCon.text=auth.value!.email??"";
    context.read<AccountBloc>().stream.listen((state) {
      if(isLoading!=state.isLoading) {
        setState(() {
          isLoading=state.isLoading;
        });
      }
    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: 'Contact Us', scaffoldKey: _scaffoldKey, locationImage: true),
      body: AbsorbPointer(
        absorbing: isLoading,
        child: SingleChildScrollView(
            child: Form(key: formKey,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InputField(controller: nameCon,
                      hintText: "Enter name",
                    ),
                    const SizedBox(height: 20,),

                    InputField(controller: emailCon,
                      hintText: "Enter email",
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 20,),

                    InputField(controller: phoneCon,
                      hintText: "Enter phone",
                      keyboardType: TextInputType.phone,
                    ),
                    const SizedBox(height: 20,),

                    InputField(controller: messageCon,
                      hintText: "Enter message",
                      maxLines: 5,
                    ),
                    const SizedBox(height: 30,),
                    InkWell(
                      child: AnimatedContainer(
                        height: 50,
                        margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 20),
                        width: isLoading?50:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: AppColors.black,
                            borderRadius:
                            BorderRadius.circular(50)),
                        duration: const Duration(milliseconds: 500),
                        child:  Center(
                          child:isLoading?const CircularProgressIndicator(
                            color: Colors.white,
                          ): const Text(
                            'Submit',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      onTap: (){
                        if(formKey.currentState!.validate()){
                          context.read<AccountBloc>().add(AccountEvent.contactUs(ContactUsParams(name: nameCon.text,email: emailCon.text,message: messageCon.text,phone: phoneCon.text)));
                        context.popRoute();
                        }
                      },
                    )
                  ],
                ),
              ),)
        ),
      ),
    );
  }

}
