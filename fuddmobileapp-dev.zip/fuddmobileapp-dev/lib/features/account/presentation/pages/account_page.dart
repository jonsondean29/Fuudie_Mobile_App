import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/account/presentation/bloc/account_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:rxdart/rxdart.dart';
import '../../../../core/constants/storege.dart';
import '../../../../generated/assets.dart';
import '../../../home/data/models/home_response.dart';
import '../../../home/presentation/bloc/home_bloc.dart';

@RoutePage()
class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  static const routeName = 'account';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<AccountPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final searchController = TextEditingController();
  List<Restrolist>listOld=[];
  List<Restrolist>list=[];
  int totalFab=0;
  int totalTested=0;
  int totalTry=0;
  final searchOnChange =  BehaviorSubject<String>();

    void InitSearch(){
    searchOnChange.debounceTime(const Duration(milliseconds: 300))
        .listen((queryString) async {
          list=listOld.where((element) => element.name!.toLowerCase().contains(queryString.toLowerCase()),).toList();
          setState(() {});
        });
  }
  @override
  void initState() {
    // TODO: implement initState
    InitSearch();
    Future.delayed(const Duration(milliseconds: 500),() async {
     context.read<AccountBloc>().add(const GetProfile());
     context.read<AccountBloc>().add(const GetWTTList());
    },);
    context.read<AccountBloc>().stream.listen((state) {
      if(state.list!.isNotEmpty){
        setState(() {
          list=state.list!;
          listOld=state.list!;
          totalFab=list.where((element) => element.iswishlist==1).toList().length;
          totalTested=list.where((element) => element.isbeenlist==1).toList().length;
          totalTry=list.where((element) => element.istrylist==1).toList().length;
        });
      }
    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const AppDrawer(),
      backgroundColor: Colors.white,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Gap(10),
            BlocBuilder<AccountBloc, AccountState>(
              builder: (context, state) {
                if (state.isLoading) {
                  return const CircularProgressIndicator();
                }
                if(state.userDetails==null){
                  return const Text("Login again");
                }
                return Container(
                  margin: const EdgeInsets.all(15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        children: [
                          CircleAvatar(
                            radius: 35,
                            child: ClipOval(
                              child: NetworkImageWidget(url: "${Apis.baseUrl}${state.userDetails!.profileimg}",
                              fit: BoxFit.cover,
                              height: 80,width: 80,),
                            ),
                          ),
                          const Gap(10),
                          InkWell(
                            child: Container(
                              height: 30,
                              width: 90,
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black, width: 0.3),
                                  borderRadius: BorderRadius.circular(3),
                                  color: Colors.grey.withOpacity(0.2)),
                              child: const Center(
                                child: Text(
                                  'Edit Profile',
                                  style: TextStyle(fontSize: 10),
                                ),
                              ),
                            ),
                            onTap: (){
                              context.router.push(const EditProfileRoute());
                            },
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Column(
                            children: [
                              Text('${totalFab}'),
                              Image.asset(Assets.imagesWishSelected,width: 25,),
                              const Text('Favourite')
                            ],
                          ),
                          Gap(10),
                          Column(
                            children: [
                              Text('${totalTested}'),
                              Image.asset(Assets.imagesBeenSelected,width: 25,),
                              const Text('Tested')
                            ],
                          ),
                          Gap(10),
                          Column(
                            children: [
                              Text('${totalTry}'),
                              Image.asset(Assets.imagesFlagTrySelected,width: 20,),
                              const Text('Go Try')
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
            Container(
              height: 80,
              decoration: const BoxDecoration(color: Colors.black),
              child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: InputField(
                      hintText: "Search for place area,list or tag",
                      filled: true,
                      suffixIcon: const Icon(Icons.search),
                      fillColour: Colors.white,
                      onChange: (v) {
                        searchOnChange.add(v!);
                      },
                      controller: searchController)),
            ),
            ListView.builder(itemBuilder: (context, index) {
              return InkWell(
                child: Container(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      NetworkImageWidget(url: '${Apis.baseUrl}/${list[index].mainimg}',
                        width: 120,height: 80,),
                      const SizedBox(width: 5,),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${list[index].name}'),
                          Text('${list[index].shortdescription}',
                            style:const TextStyle(
                                fontSize: 12,
                                overflow: TextOverflow.ellipsis
                            ),
                            maxLines: 2,
                          ),
                        ],),
                      ),
                      const SizedBox(width: 5,),
                      Image.asset(list[index].iswishlist==1?Assets.imagesWishSelected:Assets.imagesWish,width: 20,),
                      const SizedBox(width: 5,),
                      Image.asset(list[index].isbeenlist==1?Assets.imagesBeenSelected:Assets.imagesBeen,width: 20,),
                      const SizedBox(width: 5,),
                      Image.asset(list[index].istrylist==1?Assets.imagesFlagTrySelected:Assets.imagesFlagTry,width: 20,),
                      const SizedBox(width: 5,),

                    ],
                  ),
                ),
                onTap: () async {
                  final userid = await getIntValue('id') ?? 0;
                  if (context.mounted) {
                    context
                        .read<HomeBloc>()
                        .add(HomeFeatchDetails(id: userid, resturentId: list[index].id!));
                    context.router.push(const ResturantDetailsRoute());
                  }
                },
              );
            },
              itemCount: list.length,shrinkWrap: true,primary: false,),
          ],
        ),
      ),
    );
  }
}
