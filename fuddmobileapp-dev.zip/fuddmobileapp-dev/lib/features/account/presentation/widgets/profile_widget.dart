import 'package:flutter/material.dart';
import 'package:fuud/features/account/presentation/widgets/change_password.dart';

class ProfileWidget extends StatelessWidget {
  const ProfileWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 160,
          child: Material(
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // state.userDetailsEntity.profileimg != null
                //     ? CircleAvatar(
                //         radius: 50,
                //         backgroundImage: NetworkImage(
                //           '${Apis.baseUrl}${state.userDetailsEntity.profileimg}',
                //         ),
                //       )
                //     :
                const ImageIcon(
                  AssetImage('assets/images/user.png'),
                  size: 180,
                  color: Colors.grey,
                ),
                GestureDetector(
                  onTap: () {
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //       builder: (_) => BlocProvider.value(
                    //         value: BlocProvider.of<UserAccountBloc>(context),
                    //         child: const YourAccount(),
                    //       ),
                    //     ));
                  },
                  child: Container(
                    height: 45,
                    width: 170,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        border:
                            Border.all(width: 1, color: Colors.grey.shade300)),
                    child: const Center(
                      child: Text(
                        'Your Account',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                )
              ],
            ),
          ),
        ),
        Divider(
          thickness: 15,
          color: Colors.grey.shade200,
        ),
        SizedBox(
          height: 200,
          child: Material(
            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // context.go('/profile/order');
                      },
                      child: Container(
                        height: 45,
                        width: 170,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(
                                width: 1, color: Colors.grey.shade300)),
                        child: const Center(
                          child: Text(
                            'Favorite List',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (_) => ChangePassword(),
                        );
                      },
                      child: Container(
                        height: 45,
                        width: 170,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(
                                width: 1, color: Colors.grey.shade300)),
                        child: const Center(
                          child: Text(
                            'Try List',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // context.go('/profile/wishList');
                      },
                      child: Container(
                        height: 45,
                        width: 170,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(
                                width: 1, color: Colors.grey.shade300)),
                        child: const Center(
                          child: Text(
                            'Tested List',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (_) => BlocProvider.value(
                        //         value:
                        //             BlocProvider.of<UserAccountBloc>(context),
                        //         child: const RewardScreen(),
                        //       ),
                        //     ));
                      },
                      child: Container(
                        height: 45,
                        width: 170,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(
                                width: 1, color: Colors.grey.shade300)),
                        child: const Center(
                          child: Text(
                            'Change password',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
        Divider(
          thickness: 15,
          color: Colors.grey.shade200,
        ),
      ],
    );
  }
}
