import 'dart:convert';
import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/features/account/data/account_usecase.dart';
import 'package:fuud/features/account/data/delete_account_usecase.dart';
import 'package:fuud/features/account/data/privacy_policy_usecase.dart';
import 'package:fuud/features/account/data/support_usecase.dart';
import 'package:fuud/features/account/data/term_usecase.dart';
import 'package:fuud/features/account/data/wtt_usecase.dart';
import 'package:injectable/injectable.dart';
import '../../../../core/model/user_details.dart';
import '../../../home/data/models/home_response.dart';
import '../../data/contact_us_usecase.dart';
import '../../data/model/support_model.dart';
import '../../data/update_profile_usecase.dart';
part 'account_event.dart';
part 'account_state.dart';
part 'account_bloc.freezed.dart';

@injectable
class AccountBloc extends Bloc<AccountEvent, AccountState> {
  final AccountUsecase accountUsecase;
  final WttUsecase wttUsecase;
  final UpdateProfileUsecase updateProfileUsecase;
  final DeleteAccountUsecase deleteAccountUsecase;
  final ContactUsUsecase contactUsUsecase;
  final SupportUsecase supportUsecase;
  final PrivacyPolicyUsecase policyUsecase;
  final TermUsecase termUsecase;

  AccountBloc({
    required this.accountUsecase,
    required this.updateProfileUsecase,
    required this.deleteAccountUsecase,
    required this.wttUsecase,
    required this.supportUsecase,
    required this.policyUsecase,
    required this.termUsecase,
    required this.contactUsUsecase
}) : super(AccountState.initial()) {
    on<AccountEvent>((event, emit) {});
    on<GetProfile>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await accountUsecase.call();
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        auth.value=r;
        print("getProfileresponse===>${r.toJson()}");
        saveString("data", jsonEncode(r.toJson()));
        emit(state.copyWith( isLoading: false,userDetails: r));
      });
    });
    on<GetWTTList>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await wttUsecase.call();
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false,list: r));
      });
    });
    on<UpdateProfile>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await updateProfileUsecase.call(ProfileParams(file: event.file));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false));
        Fluttertoast.showToast(
            msg: r,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        add(const AccountEvent.getProfile());
      },);
    });
    on<DeleteAccount>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await deleteAccountUsecase.call();
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        Fluttertoast.showToast(
            msg: l.message,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false));
        Fluttertoast.showToast(
            msg: r,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        clearStorage();
        event.context.router.push(const SigninRoute());
      },);
    });
    on<contactUs>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await contactUsUsecase.call(event.param);
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        Fluttertoast.showToast(
            msg: l.message,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false));
        Fluttertoast.showToast(
            msg: r,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
      },);
    });
    on<getSupport>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await supportUsecase.call(event.country);
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        Fluttertoast.showToast(
            msg: l.message,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false,supportList: r));

      },);
    });
    on<getPrivacyPolicy>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await policyUsecase.call(event.country);
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        Fluttertoast.showToast(
            msg: l.message,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false,privacyPolicy: r));

      },);
    });
    on<getTerm>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await termUsecase.call(event.country);
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        Fluttertoast.showToast(
            msg: l.message,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
        print('function error $l');
      }, (r) {
        emit(state.copyWith( isLoading: false,privacyPolicy: r));

      },);
    });
  }
}
