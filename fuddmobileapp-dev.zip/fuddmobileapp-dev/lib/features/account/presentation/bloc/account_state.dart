part of 'account_bloc.dart';

@freezed
class AccountState with _$AccountState {
  factory AccountState({
    required bool isLoading,
     UserDetails? userDetails,
    required List<Restrolist>?list,
    required List<SupportModel>?supportList,
    String? privacyPolicy
  }) = _AccountState;
   factory AccountState.initial() =>AccountState(isLoading: false,userDetails: null,list: [],supportList: [],privacyPolicy:null);
}
