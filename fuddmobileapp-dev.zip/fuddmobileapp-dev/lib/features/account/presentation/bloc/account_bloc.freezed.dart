// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'account_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AccountEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AccountEventCopyWith<$Res> {
  factory $AccountEventCopyWith(
          AccountEvent value, $Res Function(AccountEvent) then) =
      _$AccountEventCopyWithImpl<$Res, AccountEvent>;
}

/// @nodoc
class _$AccountEventCopyWithImpl<$Res, $Val extends AccountEvent>
    implements $AccountEventCopyWith<$Res> {
  _$AccountEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'AccountEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements AccountEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetProfileImplCopyWith<$Res> {
  factory _$$GetProfileImplCopyWith(
          _$GetProfileImpl value, $Res Function(_$GetProfileImpl) then) =
      __$$GetProfileImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetProfileImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$GetProfileImpl>
    implements _$$GetProfileImplCopyWith<$Res> {
  __$$GetProfileImplCopyWithImpl(
      _$GetProfileImpl _value, $Res Function(_$GetProfileImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetProfileImpl implements GetProfile {
  const _$GetProfileImpl();

  @override
  String toString() {
    return 'AccountEvent.getProfile()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetProfileImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return getProfile();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return getProfile?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (getProfile != null) {
      return getProfile();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return getProfile(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return getProfile?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (getProfile != null) {
      return getProfile(this);
    }
    return orElse();
  }
}

abstract class GetProfile implements AccountEvent {
  const factory GetProfile() = _$GetProfileImpl;
}

/// @nodoc
abstract class _$$GetWTTListImplCopyWith<$Res> {
  factory _$$GetWTTListImplCopyWith(
          _$GetWTTListImpl value, $Res Function(_$GetWTTListImpl) then) =
      __$$GetWTTListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetWTTListImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$GetWTTListImpl>
    implements _$$GetWTTListImplCopyWith<$Res> {
  __$$GetWTTListImplCopyWithImpl(
      _$GetWTTListImpl _value, $Res Function(_$GetWTTListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetWTTListImpl implements GetWTTList {
  const _$GetWTTListImpl();

  @override
  String toString() {
    return 'AccountEvent.getWTTlist()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetWTTListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return getWTTlist();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return getWTTlist?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (getWTTlist != null) {
      return getWTTlist();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return getWTTlist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return getWTTlist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (getWTTlist != null) {
      return getWTTlist(this);
    }
    return orElse();
  }
}

abstract class GetWTTList implements AccountEvent {
  const factory GetWTTList() = _$GetWTTListImpl;
}

/// @nodoc
abstract class _$$UpdateProfileImplCopyWith<$Res> {
  factory _$$UpdateProfileImplCopyWith(
          _$UpdateProfileImpl value, $Res Function(_$UpdateProfileImpl) then) =
      __$$UpdateProfileImplCopyWithImpl<$Res>;
  @useResult
  $Res call({File? file});
}

/// @nodoc
class __$$UpdateProfileImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$UpdateProfileImpl>
    implements _$$UpdateProfileImplCopyWith<$Res> {
  __$$UpdateProfileImplCopyWithImpl(
      _$UpdateProfileImpl _value, $Res Function(_$UpdateProfileImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? file = freezed,
  }) {
    return _then(_$UpdateProfileImpl(
      file: freezed == file
          ? _value.file
          : file // ignore: cast_nullable_to_non_nullable
              as File?,
    ));
  }
}

/// @nodoc

class _$UpdateProfileImpl implements UpdateProfile {
  const _$UpdateProfileImpl({this.file});

  @override
  final File? file;

  @override
  String toString() {
    return 'AccountEvent.updateProfile(file: $file)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateProfileImpl &&
            (identical(other.file, file) || other.file == file));
  }

  @override
  int get hashCode => Object.hash(runtimeType, file);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateProfileImplCopyWith<_$UpdateProfileImpl> get copyWith =>
      __$$UpdateProfileImplCopyWithImpl<_$UpdateProfileImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return updateProfile(file);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return updateProfile?.call(file);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (updateProfile != null) {
      return updateProfile(file);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return updateProfile(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return updateProfile?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (updateProfile != null) {
      return updateProfile(this);
    }
    return orElse();
  }
}

abstract class UpdateProfile implements AccountEvent {
  const factory UpdateProfile({final File? file}) = _$UpdateProfileImpl;

  File? get file;
  @JsonKey(ignore: true)
  _$$UpdateProfileImplCopyWith<_$UpdateProfileImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$contactUsImplCopyWith<$Res> {
  factory _$$contactUsImplCopyWith(
          _$contactUsImpl value, $Res Function(_$contactUsImpl) then) =
      __$$contactUsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ContactUsParams param});
}

/// @nodoc
class __$$contactUsImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$contactUsImpl>
    implements _$$contactUsImplCopyWith<$Res> {
  __$$contactUsImplCopyWithImpl(
      _$contactUsImpl _value, $Res Function(_$contactUsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? param = null,
  }) {
    return _then(_$contactUsImpl(
      null == param
          ? _value.param
          : param // ignore: cast_nullable_to_non_nullable
              as ContactUsParams,
    ));
  }
}

/// @nodoc

class _$contactUsImpl implements contactUs {
  const _$contactUsImpl(this.param);

  @override
  final ContactUsParams param;

  @override
  String toString() {
    return 'AccountEvent.contactUs(param: $param)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$contactUsImpl &&
            (identical(other.param, param) || other.param == param));
  }

  @override
  int get hashCode => Object.hash(runtimeType, param);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$contactUsImplCopyWith<_$contactUsImpl> get copyWith =>
      __$$contactUsImplCopyWithImpl<_$contactUsImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return contactUs(param);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return contactUs?.call(param);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (contactUs != null) {
      return contactUs(param);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return contactUs(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return contactUs?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (contactUs != null) {
      return contactUs(this);
    }
    return orElse();
  }
}

abstract class contactUs implements AccountEvent {
  const factory contactUs(final ContactUsParams param) = _$contactUsImpl;

  ContactUsParams get param;
  @JsonKey(ignore: true)
  _$$contactUsImplCopyWith<_$contactUsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DeleteAccountImplCopyWith<$Res> {
  factory _$$DeleteAccountImplCopyWith(
          _$DeleteAccountImpl value, $Res Function(_$DeleteAccountImpl) then) =
      __$$DeleteAccountImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DeleteAccountImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$DeleteAccountImpl>
    implements _$$DeleteAccountImplCopyWith<$Res> {
  __$$DeleteAccountImplCopyWithImpl(
      _$DeleteAccountImpl _value, $Res Function(_$DeleteAccountImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DeleteAccountImpl(
      null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DeleteAccountImpl implements DeleteAccount {
  const _$DeleteAccountImpl(this.context);

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AccountEvent.DeleteAccount(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeleteAccountImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeleteAccountImplCopyWith<_$DeleteAccountImpl> get copyWith =>
      __$$DeleteAccountImplCopyWithImpl<_$DeleteAccountImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return DeleteAccount(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return DeleteAccount?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (DeleteAccount != null) {
      return DeleteAccount(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return DeleteAccount(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return DeleteAccount?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (DeleteAccount != null) {
      return DeleteAccount(this);
    }
    return orElse();
  }
}

abstract class DeleteAccount implements AccountEvent {
  const factory DeleteAccount(final BuildContext context) = _$DeleteAccountImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DeleteAccountImplCopyWith<_$DeleteAccountImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getSupportImplCopyWith<$Res> {
  factory _$$getSupportImplCopyWith(
          _$getSupportImpl value, $Res Function(_$getSupportImpl) then) =
      __$$getSupportImplCopyWithImpl<$Res>;
  @useResult
  $Res call({dynamic country});
}

/// @nodoc
class __$$getSupportImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$getSupportImpl>
    implements _$$getSupportImplCopyWith<$Res> {
  __$$getSupportImplCopyWithImpl(
      _$getSupportImpl _value, $Res Function(_$getSupportImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? country = freezed,
  }) {
    return _then(_$getSupportImpl(
      freezed == country ? _value.country! : country,
    ));
  }
}

/// @nodoc

class _$getSupportImpl implements getSupport {
  const _$getSupportImpl(this.country);

  @override
  final dynamic country;

  @override
  String toString() {
    return 'AccountEvent.getSupport(country: $country)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSupportImpl &&
            const DeepCollectionEquality().equals(other.country, country));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(country));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSupportImplCopyWith<_$getSupportImpl> get copyWith =>
      __$$getSupportImplCopyWithImpl<_$getSupportImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return getSupport(country);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return getSupport?.call(country);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (getSupport != null) {
      return getSupport(country);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return getSupport(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return getSupport?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (getSupport != null) {
      return getSupport(this);
    }
    return orElse();
  }
}

abstract class getSupport implements AccountEvent {
  const factory getSupport(final dynamic country) = _$getSupportImpl;

  dynamic get country;
  @JsonKey(ignore: true)
  _$$getSupportImplCopyWith<_$getSupportImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPrivacyPolicyImplCopyWith<$Res> {
  factory _$$getPrivacyPolicyImplCopyWith(_$getPrivacyPolicyImpl value,
          $Res Function(_$getPrivacyPolicyImpl) then) =
      __$$getPrivacyPolicyImplCopyWithImpl<$Res>;
  @useResult
  $Res call({dynamic country});
}

/// @nodoc
class __$$getPrivacyPolicyImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$getPrivacyPolicyImpl>
    implements _$$getPrivacyPolicyImplCopyWith<$Res> {
  __$$getPrivacyPolicyImplCopyWithImpl(_$getPrivacyPolicyImpl _value,
      $Res Function(_$getPrivacyPolicyImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? country = freezed,
  }) {
    return _then(_$getPrivacyPolicyImpl(
      freezed == country ? _value.country! : country,
    ));
  }
}

/// @nodoc

class _$getPrivacyPolicyImpl implements getPrivacyPolicy {
  const _$getPrivacyPolicyImpl(this.country);

  @override
  final dynamic country;

  @override
  String toString() {
    return 'AccountEvent.getPrivacyPolicy(country: $country)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPrivacyPolicyImpl &&
            const DeepCollectionEquality().equals(other.country, country));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(country));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPrivacyPolicyImplCopyWith<_$getPrivacyPolicyImpl> get copyWith =>
      __$$getPrivacyPolicyImplCopyWithImpl<_$getPrivacyPolicyImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return getPrivacyPolicy(country);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return getPrivacyPolicy?.call(country);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (getPrivacyPolicy != null) {
      return getPrivacyPolicy(country);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return getPrivacyPolicy(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return getPrivacyPolicy?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (getPrivacyPolicy != null) {
      return getPrivacyPolicy(this);
    }
    return orElse();
  }
}

abstract class getPrivacyPolicy implements AccountEvent {
  const factory getPrivacyPolicy(final dynamic country) =
      _$getPrivacyPolicyImpl;

  dynamic get country;
  @JsonKey(ignore: true)
  _$$getPrivacyPolicyImplCopyWith<_$getPrivacyPolicyImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getTermImplCopyWith<$Res> {
  factory _$$getTermImplCopyWith(
          _$getTermImpl value, $Res Function(_$getTermImpl) then) =
      __$$getTermImplCopyWithImpl<$Res>;
  @useResult
  $Res call({dynamic country});
}

/// @nodoc
class __$$getTermImplCopyWithImpl<$Res>
    extends _$AccountEventCopyWithImpl<$Res, _$getTermImpl>
    implements _$$getTermImplCopyWith<$Res> {
  __$$getTermImplCopyWithImpl(
      _$getTermImpl _value, $Res Function(_$getTermImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? country = freezed,
  }) {
    return _then(_$getTermImpl(
      freezed == country ? _value.country! : country,
    ));
  }
}

/// @nodoc

class _$getTermImpl implements getTerm {
  const _$getTermImpl(this.country);

  @override
  final dynamic country;

  @override
  String toString() {
    return 'AccountEvent.getTerm(country: $country)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getTermImpl &&
            const DeepCollectionEquality().equals(other.country, country));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(country));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getTermImplCopyWith<_$getTermImpl> get copyWith =>
      __$$getTermImplCopyWithImpl<_$getTermImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfile,
    required TResult Function() getWTTlist,
    required TResult Function(File? file) updateProfile,
    required TResult Function(ContactUsParams param) contactUs,
    required TResult Function(BuildContext context) DeleteAccount,
    required TResult Function(dynamic country) getSupport,
    required TResult Function(dynamic country) getPrivacyPolicy,
    required TResult Function(dynamic country) getTerm,
  }) {
    return getTerm(country);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfile,
    TResult? Function()? getWTTlist,
    TResult? Function(File? file)? updateProfile,
    TResult? Function(ContactUsParams param)? contactUs,
    TResult? Function(BuildContext context)? DeleteAccount,
    TResult? Function(dynamic country)? getSupport,
    TResult? Function(dynamic country)? getPrivacyPolicy,
    TResult? Function(dynamic country)? getTerm,
  }) {
    return getTerm?.call(country);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfile,
    TResult Function()? getWTTlist,
    TResult Function(File? file)? updateProfile,
    TResult Function(ContactUsParams param)? contactUs,
    TResult Function(BuildContext context)? DeleteAccount,
    TResult Function(dynamic country)? getSupport,
    TResult Function(dynamic country)? getPrivacyPolicy,
    TResult Function(dynamic country)? getTerm,
    required TResult orElse(),
  }) {
    if (getTerm != null) {
      return getTerm(country);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetProfile value) getProfile,
    required TResult Function(GetWTTList value) getWTTlist,
    required TResult Function(UpdateProfile value) updateProfile,
    required TResult Function(contactUs value) contactUs,
    required TResult Function(DeleteAccount value) DeleteAccount,
    required TResult Function(getSupport value) getSupport,
    required TResult Function(getPrivacyPolicy value) getPrivacyPolicy,
    required TResult Function(getTerm value) getTerm,
  }) {
    return getTerm(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetProfile value)? getProfile,
    TResult? Function(GetWTTList value)? getWTTlist,
    TResult? Function(UpdateProfile value)? updateProfile,
    TResult? Function(contactUs value)? contactUs,
    TResult? Function(DeleteAccount value)? DeleteAccount,
    TResult? Function(getSupport value)? getSupport,
    TResult? Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult? Function(getTerm value)? getTerm,
  }) {
    return getTerm?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetProfile value)? getProfile,
    TResult Function(GetWTTList value)? getWTTlist,
    TResult Function(UpdateProfile value)? updateProfile,
    TResult Function(contactUs value)? contactUs,
    TResult Function(DeleteAccount value)? DeleteAccount,
    TResult Function(getSupport value)? getSupport,
    TResult Function(getPrivacyPolicy value)? getPrivacyPolicy,
    TResult Function(getTerm value)? getTerm,
    required TResult orElse(),
  }) {
    if (getTerm != null) {
      return getTerm(this);
    }
    return orElse();
  }
}

abstract class getTerm implements AccountEvent {
  const factory getTerm(final dynamic country) = _$getTermImpl;

  dynamic get country;
  @JsonKey(ignore: true)
  _$$getTermImplCopyWith<_$getTermImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$AccountState {
  bool get isLoading => throw _privateConstructorUsedError;
  UserDetails? get userDetails => throw _privateConstructorUsedError;
  List<Restrolist>? get list => throw _privateConstructorUsedError;
  List<SupportModel>? get supportList => throw _privateConstructorUsedError;
  String? get privacyPolicy => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AccountStateCopyWith<AccountState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AccountStateCopyWith<$Res> {
  factory $AccountStateCopyWith(
          AccountState value, $Res Function(AccountState) then) =
      _$AccountStateCopyWithImpl<$Res, AccountState>;
  @useResult
  $Res call(
      {bool isLoading,
      UserDetails? userDetails,
      List<Restrolist>? list,
      List<SupportModel>? supportList,
      String? privacyPolicy});
}

/// @nodoc
class _$AccountStateCopyWithImpl<$Res, $Val extends AccountState>
    implements $AccountStateCopyWith<$Res> {
  _$AccountStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? userDetails = freezed,
    Object? list = freezed,
    Object? supportList = freezed,
    Object? privacyPolicy = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      userDetails: freezed == userDetails
          ? _value.userDetails
          : userDetails // ignore: cast_nullable_to_non_nullable
              as UserDetails?,
      list: freezed == list
          ? _value.list
          : list // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>?,
      supportList: freezed == supportList
          ? _value.supportList
          : supportList // ignore: cast_nullable_to_non_nullable
              as List<SupportModel>?,
      privacyPolicy: freezed == privacyPolicy
          ? _value.privacyPolicy
          : privacyPolicy // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AccountStateImplCopyWith<$Res>
    implements $AccountStateCopyWith<$Res> {
  factory _$$AccountStateImplCopyWith(
          _$AccountStateImpl value, $Res Function(_$AccountStateImpl) then) =
      __$$AccountStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoading,
      UserDetails? userDetails,
      List<Restrolist>? list,
      List<SupportModel>? supportList,
      String? privacyPolicy});
}

/// @nodoc
class __$$AccountStateImplCopyWithImpl<$Res>
    extends _$AccountStateCopyWithImpl<$Res, _$AccountStateImpl>
    implements _$$AccountStateImplCopyWith<$Res> {
  __$$AccountStateImplCopyWithImpl(
      _$AccountStateImpl _value, $Res Function(_$AccountStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? userDetails = freezed,
    Object? list = freezed,
    Object? supportList = freezed,
    Object? privacyPolicy = freezed,
  }) {
    return _then(_$AccountStateImpl(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      userDetails: freezed == userDetails
          ? _value.userDetails
          : userDetails // ignore: cast_nullable_to_non_nullable
              as UserDetails?,
      list: freezed == list
          ? _value._list
          : list // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>?,
      supportList: freezed == supportList
          ? _value._supportList
          : supportList // ignore: cast_nullable_to_non_nullable
              as List<SupportModel>?,
      privacyPolicy: freezed == privacyPolicy
          ? _value.privacyPolicy
          : privacyPolicy // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$AccountStateImpl implements _AccountState {
  _$AccountStateImpl(
      {required this.isLoading,
      this.userDetails,
      required final List<Restrolist>? list,
      required final List<SupportModel>? supportList,
      this.privacyPolicy})
      : _list = list,
        _supportList = supportList;

  @override
  final bool isLoading;
  @override
  final UserDetails? userDetails;
  final List<Restrolist>? _list;
  @override
  List<Restrolist>? get list {
    final value = _list;
    if (value == null) return null;
    if (_list is EqualUnmodifiableListView) return _list;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SupportModel>? _supportList;
  @override
  List<SupportModel>? get supportList {
    final value = _supportList;
    if (value == null) return null;
    if (_supportList is EqualUnmodifiableListView) return _supportList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final String? privacyPolicy;

  @override
  String toString() {
    return 'AccountState(isLoading: $isLoading, userDetails: $userDetails, list: $list, supportList: $supportList, privacyPolicy: $privacyPolicy)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AccountStateImpl &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.userDetails, userDetails) ||
                other.userDetails == userDetails) &&
            const DeepCollectionEquality().equals(other._list, _list) &&
            const DeepCollectionEquality()
                .equals(other._supportList, _supportList) &&
            (identical(other.privacyPolicy, privacyPolicy) ||
                other.privacyPolicy == privacyPolicy));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isLoading,
      userDetails,
      const DeepCollectionEquality().hash(_list),
      const DeepCollectionEquality().hash(_supportList),
      privacyPolicy);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AccountStateImplCopyWith<_$AccountStateImpl> get copyWith =>
      __$$AccountStateImplCopyWithImpl<_$AccountStateImpl>(this, _$identity);
}

abstract class _AccountState implements AccountState {
  factory _AccountState(
      {required final bool isLoading,
      final UserDetails? userDetails,
      required final List<Restrolist>? list,
      required final List<SupportModel>? supportList,
      final String? privacyPolicy}) = _$AccountStateImpl;

  @override
  bool get isLoading;
  @override
  UserDetails? get userDetails;
  @override
  List<Restrolist>? get list;
  @override
  List<SupportModel>? get supportList;
  @override
  String? get privacyPolicy;
  @override
  @JsonKey(ignore: true)
  _$$AccountStateImplCopyWith<_$AccountStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
