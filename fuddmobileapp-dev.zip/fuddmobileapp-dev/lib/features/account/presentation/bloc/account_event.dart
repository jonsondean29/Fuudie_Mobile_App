part of 'account_bloc.dart';

@freezed
class AccountEvent with _$AccountEvent {
  const factory AccountEvent.started() = _Started;
  const factory AccountEvent.getProfile() = GetProfile;
  const factory AccountEvent.getWTTlist() = GetWTTList;
  const factory AccountEvent.updateProfile({File? file}) = UpdateProfile;
  const factory AccountEvent.contactUs(ContactUsParams param) = contactUs;
  const factory AccountEvent.DeleteAccount(BuildContext context) = DeleteAccount;
  const factory AccountEvent.getSupport(country) = getSupport;
  const factory AccountEvent.getPrivacyPolicy(country) = getPrivacyPolicy;
  const factory AccountEvent.getTerm(country) = getTerm;
}