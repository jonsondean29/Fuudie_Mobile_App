import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:injectable/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/usecases/get_comments_usecase.dart';

import '../../domain/entities/community_response.dart';
import '../../domain/usecases/action_community_usecase.dart';
import '../../domain/usecases/add_post_usecase.dart';
import '../../domain/usecases/add_reply_usecase.dart';
import '../../domain/usecases/get_post_comment_usecase.dart';

part 'activity_event.dart';
part 'activity_state.dart';
part 'activity_bloc.freezed.dart';

@injectable
class ActivityBloc extends Bloc<ActivityEvent, ActivityState> {
  final GetCommentsUsecase getCommentsUsecase;
  final AddPostUsecase addPostUsecase;
  final GetPostCommentUsecase getPostCommentUsecase;
  final AddReplyUsecase addReplyUsecase;
  final ActionCommunityUsecase actionCommunityUsecase;
  ActivityBloc({required this.getCommentsUsecase,
    required this.addPostUsecase,
    required this.addReplyUsecase,
    required this.actionCommunityUsecase,
    required this.getPostCommentUsecase})
      : super(ActivityState.initial()) {

    on<GetCommets>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await getCommentsUsecase.call();
      result.fold((l) => null,
          (r) => emit(state.copyWith(isLoading: false, communityList: r)));
    });

    on<AddPost>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await addPostUsecase.call(AddPostParams(title: event.title, description: event.description));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
      }, (r) {

      },);
    });
    on<GetCommentDetails>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await getPostCommentUsecase.call(CommentParams(id: event.id,slag: event.slag));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
      }, (r) {
        emit(state.copyWith(isLoading: false,commentResponse: r));
      },);
    });
    on<AddReply>((event, emit) async {
      final result = await addReplyUsecase.call(event.param);
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
      }, (r) {
        emit(state.copyWith(isLoading: false,reply: r));
      },);
    });
    on<ActionCommunity>((event, emit) async {
      actionCommunityUsecase.call(ActionCommunityParams(actionType: event.type, id: event.id)).then((value) {
        value.fold((l) {
        }, (r) {
          Fluttertoast.showToast(
              msg: r,
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.white,
              textColor: Colors.black,
              fontSize: 16.0);
        },);
      },);
    },);
  }
}
