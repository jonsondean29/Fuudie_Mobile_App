part of 'activity_bloc.dart';

@freezed
class ActivityEvent with _$ActivityEvent {
  const factory ActivityEvent.started() = _Started;
  const factory ActivityEvent.getCommets() = GetCommets;
  const factory ActivityEvent.addPost({required String title,required String description}) = AddPost;
  const factory ActivityEvent.addReply({required AddReplyParams param}) = AddReply;
  const factory ActivityEvent.getCommentDetails({required dynamic id,required String slag}) = GetCommentDetails;
  const factory ActivityEvent.actionCommunity({required dynamic id,required ActionType type}) = ActionCommunity;
}
