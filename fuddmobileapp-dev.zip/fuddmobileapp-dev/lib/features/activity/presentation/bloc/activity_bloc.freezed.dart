// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'activity_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ActivityEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActivityEventCopyWith<$Res> {
  factory $ActivityEventCopyWith(
          ActivityEvent value, $Res Function(ActivityEvent) then) =
      _$ActivityEventCopyWithImpl<$Res, ActivityEvent>;
}

/// @nodoc
class _$ActivityEventCopyWithImpl<$Res, $Val extends ActivityEvent>
    implements $ActivityEventCopyWith<$Res> {
  _$ActivityEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ActivityEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ActivityEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetCommetsImplCopyWith<$Res> {
  factory _$$GetCommetsImplCopyWith(
          _$GetCommetsImpl value, $Res Function(_$GetCommetsImpl) then) =
      __$$GetCommetsImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetCommetsImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$GetCommetsImpl>
    implements _$$GetCommetsImplCopyWith<$Res> {
  __$$GetCommetsImplCopyWithImpl(
      _$GetCommetsImpl _value, $Res Function(_$GetCommetsImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetCommetsImpl implements GetCommets {
  const _$GetCommetsImpl();

  @override
  String toString() {
    return 'ActivityEvent.getCommets()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetCommetsImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return getCommets();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return getCommets?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (getCommets != null) {
      return getCommets();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return getCommets(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return getCommets?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (getCommets != null) {
      return getCommets(this);
    }
    return orElse();
  }
}

abstract class GetCommets implements ActivityEvent {
  const factory GetCommets() = _$GetCommetsImpl;
}

/// @nodoc
abstract class _$$AddPostImplCopyWith<$Res> {
  factory _$$AddPostImplCopyWith(
          _$AddPostImpl value, $Res Function(_$AddPostImpl) then) =
      __$$AddPostImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String title, String description});
}

/// @nodoc
class __$$AddPostImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$AddPostImpl>
    implements _$$AddPostImplCopyWith<$Res> {
  __$$AddPostImplCopyWithImpl(
      _$AddPostImpl _value, $Res Function(_$AddPostImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = null,
    Object? description = null,
  }) {
    return _then(_$AddPostImpl(
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddPostImpl implements AddPost {
  const _$AddPostImpl({required this.title, required this.description});

  @override
  final String title;
  @override
  final String description;

  @override
  String toString() {
    return 'ActivityEvent.addPost(title: $title, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddPostImpl &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @override
  int get hashCode => Object.hash(runtimeType, title, description);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddPostImplCopyWith<_$AddPostImpl> get copyWith =>
      __$$AddPostImplCopyWithImpl<_$AddPostImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return addPost(title, description);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return addPost?.call(title, description);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (addPost != null) {
      return addPost(title, description);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return addPost(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return addPost?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (addPost != null) {
      return addPost(this);
    }
    return orElse();
  }
}

abstract class AddPost implements ActivityEvent {
  const factory AddPost(
      {required final String title,
      required final String description}) = _$AddPostImpl;

  String get title;
  String get description;
  @JsonKey(ignore: true)
  _$$AddPostImplCopyWith<_$AddPostImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddReplyImplCopyWith<$Res> {
  factory _$$AddReplyImplCopyWith(
          _$AddReplyImpl value, $Res Function(_$AddReplyImpl) then) =
      __$$AddReplyImplCopyWithImpl<$Res>;
  @useResult
  $Res call({AddReplyParams param});
}

/// @nodoc
class __$$AddReplyImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$AddReplyImpl>
    implements _$$AddReplyImplCopyWith<$Res> {
  __$$AddReplyImplCopyWithImpl(
      _$AddReplyImpl _value, $Res Function(_$AddReplyImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? param = null,
  }) {
    return _then(_$AddReplyImpl(
      param: null == param
          ? _value.param
          : param // ignore: cast_nullable_to_non_nullable
              as AddReplyParams,
    ));
  }
}

/// @nodoc

class _$AddReplyImpl implements AddReply {
  const _$AddReplyImpl({required this.param});

  @override
  final AddReplyParams param;

  @override
  String toString() {
    return 'ActivityEvent.addReply(param: $param)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddReplyImpl &&
            (identical(other.param, param) || other.param == param));
  }

  @override
  int get hashCode => Object.hash(runtimeType, param);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddReplyImplCopyWith<_$AddReplyImpl> get copyWith =>
      __$$AddReplyImplCopyWithImpl<_$AddReplyImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return addReply(param);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return addReply?.call(param);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (addReply != null) {
      return addReply(param);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return addReply(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return addReply?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (addReply != null) {
      return addReply(this);
    }
    return orElse();
  }
}

abstract class AddReply implements ActivityEvent {
  const factory AddReply({required final AddReplyParams param}) =
      _$AddReplyImpl;

  AddReplyParams get param;
  @JsonKey(ignore: true)
  _$$AddReplyImplCopyWith<_$AddReplyImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetCommentDetailsImplCopyWith<$Res> {
  factory _$$GetCommentDetailsImplCopyWith(_$GetCommentDetailsImpl value,
          $Res Function(_$GetCommentDetailsImpl) then) =
      __$$GetCommentDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({dynamic id, String slag});
}

/// @nodoc
class __$$GetCommentDetailsImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$GetCommentDetailsImpl>
    implements _$$GetCommentDetailsImplCopyWith<$Res> {
  __$$GetCommentDetailsImplCopyWithImpl(_$GetCommentDetailsImpl _value,
      $Res Function(_$GetCommentDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? slag = null,
  }) {
    return _then(_$GetCommentDetailsImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as dynamic,
      slag: null == slag
          ? _value.slag
          : slag // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetCommentDetailsImpl implements GetCommentDetails {
  const _$GetCommentDetailsImpl({required this.id, required this.slag});

  @override
  final dynamic id;
  @override
  final String slag;

  @override
  String toString() {
    return 'ActivityEvent.getCommentDetails(id: $id, slag: $slag)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetCommentDetailsImpl &&
            const DeepCollectionEquality().equals(other.id, id) &&
            (identical(other.slag, slag) || other.slag == slag));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(id), slag);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetCommentDetailsImplCopyWith<_$GetCommentDetailsImpl> get copyWith =>
      __$$GetCommentDetailsImplCopyWithImpl<_$GetCommentDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return getCommentDetails(id, slag);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return getCommentDetails?.call(id, slag);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (getCommentDetails != null) {
      return getCommentDetails(id, slag);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return getCommentDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return getCommentDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (getCommentDetails != null) {
      return getCommentDetails(this);
    }
    return orElse();
  }
}

abstract class GetCommentDetails implements ActivityEvent {
  const factory GetCommentDetails(
      {required final dynamic id,
      required final String slag}) = _$GetCommentDetailsImpl;

  dynamic get id;
  String get slag;
  @JsonKey(ignore: true)
  _$$GetCommentDetailsImplCopyWith<_$GetCommentDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ActionCommunityImplCopyWith<$Res> {
  factory _$$ActionCommunityImplCopyWith(_$ActionCommunityImpl value,
          $Res Function(_$ActionCommunityImpl) then) =
      __$$ActionCommunityImplCopyWithImpl<$Res>;
  @useResult
  $Res call({dynamic id, ActionType type});
}

/// @nodoc
class __$$ActionCommunityImplCopyWithImpl<$Res>
    extends _$ActivityEventCopyWithImpl<$Res, _$ActionCommunityImpl>
    implements _$$ActionCommunityImplCopyWith<$Res> {
  __$$ActionCommunityImplCopyWithImpl(
      _$ActionCommunityImpl _value, $Res Function(_$ActionCommunityImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? type = null,
  }) {
    return _then(_$ActionCommunityImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as dynamic,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as ActionType,
    ));
  }
}

/// @nodoc

class _$ActionCommunityImpl implements ActionCommunity {
  const _$ActionCommunityImpl({required this.id, required this.type});

  @override
  final dynamic id;
  @override
  final ActionType type;

  @override
  String toString() {
    return 'ActivityEvent.actionCommunity(id: $id, type: $type)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ActionCommunityImpl &&
            const DeepCollectionEquality().equals(other.id, id) &&
            (identical(other.type, type) || other.type == type));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(id), type);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ActionCommunityImplCopyWith<_$ActionCommunityImpl> get copyWith =>
      __$$ActionCommunityImplCopyWithImpl<_$ActionCommunityImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getCommets,
    required TResult Function(String title, String description) addPost,
    required TResult Function(AddReplyParams param) addReply,
    required TResult Function(dynamic id, String slag) getCommentDetails,
    required TResult Function(dynamic id, ActionType type) actionCommunity,
  }) {
    return actionCommunity(id, type);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getCommets,
    TResult? Function(String title, String description)? addPost,
    TResult? Function(AddReplyParams param)? addReply,
    TResult? Function(dynamic id, String slag)? getCommentDetails,
    TResult? Function(dynamic id, ActionType type)? actionCommunity,
  }) {
    return actionCommunity?.call(id, type);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getCommets,
    TResult Function(String title, String description)? addPost,
    TResult Function(AddReplyParams param)? addReply,
    TResult Function(dynamic id, String slag)? getCommentDetails,
    TResult Function(dynamic id, ActionType type)? actionCommunity,
    required TResult orElse(),
  }) {
    if (actionCommunity != null) {
      return actionCommunity(id, type);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(GetCommets value) getCommets,
    required TResult Function(AddPost value) addPost,
    required TResult Function(AddReply value) addReply,
    required TResult Function(GetCommentDetails value) getCommentDetails,
    required TResult Function(ActionCommunity value) actionCommunity,
  }) {
    return actionCommunity(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(GetCommets value)? getCommets,
    TResult? Function(AddPost value)? addPost,
    TResult? Function(AddReply value)? addReply,
    TResult? Function(GetCommentDetails value)? getCommentDetails,
    TResult? Function(ActionCommunity value)? actionCommunity,
  }) {
    return actionCommunity?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(GetCommets value)? getCommets,
    TResult Function(AddPost value)? addPost,
    TResult Function(AddReply value)? addReply,
    TResult Function(GetCommentDetails value)? getCommentDetails,
    TResult Function(ActionCommunity value)? actionCommunity,
    required TResult orElse(),
  }) {
    if (actionCommunity != null) {
      return actionCommunity(this);
    }
    return orElse();
  }
}

abstract class ActionCommunity implements ActivityEvent {
  const factory ActionCommunity(
      {required final dynamic id,
      required final ActionType type}) = _$ActionCommunityImpl;

  dynamic get id;
  ActionType get type;
  @JsonKey(ignore: true)
  _$$ActionCommunityImplCopyWith<_$ActionCommunityImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ActivityState {
  bool get isLoading => throw _privateConstructorUsedError;
  List<CommunityResponse> get communityList =>
      throw _privateConstructorUsedError;
  CommentResponse? get commentResponse => throw _privateConstructorUsedError;
  Replies? get reply => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ActivityStateCopyWith<ActivityState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActivityStateCopyWith<$Res> {
  factory $ActivityStateCopyWith(
          ActivityState value, $Res Function(ActivityState) then) =
      _$ActivityStateCopyWithImpl<$Res, ActivityState>;
  @useResult
  $Res call(
      {bool isLoading,
      List<CommunityResponse> communityList,
      CommentResponse? commentResponse,
      Replies? reply});
}

/// @nodoc
class _$ActivityStateCopyWithImpl<$Res, $Val extends ActivityState>
    implements $ActivityStateCopyWith<$Res> {
  _$ActivityStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? communityList = null,
    Object? commentResponse = freezed,
    Object? reply = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      communityList: null == communityList
          ? _value.communityList
          : communityList // ignore: cast_nullable_to_non_nullable
              as List<CommunityResponse>,
      commentResponse: freezed == commentResponse
          ? _value.commentResponse
          : commentResponse // ignore: cast_nullable_to_non_nullable
              as CommentResponse?,
      reply: freezed == reply
          ? _value.reply
          : reply // ignore: cast_nullable_to_non_nullable
              as Replies?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ActivityStateImplCopyWith<$Res>
    implements $ActivityStateCopyWith<$Res> {
  factory _$$ActivityStateImplCopyWith(
          _$ActivityStateImpl value, $Res Function(_$ActivityStateImpl) then) =
      __$$ActivityStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoading,
      List<CommunityResponse> communityList,
      CommentResponse? commentResponse,
      Replies? reply});
}

/// @nodoc
class __$$ActivityStateImplCopyWithImpl<$Res>
    extends _$ActivityStateCopyWithImpl<$Res, _$ActivityStateImpl>
    implements _$$ActivityStateImplCopyWith<$Res> {
  __$$ActivityStateImplCopyWithImpl(
      _$ActivityStateImpl _value, $Res Function(_$ActivityStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? communityList = null,
    Object? commentResponse = freezed,
    Object? reply = freezed,
  }) {
    return _then(_$ActivityStateImpl(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      communityList: null == communityList
          ? _value._communityList
          : communityList // ignore: cast_nullable_to_non_nullable
              as List<CommunityResponse>,
      commentResponse: freezed == commentResponse
          ? _value.commentResponse
          : commentResponse // ignore: cast_nullable_to_non_nullable
              as CommentResponse?,
      reply: freezed == reply
          ? _value.reply
          : reply // ignore: cast_nullable_to_non_nullable
              as Replies?,
    ));
  }
}

/// @nodoc

class _$ActivityStateImpl implements _ActivityState {
  const _$ActivityStateImpl(
      {required this.isLoading,
      required final List<CommunityResponse> communityList,
      required this.commentResponse,
      required this.reply})
      : _communityList = communityList;

  @override
  final bool isLoading;
  final List<CommunityResponse> _communityList;
  @override
  List<CommunityResponse> get communityList {
    if (_communityList is EqualUnmodifiableListView) return _communityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_communityList);
  }

  @override
  final CommentResponse? commentResponse;
  @override
  final Replies? reply;

  @override
  String toString() {
    return 'ActivityState(isLoading: $isLoading, communityList: $communityList, commentResponse: $commentResponse, reply: $reply)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ActivityStateImpl &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            const DeepCollectionEquality()
                .equals(other._communityList, _communityList) &&
            (identical(other.commentResponse, commentResponse) ||
                other.commentResponse == commentResponse) &&
            (identical(other.reply, reply) || other.reply == reply));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isLoading,
      const DeepCollectionEquality().hash(_communityList),
      commentResponse,
      reply);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ActivityStateImplCopyWith<_$ActivityStateImpl> get copyWith =>
      __$$ActivityStateImplCopyWithImpl<_$ActivityStateImpl>(this, _$identity);
}

abstract class _ActivityState implements ActivityState {
  const factory _ActivityState(
      {required final bool isLoading,
      required final List<CommunityResponse> communityList,
      required final CommentResponse? commentResponse,
      required final Replies? reply}) = _$ActivityStateImpl;

  @override
  bool get isLoading;
  @override
  List<CommunityResponse> get communityList;
  @override
  CommentResponse? get commentResponse;
  @override
  Replies? get reply;
  @override
  @JsonKey(ignore: true)
  _$$ActivityStateImplCopyWith<_$ActivityStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
