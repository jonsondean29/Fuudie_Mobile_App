import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:fuud/features/activity/domain/usecases/add_reply_usecase.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import '../../../widgets/loading_widget.dart';
import '../../domain/entities/community_response.dart';
import '../../domain/usecases/action_community_usecase.dart';
import '../bloc/activity_bloc.dart';

class CommentsWidget extends StatefulWidget {
    CommentsWidget({
    Key? key,
    required this.data,
  }) : super(key: key);
  final CommunityResponse data;
    @override
    _PageState createState() => _PageState();
}

class _PageState extends State<CommentsWidget> {
  Replies? replyData;
  var con=TextEditingController();
  bool isLoading=false;
  List<Replies>list=[];
  @override
  void initState() {
    // TODO: implement initState
    context.read<ActivityBloc>().stream.listen((state) {
      print("isLoading====> ${state.isLoading}");
      if(isLoading!=state.isLoading){
        setState(() {
          isLoading=state.isLoading;
        });
      }
      if(state.commentResponse!=null) {
       setState(() {
         list=state.commentResponse!.replies??[];
       });
      }
      if(state.reply!=null){
        if(replyData==null){
          setState(() {
            list.add(state.reply!);
          });
        }else{
          context.read<ActivityBloc>().add(GetCommentDetails(slag: widget.data.slug!, id: widget.data.id!));
        }
      }

    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height*0.9,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        backgroundColor: Colors.transparent,
        body: Container(
          margin: const EdgeInsets.symmetric(horizontal: 5,vertical: 10),
          padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: [
                  const Center(child:Text(
                    'Comments',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),),
                  Positioned(right: 10,
                    top: 5,
                    child:  InkWell(onTap: () {
                      Navigator.pop(context);
                    }, child: const Icon(Icons.close,size: 20,)),)
                ],
              ),
              const Divider(),
              const Gap(10),
              Expanded(child: _data(),),
              const Gap(10),
              Container(
                margin: const EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(50),
                      child: NetworkImageWidget(url: '${Apis.baseUrl}${auth.value!.profileimg}',
                        height: 50,width: 50,),
                    ),
                    const Gap(5),
                    Expanded(child: Container(
                      decoration: BoxDecoration(
                          borderRadius: const BorderRadius.all(Radius.circular(20),),
                          border: Border.all(color: Colors.grey,width: 1),
                          color: Colors.white
                      ),
                      child: Column(
                        children: [
                          if(replyData!=null)
                            Container(
                              alignment: AlignmentDirectional.center,
                              decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20)),
                                  color: Colors.grey.shade200
                              ),
                              child: Stack(
                                children: [
                                  Container(
                                    alignment: AlignmentDirectional.centerStart,
                                    padding: const EdgeInsets.all(8),
                                    child: Text("${replyData!.description}",maxLines: 2,
                                      style: TextStyle(
                                          overflow: TextOverflow.ellipsis,
                                          fontSize: 12,
                                          color: Colors.grey.shade500
                                      ),),),
                                  Positioned(
                                      right: 5,
                                      top: 0,
                                      child: InkWell(
                                        onTap: () {
                                          setState((){
                                            replyData=null;
                                          });
                                        },
                                        child: const Icon(Icons.close),
                                      ))
                                ],
                              ),
                            ),
                          TextFormField(controller: con,
                            onSaved: (newValue) {
                              onSubmit();

                            },
                            decoration:  InputDecoration(
                                border: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                contentPadding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                filled: false,
                                fillColor: Colors.white,
                                hintText: "Write your comment..",
                                hintStyle: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                ),
                                suffixIcon: InkWell(
                                  onTap: () {
                                    onSubmit();
                                  },
                                  child: Image.asset(
                                    'assets/images/icon-ma.png',
                                    height: 15,
                                  ),
                                )
                            ),
                          )
                        ],
                      ),
                    )),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
  Widget _comment(Replies data,{Function(Replies data)?onReply,bool isSubComment=false}){
    return Container(
      margin:  EdgeInsets.symmetric(horizontal: 5,vertical: isSubComment?0:5),
      decoration:   BoxDecoration(
        color: isSubComment?Colors.transparent:Colors.grey.shade50,
        border: const Border(left: BorderSide(color: Colors.grey,width: 3))
        ),
      child:Container(
        margin: const EdgeInsets.only(bottom: 5,top: 5),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${data.username}',style: const TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: Colors.black),),
            Text('${data.description}',style:  const TextStyle(fontSize: 14,fontWeight: FontWeight.normal,color: Colors.black),),
            Wrap(
              children: [
                SizedBox(width: 120,
                height: 30,
                child: InkWell(onTap: () {
                  context.read<ActivityBloc>().add(ActionCommunity(id: data.id, type: ActionType.LIKE));
                },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Icon(Icons.thumb_up_alt_outlined,size: 20,),
                      Text("${data.totlike} Like(s)"),
                    ],
                  ),
                ),),
                SizedBox(width: 120,
                  height: 30,
                child: InkWell(onTap: () {
                  context.read<ActivityBloc>().add(ActionCommunity(id: data.id, type: ActionType.DISLIKE));
                },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        const Icon(Icons.thumb_down_alt_outlined,size: 20,),
                        Text("${data.totdislike} Dislike(s)"),
                      ],
                    )),),
                SizedBox(width: 120,
                  height: 30,
                child: InkWell(onTap: () {
                  onReply!.call(data);
                },
                    child:const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(Icons.mode_comment_outlined,size: 20,),
                        Text("Reply"),
                      ],
                    )),),
              ],
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade100
              ),
              child: Wrap(
                children: data.replies!.map((e) {
                  return _comment(
                    e,
                    onReply: onReply,
                    isSubComment: true
                  );
                },).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
  Widget _data(){
    if(isLoading){
      return LoadingWidget(type: LoadingType.LIST,);
    }
    if(list.isEmpty){
      return const Text("No Reply found");
    }
    return ListView.builder(
      itemCount: list.length,
      reverse: true,
      itemBuilder: (context, index) => _comment(
        list.reversed.toList()[index],
        onReply: (data) {
          setState((){
            replyData=data;
          });
        },
      ),
    );
  }
  void onSubmit(){
    FocusScope.of(context).unfocus();
    if(con.text.isNotEmpty){
      context.read<ActivityBloc>().add(AddReply(param: AddReplyParams(description: con.value.text,
          communityid: widget.data.id!, parentid: replyData==null?0:replyData!.id!,slag: widget.data.slug!)));
      con.text="";

    }
  }
}
