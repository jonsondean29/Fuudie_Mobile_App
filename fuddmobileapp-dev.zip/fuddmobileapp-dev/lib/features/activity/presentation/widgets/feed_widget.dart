import 'package:gap/gap.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';

import '../../../../core/constants/urls.dart';
import '../../../../core/widgets/input_field.dart';
import '../../../home/presentation/widgets/network_image_widget.dart';
import '../../domain/entities/community_response.dart';
import '../bloc/activity_bloc.dart';
// ignore_for_file: public_member_api_docs, sort_constructors_first

class FeedWidget extends StatelessWidget {
  FeedWidget({
    Key? key,
    required this.getCommentsEntity,
    required this.onClickComment,
    required this.onClickShare,
    required this.onClickLike,
    required this.onClickDislike,
  }) : super(key: key);
  final CommunityResponse getCommentsEntity;
  Function(CommunityResponse data) onClickComment;
  Function(CommunityResponse data) onClickShare;
  Function(CommunityResponse data) onClickLike;
  Function(CommunityResponse data) onClickDislike;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: NetworkImageWidget(url: '${Apis.baseUrl}',
                    height: 50,width: 50,),
                ),
              ),
              const Gap(20),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "${getCommentsEntity.creatorname} ",
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "(${getCommentsEntity.usertype})",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey.shade500),
                      )
                    ],
                  ),
                  const Gap(5),
                  Text(changeDateFormat(getCommentsEntity.createdon),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade500),
                  ),
                ],
              ),
            ],
          ),
          const Gap(15),
          Text(
            '${getCommentsEntity.title}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const Gap(10),
          Text(
            '${getCommentsEntity.description}',
            style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
          ),
          const Gap(10),
          Row(
            children: [
             /* Row(
                children: [
                  Image.asset(
                    'assets/images/eye.png',
                    height: 30,
                  ),
                  Text(getCommentsEntity.totview.toString())
                ],
              ),
              const Gap(30),
              */Row(
                children: [
                  Text(getCommentsEntity.totreply.toString()),
                  const Gap(5),
                  const Text('Answers')
                ],
              )
            ],
          ),
          const Divider(),
          const SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        if(getCommentsEntity.isdisliked==0) {
                          onClickLike.call(getCommentsEntity);
                        }
                        },
                      icon:getCommentsEntity.isliked==0?Icon(Icons.thumb_up_alt_outlined):Icon(Icons.thumb_up,color: Colors.deepOrange,)),
                  IconButton(
                      onPressed: () {
                        if(getCommentsEntity.isliked==0) {
                          onClickDislike.call(getCommentsEntity);
                        }
                      },
                      icon: getCommentsEntity.isdisliked==0?Icon(Icons.thumb_down_alt_outlined):Icon(Icons.thumb_down,color: Colors.deepOrange))
                ],
              ),
              InkWell(
                child: const Row(
                  children: [
                    Icon(Icons.comment_bank_outlined),
                    SizedBox(
                      width: 5,
                    ),
                    Text('Comment(s)'),
                  ],
                ),
                onTap: () {
                  onClickComment.call(getCommentsEntity);
                },
              ),
              InkWell(
                child: const Row(
                  children: [
                    Icon(Icons.share),
                    SizedBox(
                      width: 5,
                    ),
                    Text('Share'),
                  ],
                ),
                onTap: () {
                  onClickShare.call(getCommentsEntity);
                },
              )
            ],
          ),
          const SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }
  String changeDateFormat(inputString){
    DateFormat oldF=DateFormat("yyyy-MM-ddTHH:mm:ss");
    DateFormat newF=DateFormat("dd/MM/yyyy hh:mm a");
    DateTime dateTime=oldF.parse(inputString);
    return newF.format(dateTime);
  }
}
