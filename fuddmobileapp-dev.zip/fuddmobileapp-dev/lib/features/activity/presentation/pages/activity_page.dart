import 'package:fuud/features/widgets/loading_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:fuud/features/activity/presentation/bloc/activity_bloc.dart';
import 'package:fuud/features/activity/presentation/widgets/comments_widget.dart';
import 'package:rxdart/rxdart.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../config/theme/colors.dart';
import '../../../explore/presentation/widgets/search_widget.dart';
import '../../domain/entities/community_response.dart';
import '../../domain/usecases/action_community_usecase.dart';
import '../widgets/feed_widget.dart';

@RoutePage()
class ActivityPage extends StatefulWidget {
  const ActivityPage({super.key});
  static const routeName = 'activity';

  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<ActivityPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final commentController = TextEditingController();
  var titleCon=TextEditingController();
  var desCon=TextEditingController();
  final searchOnChange =  BehaviorSubject<String>();
  var searchCon=TextEditingController();
  bool isLoading=true;
  List<CommunityResponse>list=[];
  List<CommunityResponse>oldList=[];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(const Duration(milliseconds: 500),() {
      context.read<ActivityBloc>().add(const GetCommets());
    },);
    context.read<ActivityBloc>().stream.listen((state) {
      if(isLoading!=state.isLoading){
        setState(() {
          isLoading=state.isLoading;
        });
      }
      if(mounted) {
        setState(() {
          list=state.communityList;
          oldList=state.communityList;
        });
      }
    },);
    initSearch();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.grey.shade50,
      floatingActionButton: FloatingActionButton(onPressed: () {
        addPostWidget(context);
      },
        shape: const StadiumBorder(),
        backgroundColor: Colors.black,child: const Icon(Icons.add,color: Colors.white,size: 45,),
      ),
      key: _scaffoldKey,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: false),
      endDrawer: const AppDrawer(),
      body: Column(
        children: [
          const Gap(10),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 10),
            child: SearchWidget(
              hintText: 'Search',
              searchController: searchCon,
              isLoading: isLoading,
              onChanged: (s) {
                searchOnChange.add(s);
              },
            ),),
          const Gap(20),
          Expanded(child: _body()),
        ],
      ),
    );
  }
  void addPostWidget(context){
    showModalBottomSheet(context: context, builder: (context) {
      return Container(
        padding: const EdgeInsets.all(20),
        height: MediaQuery.of(context).size.height*0.75,
        child: Scaffold(
          resizeToAvoidBottomInset: true,
          body: SingleChildScrollView(
            child: Column(
              children: [
                const Text("Add Post",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: AppColors.black),),
                const SizedBox(
                  height: 20,
                ),
                InputField(controller:titleCon ,
                  hintText: "Enter Title",),
                const SizedBox(
                  height: 20,
                ),
                InputField(controller: desCon,
                  hintText: "Enter Description",
                  maxLines: 4,
                ),
                const SizedBox(
                  height: 20,
                ),
                InkWell(
                  child: Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: AppColors.black,
                        borderRadius:
                        BorderRadius.circular(50)),
                    child: const Center(
                      child: Text(
                        'Submit',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  onTap: (){
                    context.read<ActivityBloc>().add(AddPost(title: titleCon.value.text, description: desCon.value.text));
                    Navigator.pop(context);
                  },
                )
              ],
            ),
          ),
        ),
      );
    },
        isScrollControlled: true,
    backgroundColor: Colors.white);
  }
  void showComment(context,CommunityResponse data){
     showModalBottomSheet(context: context, builder: (context) {
      return CommentsWidget(data: data,);
    },
       backgroundColor: Colors.white,
       isScrollControlled: true,
     );
  }
  void initSearch(){
    searchOnChange.debounceTime(const Duration(milliseconds: 300))
        .listen((queryString) async {
          list=oldList.where((element) => element.title.toString().toLowerCase().contains(queryString.toLowerCase()),).toList();
          setState(() {
          });
        });
  }
  Widget _body(){
    if(isLoading){
      return LoadingWidget(type: LoadingType.BANNER,);
    }
    if(list.isEmpty){
      return const Center(
        child: Text("No Data Found")
      );
    }
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (conte, index) => FeedWidget(
        getCommentsEntity: list[index],
        onClickComment: (CommunityResponse data) {
          context.read<ActivityBloc>().add(GetCommentDetails(slag: data.slug!, id: data.id!));
          showComment(context,data);
        }, onClickShare: (CommunityResponse data) {
        Share.share('${data.title}\n${data.description}');
        context.read<ActivityBloc>().add(ActionCommunity(id: data.id, type: ActionType.SHARE));

      }, onClickLike: (CommunityResponse data) {
        context.read<ActivityBloc>().add(ActionCommunity(id: data.id, type: ActionType.LIKE));
        setState(() {
          list[index].isliked=data.isliked==0?1:0;
        });
      },
        onClickDislike: (CommunityResponse data) {
          context.read<ActivityBloc>().add(ActionCommunity(id: data.id, type: ActionType.DISLIKE));
          setState(() {
            list[index].isdisliked=data.isdisliked==0?1:0;
          });
        },
      ),
    );
  }
}
