class CommentResponse {
  CommentResponse({
      this.id, 
      this.creatorid, 
      this.creatorname, 
      this.title, 
      this.description, 
      this.usertype, 
      this.totview, 
      this.totreply, 
      this.totlike, 
      this.totdislike, 
      this.totshare, 
      this.slug, 
      this.createdon, 
      this.isactive, 
      this.lastreply, 
      this.createdAt, 
      this.updatedAt, 
      this.restroid, 
      this.isliked, 
      this.isdisliked, 
      this.replies,});

  CommentResponse.fromJson(dynamic json) {
    id = json['id'];
    creatorid = json['creatorid'];
    creatorname = json['creatorname'];
    title = json['title'];
    description = json['description'];
    usertype = json['usertype'];
    totview = json['totview'];
    totreply = json['totreply'];
    totlike = json['totlike'];
    totdislike = json['totdislike'];
    totshare = json['totshare'];
    slug = json['slug'];
    createdon = json['createdon'];
    isactive = json['isactive'];
    lastreply = json['lastreply'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    restroid = json['restroid'];
    isliked = json['isliked'];
    isdisliked = json['isdisliked'];
    if (json['replies'] != null) {
      replies = [];
      json['replies'].forEach((v) {
        replies?.add(Replies.fromJson(v));
      });
    }
  }
  int? id;
  int? creatorid;
  String? creatorname;
  String? title;
  String? description;
  String? usertype;
  int? totview;
  int? totreply;
  int? totlike;
  int? totdislike;
  int? totshare;
  String? slug;
  String? createdon;
  int? isactive;
  String? lastreply;
  dynamic createdAt;
  dynamic updatedAt;
  int? restroid;
  int? isliked;
  int? isdisliked;
  List<Replies>? replies;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['creatorid'] = creatorid;
    map['creatorname'] = creatorname;
    map['title'] = title;
    map['description'] = description;
    map['usertype'] = usertype;
    map['totview'] = totview;
    map['totreply'] = totreply;
    map['totlike'] = totlike;
    map['totdislike'] = totdislike;
    map['totshare'] = totshare;
    map['slug'] = slug;
    map['createdon'] = createdon;
    map['isactive'] = isactive;
    map['lastreply'] = lastreply;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['restroid'] = restroid;
    map['isliked'] = isliked;
    map['isdisliked'] = isdisliked;
    if (replies != null) {
      map['replies'] = replies?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Replies {
  Replies({
      this.id, 
      this.communityid, 
      this.userid, 
      this.username, 
      this.description, 
      this.usertype, 
      this.parentid, 
      this.totlike, 
      this.totdislike, 
      this.createdon, 
      this.isactive, 
      this.lastreply, 
      this.isAdminReply, 
      this.createdAt, 
      this.updatedAt, 
      this.replies,});

  Replies.fromJson(dynamic json) {
    id = json['id'];
    communityid = json['communityid'];
    userid = json['userid'];
    username = json['username'];
    description = json['description'];
    usertype = json['usertype'];
    parentid = json['parentid'];
    totlike = json['totlike']??0;
    totdislike = json['totdislike']??0;
    createdon = json['createdon'];
    isactive = json['isactive'];
    lastreply = json['lastreply'];
    isAdminReply = json['is_admin_reply'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    replies = [];
    if (json['subreplies'] != null) {
      json['subreplies'].forEach((v) {
        replies?.add(Replies.fromJson(v));
      });
    }
  }
  int? id;
  int? communityid;
  int? userid;
  String? username;
  String? description;
  String? usertype;
  int? parentid;
  int? totlike;
  int? totdislike;
  String? createdon;
  int? isactive;
  dynamic lastreply;
  int? isAdminReply;
  dynamic createdAt;
  dynamic updatedAt;
  List<Replies>? replies;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['communityid'] = communityid;
    map['userid'] = userid;
    map['username'] = username;
    map['description'] = description;
    map['usertype'] = usertype;
    map['parentid'] = parentid;
    map['totlike'] = totlike;
    map['totdislike'] = totdislike;
    map['createdon'] = createdon;
    map['isactive'] = isactive;
    map['lastreply'] = lastreply;
    map['is_admin_reply'] = isAdminReply;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    if (replies != null) {
      map['subreplies'] = replies?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}