class CommunityResponse {
  CommunityResponse({
      this.id, 
      this.creatorid, 
      this.creatorname, 
      this.title, 
      this.description, 
      this.usertype, 
      this.totview, 
      this.totreply, 
      this.totlike, 
      this.totdislike, 
      this.totshare, 
      this.slug, 
      this.createdon, 
      this.isactive, 
      this.lastreply, 
      this.createdAt, 
      this.updatedAt, 
      this.restroid, 
      this.replies,});

  CommunityResponse.fromJson(dynamic json) {
    id = json['id'];
    creatorid = json['creatorid'];
    creatorname = json['creatorname'];
    title = json['title'];
    description = json['description'];
    usertype = json['usertype'];
    totview = json['totview'];
    totreply = json['totreply'];
    totlike = json['totlike'];
    totdislike = json['totdislike'];
    totshare = json['totshare'];
    slug = json['slug'];
    createdon = json['createdon'];
    isactive = json['isactive'];
    lastreply = json['lastreply'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    restroid = json['restroid'];
    replies = json['replies'];
    isliked = json['isliked'];
    isdisliked = json['isdisliked'];
  }
  int? isliked;
  int? isdisliked;
  int? id;
  int? creatorid;
  String? creatorname;
  String? title;
  String? description;
  String? usertype;
  int? totview;
  int? totreply;
  int? totlike;
  int? totdislike;
  int? totshare;
  String? slug;
  String? createdon;
  int? isactive;
  String? lastreply;
  dynamic createdAt;
  dynamic updatedAt;
  int? restroid;
  dynamic replies;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['creatorid'] = creatorid;
    map['creatorname'] = creatorname;
    map['title'] = title;
    map['description'] = description;
    map['usertype'] = usertype;
    map['totview'] = totview;
    map['totreply'] = totreply;
    map['totlike'] = totlike;
    map['totdislike'] = totdislike;
    map['totshare'] = totshare;
    map['slug'] = slug;
    map['createdon'] = createdon;
    map['isactive'] = isactive;
    map['lastreply'] = lastreply;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['restroid'] = restroid;
    map['replies'] = replies;
    return map;
  }

}