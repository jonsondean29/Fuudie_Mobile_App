import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

@LazySingleton()
class AddReplyUsecase implements UseCaseWithParams<void,AddReplyParams> {
  final GetCommentsRepository repository;

  AddReplyUsecase({required this.repository});
  @override
  Future<Either<Failure, Replies>> call(param) {
    return repository.addReply(param);
  }
}

class AddReplyParams extends Equatable {
  final dynamic parentid;
  final dynamic communityid;
  final String description;
  final String slag;

  AddReplyParams({required this.description,required this.communityid,required this.parentid,required this.slag});
  @override
  List<Object?> get props => [parentid,description,communityid];
}
