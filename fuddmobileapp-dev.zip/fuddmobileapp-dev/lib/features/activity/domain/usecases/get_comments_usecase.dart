import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

import '../entities/community_response.dart';

@LazySingleton()
class GetCommentsUsecase implements UseCaseWithoutParams {
  final GetCommentsRepository getcommentsRepository;

  GetCommentsUsecase({required this.getcommentsRepository});
  @override
  Future<Either<Failure, List<CommunityResponse>>> call() {
    return getcommentsRepository.getGetComments();
  }
}
