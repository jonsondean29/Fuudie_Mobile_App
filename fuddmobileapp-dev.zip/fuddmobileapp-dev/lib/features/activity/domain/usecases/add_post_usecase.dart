import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

@LazySingleton()
class AddPostUsecase implements UseCaseWithParams<void,AddPostParams> {
  final GetCommentsRepository repository;

  AddPostUsecase({required this.repository});
  @override
  Future<Either<Failure, String>> call(param) {
    return repository.addPost(param);
  }
}
class AddPostParams extends Equatable {
  final String title;
  final String description;

  AddPostParams({required this.title,required this.description});
  @override
  List<Object?> get props => [title,description];
}
