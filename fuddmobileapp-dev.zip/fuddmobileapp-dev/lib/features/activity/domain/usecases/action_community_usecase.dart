import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

@LazySingleton()
class ActionCommunityUsecase implements UseCaseWithParams<void,ActionCommunityParams> {
  final GetCommentsRepository repository;

  ActionCommunityUsecase({required this.repository});
  @override
  Future<Either<Failure, String>> call(param) {
    return repository.actionCommunity(param);
  }
}
enum ActionType{
  LIKE, DISLIKE,SHARE
}
class ActionCommunityParams extends Equatable {
  final dynamic id;
  final ActionType actionType;

  ActionCommunityParams({required this.actionType,required this.id});
  @override
  List<Object?> get props => [id];
}
