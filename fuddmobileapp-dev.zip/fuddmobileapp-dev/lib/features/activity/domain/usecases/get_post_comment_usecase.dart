import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

import '../entities/comment_response.dart';

@LazySingleton()
class GetPostCommentUsecase implements UseCaseWithParams<void,CommentParams> {
  final GetCommentsRepository repository;

  GetPostCommentUsecase({required this.repository});
  @override
  Future<Either<Failure, CommentResponse>> call(param) {
    return repository.getCommentReplays(param);
  }
}
class CommentParams extends Equatable {
  final dynamic id;
  final String slag;

  CommentParams({required this.id,required this.slag});
  @override
  List<Object?> get props => [id,slag];
}
