import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/domain/usecases/action_community_usecase.dart';
import 'package:fuud/features/activity/domain/usecases/get_post_comment_usecase.dart';

import '../entities/community_response.dart';
import '../usecases/add_post_usecase.dart';
import '../usecases/add_reply_usecase.dart';

abstract class GetCommentsRepository {
  Future<Either<Failure, List<CommunityResponse>>> getGetComments();
  Future<Either<Failure, String>> addPost(AddPostParams param);
  Future<Either<Failure, Replies>> addReply(AddReplyParams param);
  Future<Either<Failure, CommentResponse>> getCommentReplays(CommentParams param);
  Future<Either<Failure, String>> actionCommunity(ActionCommunityParams param);
}
