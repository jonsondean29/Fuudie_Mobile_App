import 'dart:convert';
import 'dart:developer';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:fuud/features/activity/domain/usecases/action_community_usecase.dart';
import 'package:fuud/features/activity/domain/usecases/add_reply_usecase.dart';
import 'package:fuud/features/activity/domain/usecases/get_post_comment_usecase.dart';
import 'package:fuud/features/activity/presentation/bloc/activity_bloc.dart';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import '../../../../core/constants/constants.dart';
import '../../domain/entities/community_response.dart';
import '../../domain/usecases/add_post_usecase.dart';

abstract class GetCommentsRemoteDatasource {
  Future<List<CommunityResponse>> getcommentsList();
  Future<CommentResponse> getCommentsReplyList(CommentParams param);
  Future<String> addPost(AddPostParams param);
  Future<Replies> addReply(AddReplyParams param);
  Future<String> actionCommunity(ActionCommunityParams param);
}

@LazySingleton(as: GetCommentsRemoteDatasource)
class GetCommentsRemoteDatasourceImpl implements GetCommentsRemoteDatasource {
  final Client client;
  GetCommentsRemoteDatasourceImpl({required this.client});

  @override
  Future<List<CommunityResponse>> getcommentsList() async {
    print('getcomments api called ${Apis.getComments}');
    try {
      final response = await client.get(
        Uri.parse('${Apis.getComments}/${auth.value!.id}/true'),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myGetCommentsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        List<CommunityResponse>list=[];
       for(var d in jsonDecode(response.body)){
         list.add(CommunityResponse.fromJson(d));
       }
       return list;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> addPost(AddPostParams param) async {
    try {
      final response = await client.post(
        Uri.parse(Apis.addPost),
        body: {
          "creatorid":'${auth.value!.id}',
          "title":param.title,
          "description":param.description,
          "usertype":"Customer"
        }
      );
      log('addPost ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
       return jsonDecode(response.body)['message'];
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<CommentResponse> getCommentsReplyList(CommentParams param) async {
    String api="${Apis.getCommentsReply}/${param.slag}/${param.id}/${auth.value!.id}";
    try {
      final response = await client.get(
        Uri.parse(api),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('getCommentsReplyList ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return CommentResponse.fromJson(jsonDecode(response.body));
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<Replies> addReply(AddReplyParams param) async {
    try {
      final response = await client.post(
          Uri.parse(Apis.addReply),
          body: {
            "userid":'${auth.value!.id}',
            "parentid":'${param.parentid}',
            "communityid":'${param.communityid}',
            "description":param.description,
            "usertype":"Customer"
          }
      );
      log('addReplay ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return Replies.fromJson(jsonDecode(response.body)['returnId']);
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> actionCommunity(ActionCommunityParams param) async {
    String api;
    switch(param.actionType){
      case ActionType.LIKE:
        api='${Apis.actionCommunityLike}/${param.id}/${auth.value!.id}';
        case ActionType.DISLIKE:
          api='${Apis.actionCommunityDislike}/${param.id}/${auth.value!.id}';
      case ActionType.SHARE:
        api='${Apis.actionCommunityShare}/${param.id}/${auth.value!.id}';
    }
    try {
      final response = await client.post(
          Uri.parse(api),
      );
      log('${param.actionType.name} ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['message'];
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }}
}
