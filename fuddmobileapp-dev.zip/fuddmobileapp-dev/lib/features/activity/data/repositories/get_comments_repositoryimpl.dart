import 'package:dartz/dartz.dart';
import 'package:fuud/features/activity/domain/entities/comment_response.dart';
import 'package:fuud/features/activity/domain/usecases/action_community_usecase.dart';
import 'package:fuud/features/activity/domain/usecases/add_reply_usecase.dart';
import 'package:fuud/features/activity/domain/usecases/get_post_comment_usecase.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/activity/domain/entities/get_comments_entity.dart';
import 'package:fuud/features/activity/data/datasources/get_comments_datasource.dart';
import 'package:fuud/features/activity/domain/repositories/get_comment_repository.dart';

import '../../domain/entities/community_response.dart';

@LazySingleton(as: GetCommentsRepository)
class GetCommentsRepoImpl implements GetCommentsRepository {
  final GetCommentsRemoteDatasource sigInRemoteDatasource;

  GetCommentsRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, List<CommunityResponse>>> getGetComments() async {
    try {
      final result = await sigInRemoteDatasource.getcommentsList();
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> addPost(param) async {
    try {
      final result = await sigInRemoteDatasource.addPost(param);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, CommentResponse>> getCommentReplays(CommentParams param) async {
    try {
      final result = await sigInRemoteDatasource.getCommentsReplyList(param);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, Replies>> addReply(AddReplyParams param) async {
    try {
      final result = await sigInRemoteDatasource.addReply(param);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> actionCommunity(ActionCommunityParams param) async {
    try {
      final result = await sigInRemoteDatasource.actionCommunity(param);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }}
}
