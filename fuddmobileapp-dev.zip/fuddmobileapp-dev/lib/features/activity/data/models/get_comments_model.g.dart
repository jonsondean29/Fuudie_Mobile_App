// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_comments_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetCommentsModelImpl _$$GetCommentsModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetCommentsModelImpl(
      id: (json['id'] as num).toInt(),
      creatorid: (json['creatorid'] as num).toInt(),
      creatorname: json['creatorname'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      usertype: json['usertype'] as String,
      totview: (json['totview'] as num).toInt(),
      totreply: (json['totreply'] as num).toInt(),
      totlike: (json['totlike'] as num).toInt(),
      totdislike: (json['totdislike'] as num).toInt(),
      totshare: (json['totshare'] as num).toInt(),
      slug: json['slug'] as String,
      createdon: DateTime.parse(json['createdon'] as String),
      isactive: (json['isactive'] as num).toInt(),
      lastreply: DateTime.parse(json['lastreply'] as String),
      replies: json['replies'],
    );

Map<String, dynamic> _$$GetCommentsModelImplToJson(
        _$GetCommentsModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'creatorid': instance.creatorid,
      'creatorname': instance.creatorname,
      'title': instance.title,
      'description': instance.description,
      'usertype': instance.usertype,
      'totview': instance.totview,
      'totreply': instance.totreply,
      'totlike': instance.totlike,
      'totdislike': instance.totdislike,
      'totshare': instance.totshare,
      'slug': instance.slug,
      'createdon': instance.createdon.toIso8601String(),
      'isactive': instance.isactive,
      'lastreply': instance.lastreply.toIso8601String(),
      'replies': instance.replies,
    };
