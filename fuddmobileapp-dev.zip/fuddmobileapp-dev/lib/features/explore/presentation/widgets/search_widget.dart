import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
// ignore_for_file: public_member_api_docs, sort_constructors_first

class SearchWidget extends StatelessWidget {
  final TextEditingController searchController;
  final String? hintText;
  bool? isLoading;
  Function(String s)?onChanged;
   SearchWidget({
    Key? key,
    required this.searchController,
    this.hintText,
    this.onChanged,
    this.isLoading=false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black),
          color: Colors.white,
          borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              controller: searchController,
              onChanged: onChanged,
              decoration: InputDecoration(
                  hintText: hintText,
                  hintStyle: const TextStyle(color: Colors.black38),
                  border: InputBorder.none,
                  prefixIcon: const ImageIcon(
                    AssetImage(
                      'assets/images/b-1.png',
                    ),
                    color: Colors.black,
                  ),
                  contentPadding: const EdgeInsets.only(left: 30)),
            ),
          ),
           Align(
            alignment: Alignment.centerRight,
            child:isLoading!? const SizedBox(
              height: 30,
              width: 30,
              child: CircularProgressIndicator(strokeWidth: 3,),
            ):const ImageIcon(
              AssetImage('assets/images/filter.png'),
            ),
          ),
          const Gap(5)
        ],
      ),
    );
  }
}
