import 'package:flutter/material.dart';
import 'package:fuud/features/explore/presentation/widgets/tags.dart';
import 'package:fuud/features/explore/presentation/widgets/areas.dart';
import 'package:fuud/features/explore/presentation/widgets/lists.dart';

class TabViewWidget extends StatefulWidget {
  const TabViewWidget({
    Key? key,
  }) : super(key: key);

  @override
  State<TabViewWidget> createState() => _TabViewWidgetState();
}

class _TabViewWidgetState extends State<TabViewWidget> {
  double rating = 0.0;

  final nameController = TextEditingController();
  // final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final reviewController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(
            labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            tabs: [
              Tab(text: 'Areas'),
              Tab(text: 'List'),
              Tab(text: 'Tags'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [AreasListWidget(), ListWidget(), TagsWidget()],
            ),
          ),
        ],
      ),
    );
  }

  onRatingChanged(double rating) {
    this.rating = rating;
  }
}
