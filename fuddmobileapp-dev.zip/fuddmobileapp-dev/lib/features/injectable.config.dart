// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i1;
import 'package:http/http.dart' as _i6;
import 'package:injectable/injectable.dart' as _i2;

import '../core/utls/location/bloc/location_bloc.dart' as _i3;
import '../core/utls/network/bloc/network_bloc.dart' as _i4;
import 'account/data/account_datasource.dart' as _i7;
import 'account/data/account_repository_impl.dart' as _i34;
import 'account/data/account_usecase.dart' as _i48;
import 'account/data/contact_us_usecase.dart' as _i66;
import 'account/data/delete_account_usecase.dart' as _i49;
import 'account/data/privacy_policy_usecase.dart' as _i67;
import 'account/data/repo/account_repository.dart' as _i33;
import 'account/data/support_usecase.dart' as _i68;
import 'account/data/term_usecase.dart' as _i69;
import 'account/data/update_profile_usecase.dart' as _i50;
import 'account/data/wtt_usecase.dart' as _i51;
import 'account/presentation/bloc/account_bloc.dart' as _i75;
import 'activity/data/datasources/get_comments_datasource.dart' as _i13;
import 'activity/data/repositories/get_comments_repositoryimpl.dart' as _i23;
import 'activity/domain/repositories/get_comment_repository.dart' as _i22;
import 'activity/domain/usecases/action_community_usecase.dart' as _i43;
import 'activity/domain/usecases/add_post_usecase.dart' as _i44;
import 'activity/domain/usecases/add_reply_usecase.dart' as _i45;
import 'activity/domain/usecases/get_comments_usecase.dart' as _i54;
import 'activity/domain/usecases/get_post_comment_usecase.dart' as _i46;
import 'activity/presentation/bloc/activity_bloc.dart' as _i81;
import 'auth/data/datasources/signin_datasource.dart' as _i9;
import 'auth/data/datasources/signup_datasource.dart' as _i21;
import 'auth/data/repositories/signin_repository.dart' as _i57;
import 'auth/data/repositories/signup_repository.dart' as _i77;
import 'auth/domain/repositories/sign_in_repositories.dart' as _i56;
import 'auth/domain/repositories/sign_up_repository.dart' as _i76;
import 'auth/domain/usecases/forget_password_usecase.dart' as _i82;
import 'auth/domain/usecases/sign_in_usecase.dart' as _i83;
import 'auth/domain/usecases/sign_up_usecase.dart' as _i78;
import 'auth/presentation/bloc/auth_bloc.dart' as _i88;
import 'home/data/datasources/ads_datasource.dart' as _i12;
import 'home/data/datasources/all_tag_resturents_datasource.dart' as _i20;
import 'home/data/datasources/country_datasource.dart' as _i19;
import 'home/data/datasources/curent_year_resturent_list_datasource.dart'
    as _i14;
import 'home/data/datasources/exclusive_resturents_list_datasource.dart' as _i8;
import 'home/data/datasources/home_datasource.dart' as _i11;
import 'home/data/datasources/new_opening_resturent_datasource.dart' as _i24;
import 'home/data/datasources/restaurant_details_datasource.dart' as _i18;
import 'home/data/datasources/resturent_with_perks_datasource.dart' as _i17;
import 'home/data/datasources/top_10_resturents_datasource.dart' as _i32;
import 'home/data/repositories/ads_repository_impl.dart' as _i63;
import 'home/data/repositories/all_tags_resturent_list.dart' as _i71;
import 'home/data/repositories/country_repository_impl.dart' as _i59;
import 'home/data/repositories/current_year_resturent_repositoryimpl.dart'
    as _i31;
import 'home/data/repositories/exclusive_resturent_list.dart' as _i36;
import 'home/data/repositories/home_repository_impl.dart' as _i16;
import 'home/data/repositories/new_opening_resturent_repositoryimpl.dart'
    as _i29;
import 'home/data/repositories/restaurant_details_repositoryimpl.dart' as _i53;
import 'home/data/repositories/resturent_with_perks_repositoryimpl.dart'
    as _i61;
import 'home/data/repositories/top_10_repository_impl.dart' as _i38;
import 'home/domain/repositories/ads_repository.dart' as _i62;
import 'home/domain/repositories/all_tags_restaurent_repository.dart' as _i70;
import 'home/domain/repositories/country_repository.dart' as _i58;
import 'home/domain/repositories/current_year_resturent_repository.dart'
    as _i30;
import 'home/domain/repositories/exclusive_resturent_repository.dart' as _i35;
import 'home/domain/repositories/home_repository.dart' as _i15;
import 'home/domain/repositories/new_restaurent_repository.dart' as _i28;
import 'home/domain/repositories/perks_resturent_repository.dart' as _i60;
import 'home/domain/repositories/restaurant_details_entity.dart' as _i52;
import 'home/domain/repositories/top_10_resurents_repository.dart' as _i37;
import 'home/domain/usecases/ads_usecase.dart' as _i84;
import 'home/domain/usecases/all_tag_restaurent_usecase.dart' as _i72;
import 'home/domain/usecases/country_usecase.dart' as _i85;
import 'home/domain/usecases/current_year_resturents_usecase.dart' as _i42;
import 'home/domain/usecases/exclusive_resturent_usecase.dart' as _i39;
import 'home/domain/usecases/home_usecase.dart' as _i40;
import 'home/domain/usecases/new_opening_restaurent_usecase.dart' as _i47;
import 'home/domain/usecases/perks_resturent_usecase.dart' as _i87;
import 'home/domain/usecases/resturant_details_usecase.dart' as _i55;
import 'home/domain/usecases/search_usecase.dart' as _i41;
import 'home/domain/usecases/top_10_resturents_usecase.dart' as _i79;
import 'home/domain/usecases/update_ctiy_usecase.dart' as _i86;
import 'home/presentation/bloc/home_bloc.dart' as _i89;
import 'injectable.dart' as _i90;
import 'map/domain/datasource/add_to_datasource.dart' as _i10;
import 'map/domain/datasource/map_resturents_list_datasource.dart' as _i25;
import 'map/domain/impl/add_to_impl.dart' as _i65;
import 'map/domain/repos/add_to_repository.dart' as _i64;
import 'map/domain/repos/map_resturent_list.dart' as _i27;
import 'map/domain/repos/map_resturent_repository.dart' as _i26;
import 'map/domain/usecases/add_to_usecase.dart' as _i73;
import 'map/domain/usecases/map_resturent_usecase.dart' as _i74;
import 'map/presentation/bloc/map_bloc.dart' as _i80;
import 'splash/presentation/bloc/splash_bloc.dart' as _i5;

extension GetItInjectableX on _i1.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i1.GetIt init({
    String? environment,
    _i2.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i2.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    final injectableModule = _$InjectableModule();
    gh.factory<_i3.LocationBloc>(() => _i3.LocationBloc());
    gh.factory<_i4.NetworkBloc>(() => _i4.NetworkBloc());
    gh.factory<_i5.SplashBloc>(() => _i5.SplashBloc());
    gh.singleton<_i6.Client>(() => injectableModule.httpClient);
    gh.lazySingleton<_i7.AccountRemoteDatasource>(
        () => _i7.AdsRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i8.ExclusiveResturentRemoteDatasource>(() =>
        _i8.ExclusiveResturentRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i9.SignInRemoteDatasource>(
        () => _i9.SignInRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i10.AddToDatasource>(
        () => _i10.AddToDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i11.HomeDatasource>(
        () => _i11.HomeDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i12.AdsRemoteDatasource>(
        () => _i12.AdsRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i13.GetCommentsRemoteDatasource>(
        () => _i13.GetCommentsRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i14.CurrentYearResturentRemoteDatasource>(() =>
        _i14.CurrentYearResturentRemoteDatasourceImpl(
            client: gh<_i6.Client>()));
    gh.lazySingleton<_i15.HomeRepository>(
        () => _i16.HomeRepoImpl(datasource: gh<_i11.HomeDatasource>()));
    gh.lazySingleton<_i17.ResturentWithPerksRemoteDatasource>(() =>
        _i17.ResturentWithPerksRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i18.RestaurantDetailsRemoteDatasource>(() =>
        _i18.RestaurantDetailsRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i19.CountryDatasource>(
        () => _i19.CountryDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i20.AllTagsResturentRemoteDatasource>(() =>
        _i20.AllTagsResturentRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i21.SigUpRemoteDatasource>(
        () => _i21.SigUpRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i22.GetCommentsRepository>(() => _i23.GetCommentsRepoImpl(
        sigInRemoteDatasource: gh<_i13.GetCommentsRemoteDatasource>()));
    gh.lazySingleton<_i24.NewOpeningResturentRemoteDatasource>(() =>
        _i24.NewOpeningResturentRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i25.MapResturentRemoteDatasource>(
        () => _i25.MapResturentRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i26.MapRestaurantRepository>(() =>
        _i27.MapResturentRepoImpl(
            sigInRemoteDatasource: gh<_i25.MapResturentRemoteDatasource>()));
    gh.lazySingleton<_i28.NewRestaurantRepository>(() =>
        _i29.NewOpeningResturentRepoImpl(
            newOpeningResturentRemoteDatasource:
                gh<_i24.NewOpeningResturentRemoteDatasource>()));
    gh.lazySingleton<_i30.CurrentYearRestaurantRepository>(() =>
        _i31.CurentyearResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i14.CurrentYearResturentRemoteDatasource>()));
    gh.lazySingleton<_i32.TopTenResturentRemoteDatasource>(() =>
        _i32.TopTenResturentRemoteDatasourceImpl(client: gh<_i6.Client>()));
    gh.lazySingleton<_i33.AccountRepository>(() => _i34.AccountRepositoryImpl(
        datasource: gh<_i7.AccountRemoteDatasource>()));
    gh.lazySingleton<_i35.ExclusiveRestaurantRepository>(() =>
        _i36.ExclusiveResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i8.ExclusiveResturentRemoteDatasource>()));
    gh.lazySingleton<_i37.TopTenRestaurantRepository>(() =>
        _i38.TopTenOpeningResturentRepoImpl(
            toptenOpeningResturentRemoteDatasource:
                gh<_i32.TopTenResturentRemoteDatasource>()));
    gh.lazySingleton<_i39.ExclusiveRestaurantUsecase>(() =>
        _i39.ExclusiveRestaurantUsecase(
            exclusiveRestaurantRepository:
                gh<_i35.ExclusiveRestaurantRepository>()));
    gh.lazySingleton<_i40.HomeUsecase>(
        () => _i40.HomeUsecase(repository: gh<_i15.HomeRepository>()));
    gh.lazySingleton<_i41.SearchUsecase>(
        () => _i41.SearchUsecase(repository: gh<_i15.HomeRepository>()));
    gh.lazySingleton<_i42.CurrentYearRestaurantUsecase>(() =>
        _i42.CurrentYearRestaurantUsecase(
            currentYearRestaurantRepository:
                gh<_i30.CurrentYearRestaurantRepository>()));
    gh.lazySingleton<_i43.ActionCommunityUsecase>(() =>
        _i43.ActionCommunityUsecase(
            repository: gh<_i22.GetCommentsRepository>()));
    gh.lazySingleton<_i44.AddPostUsecase>(() =>
        _i44.AddPostUsecase(repository: gh<_i22.GetCommentsRepository>()));
    gh.lazySingleton<_i45.AddReplyUsecase>(() =>
        _i45.AddReplyUsecase(repository: gh<_i22.GetCommentsRepository>()));
    gh.lazySingleton<_i46.GetPostCommentUsecase>(() =>
        _i46.GetPostCommentUsecase(
            repository: gh<_i22.GetCommentsRepository>()));
    gh.lazySingleton<_i47.NewRestaurantUsecase>(() => _i47.NewRestaurantUsecase(
        newRestaurantRepository: gh<_i28.NewRestaurantRepository>()));
    gh.lazySingleton<_i48.AccountUsecase>(
        () => _i48.AccountUsecase(repository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i49.DeleteAccountUsecase>(() =>
        _i49.DeleteAccountUsecase(repository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i50.UpdateProfileUsecase>(() =>
        _i50.UpdateProfileUsecase(repository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i51.WttUsecase>(
        () => _i51.WttUsecase(repository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i52.RestaurantDetailsRepository>(() =>
        _i53.RestaurantDetailsRepoImpl(
            sigInRemoteDatasource:
                gh<_i18.RestaurantDetailsRemoteDatasource>()));
    gh.lazySingleton<_i54.GetCommentsUsecase>(() => _i54.GetCommentsUsecase(
        getcommentsRepository: gh<_i22.GetCommentsRepository>()));
    gh.lazySingleton<_i55.RestaurantDetailsUsecase>(() =>
        _i55.RestaurantDetailsUsecase(
            restaurantDetailsRepository:
                gh<_i52.RestaurantDetailsRepository>()));
    gh.lazySingleton<_i56.SignInRepository>(() => _i57.SignInRepoImpl(
        sigInRemoteDatasource: gh<_i9.SignInRemoteDatasource>()));
    gh.lazySingleton<_i58.CountryRepository>(() => _i59.CountryRepoImpl(
        sigInRemoteDatasource: gh<_i19.CountryDatasource>()));
    gh.lazySingleton<_i60.PerksRestaurantRepository>(() =>
        _i61.ResturentWithPerksRepoImpl(
            resturentWithPerksRemoteDatasource:
                gh<_i17.ResturentWithPerksRemoteDatasource>()));
    gh.lazySingleton<_i62.AdsRepository>(() => _i63.AdsRepoImpl(
        sigInRemoteDatasource: gh<_i12.AdsRemoteDatasource>()));
    gh.lazySingleton<_i64.AddToRepository>(
        () => _i65.AddToImpl(datasource: gh<_i10.AddToDatasource>()));
    gh.lazySingleton<_i66.ContactUsUsecase>(() =>
        _i66.ContactUsUsecase(accountRepository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i67.PrivacyPolicyUsecase>(() => _i67.PrivacyPolicyUsecase(
        accountRepository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i68.SupportUsecase>(() =>
        _i68.SupportUsecase(accountRepository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i69.TermUsecase>(() =>
        _i69.TermUsecase(accountRepository: gh<_i33.AccountRepository>()));
    gh.lazySingleton<_i70.AllTagsRestaurantRepository>(() =>
        _i71.AllTagsResturentRepoImpl(
            sigInRemoteDatasource:
                gh<_i20.AllTagsResturentRemoteDatasource>()));
    gh.lazySingleton<_i72.AllTagsRestaurantUsecase>(() =>
        _i72.AllTagsRestaurantUsecase(
            allTagsRestaurantRepository:
                gh<_i70.AllTagsRestaurantRepository>()));
    gh.lazySingleton<_i73.AddToUsecase>(
        () => _i73.AddToUsecase(repository: gh<_i64.AddToRepository>()));
    gh.lazySingleton<_i74.MapRestaurantUsecase>(() => _i74.MapRestaurantUsecase(
        mapRestaurantRepository: gh<_i26.MapRestaurantRepository>()));
    gh.factory<_i75.AccountBloc>(() => _i75.AccountBloc(
          accountUsecase: gh<_i48.AccountUsecase>(),
          updateProfileUsecase: gh<_i50.UpdateProfileUsecase>(),
          deleteAccountUsecase: gh<_i49.DeleteAccountUsecase>(),
          wttUsecase: gh<_i51.WttUsecase>(),
          supportUsecase: gh<_i68.SupportUsecase>(),
          policyUsecase: gh<_i67.PrivacyPolicyUsecase>(),
          termUsecase: gh<_i69.TermUsecase>(),
          contactUsUsecase: gh<_i66.ContactUsUsecase>(),
        ));
    gh.lazySingleton<_i76.SignUpRepository>(() => _i77.SignUpRepoImpl(
        sigUpRemoteDatasource: gh<_i21.SigUpRemoteDatasource>()));
    gh.lazySingleton<_i78.SignUpUsecase>(() =>
        _i78.SignUpUsecase(signUpRepository: gh<_i76.SignUpRepository>()));
    gh.lazySingleton<_i79.TopTenRestaurantUsecase>(() =>
        _i79.TopTenRestaurantUsecase(
            toptenRestaurantRepository: gh<_i37.TopTenRestaurantRepository>()));
    gh.factory<_i80.MapBloc>(() => _i80.MapBloc(
          mapRestaurantUsecase: gh<_i74.MapRestaurantUsecase>(),
          addToUsecase: gh<_i73.AddToUsecase>(),
        ));
    gh.factory<_i81.ActivityBloc>(() => _i81.ActivityBloc(
          getCommentsUsecase: gh<_i54.GetCommentsUsecase>(),
          addPostUsecase: gh<_i44.AddPostUsecase>(),
          addReplyUsecase: gh<_i45.AddReplyUsecase>(),
          actionCommunityUsecase: gh<_i43.ActionCommunityUsecase>(),
          getPostCommentUsecase: gh<_i46.GetPostCommentUsecase>(),
        ));
    gh.lazySingleton<_i82.ForgetPasswordUsecase>(() =>
        _i82.ForgetPasswordUsecase(
            signInRepository: gh<_i56.SignInRepository>()));
    gh.lazySingleton<_i83.SignInUsecase>(() =>
        _i83.SignInUsecase(signInRepository: gh<_i56.SignInRepository>()));
    gh.lazySingleton<_i84.AdsUsecase>(
        () => _i84.AdsUsecase(adsRepository: gh<_i62.AdsRepository>()));
    gh.lazySingleton<_i85.CountryUsecase>(() =>
        _i85.CountryUsecase(countryRepository: gh<_i58.CountryRepository>()));
    gh.lazySingleton<_i86.UpdateCtiyUsecase>(() => _i86.UpdateCtiyUsecase(
        countryRepository: gh<_i58.CountryRepository>()));
    gh.lazySingleton<_i87.PerksRestaurantUsecase>(() =>
        _i87.PerksRestaurantUsecase(
            perksRestaurantRepository: gh<_i60.PerksRestaurantRepository>()));
    gh.factory<_i88.AuthBloc>(() => _i88.AuthBloc(
          signInUsecase: gh<_i83.SignInUsecase>(),
          signUpUsecase: gh<_i78.SignUpUsecase>(),
          forgetPassword: gh<_i82.ForgetPasswordUsecase>(),
        ));
    gh.factory<_i89.HomeBloc>(() => _i89.HomeBloc(
          countryUsecase: gh<_i85.CountryUsecase>(),
          updateCtiyUsecase: gh<_i86.UpdateCtiyUsecase>(),
          restaurantDetailsUsecase: gh<_i55.RestaurantDetailsUsecase>(),
          homeUsecase: gh<_i40.HomeUsecase>(),
          adsUsecase: gh<_i84.AdsUsecase>(),
          searchUsecase: gh<_i41.SearchUsecase>(),
        ));
    return this;
  }
}

class _$InjectableModule extends _i90.InjectableModule {}
