import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/data/datasources/ads_datasource.dart';
import 'package:fuud/features/home/domain/repositories/ads_repository.dart';

import '../models/banners.dart';

@LazySingleton(as: AdsRepository)
class AdsRepoImpl implements AdsRepository {
  final AdsRemoteDatasource sigInRemoteDatasource;

  AdsRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, List<Banners>>> getAds(params) async {
    try {
      final result = await sigInRemoteDatasource.adsList(params);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
