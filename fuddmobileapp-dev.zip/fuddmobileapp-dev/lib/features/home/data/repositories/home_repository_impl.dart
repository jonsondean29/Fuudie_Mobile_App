import 'package:dartz/dartz.dart';
import 'package:fuud/features/home/data/datasources/home_datasource.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import 'package:fuud/features/home/domain/repositories/home_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';

@LazySingleton(as: HomeRepository)
class HomeRepoImpl implements HomeRepository {
  final HomeDatasource datasource;

  HomeRepoImpl({required this.datasource});

  @override
  Future<Either<Failure, HomeResponse>> getHome(params) async {
    try {
      final result = await datasource.homeList(params);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, List<Restrolist>>> search(String q) async {
    try {
      final result = await datasource.searchList(q);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

}
