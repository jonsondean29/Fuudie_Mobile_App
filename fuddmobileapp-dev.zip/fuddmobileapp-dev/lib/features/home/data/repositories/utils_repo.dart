import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
Future<String?> _findLocalPath() async {
  var externalStorageDirPath;
  if (Platform.isAndroid) {
    final directory = await getExternalStorageDirectory();
    // externalStorageDirPath = directory?.path;
    externalStorageDirPath = "storage/emulated/0/Download/";

  } else if (Platform.isIOS) {
    externalStorageDirPath = (await getApplicationDocumentsDirectory()).absolute.path;
  }
  return externalStorageDirPath;
}
Future<String> prepareSaveDir() async {

 String _localPath = (await _findLocalPath())!;
  final savedDir = Directory(_localPath);
  bool hasExisted = await savedDir.exists();
  if (!hasExisted) {
    savedDir.create();
  }
  return _localPath;
}
Future<String> download(String url,String name) async{
  var data = await http.get(Uri.parse(url));
  // final output = await prepareSaveDir();
  Directory tempDir = await getTemporaryDirectory();
  final file = File('${tempDir.absolute.path}/$name');
  print('FilePath ${file.path}');
  await file.writeAsBytes(data.bodyBytes);
  return file.path;
}


