import 'package:dartz/dartz.dart';
import 'package:fuud/features/home/data/datasources/country_datasource.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/domain/repositories/country_repository.dart';
import 'package:fuud/features/home/domain/usecases/update_ctiy_usecase.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/data/datasources/ads_datasource.dart';
import 'package:fuud/features/home/domain/repositories/ads_repository.dart';

@LazySingleton(as: CountryRepository)
class CountryRepoImpl implements CountryRepository {
  final CountryDatasource sigInRemoteDatasource;

  CountryRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, CountryResponse>> getCountry(params) async {
    try {
      final result = await sigInRemoteDatasource.countryList(params);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, String>> setCity(CityParams params) async {
    try {
      final result = await sigInRemoteDatasource.updateCity(params);
      return right(result);
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
