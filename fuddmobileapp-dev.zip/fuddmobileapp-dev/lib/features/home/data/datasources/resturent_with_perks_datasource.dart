import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/perkresturent_list.dart';
import 'package:fuud/features/home/domain/usecases/perks_resturent_usecase.dart';

abstract class ResturentWithPerksRemoteDatasource {
  Future<List<ResturentWithPerks>> resturentWithPerksUser(
      PerksRestaurantParams params);
}

@LazySingleton(as: ResturentWithPerksRemoteDatasource)
class ResturentWithPerksRemoteDatasourceImpl
    implements ResturentWithPerksRemoteDatasource {
  final Client client;
  ResturentWithPerksRemoteDatasourceImpl({required this.client});

  @override
  Future<List<ResturentWithPerks>> resturentWithPerksUser(
      PerksRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse("${Apis.getperkrestrolist}/${params.userId}/${params.count}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('resturentWithPerksResponce ${response.statusCode}, : ${response.body} ');

      if (response.statusCode == 200) {
        final user = resturentwithperksFromJson(response.body);
        print('resturentWithPerksResponce Json $user');
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
