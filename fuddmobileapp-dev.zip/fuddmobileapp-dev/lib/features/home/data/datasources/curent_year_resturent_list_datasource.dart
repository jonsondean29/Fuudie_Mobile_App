import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/curent_year_resturant_list.dart';
import 'package:fuud/features/home/domain/usecases/current_year_resturents_usecase.dart';

abstract class CurrentYearResturentRemoteDatasource {
  Future<List<Curryearrestrolist>> currentYearResturentUser(
      CurrentYearRestaurantParams params);
}

@LazySingleton(as: CurrentYearResturentRemoteDatasource)
class CurrentYearResturentRemoteDatasourceImpl
    implements CurrentYearResturentRemoteDatasource {
  final Client client;
  CurrentYearResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<Curryearrestrolist>> currentYearResturentUser(
      CurrentYearRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse(
            "${Apis.getcurryearrestrolist}/${params.userId}/${params.count}"),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        log('myResponce ${response.statusCode}, : ${response.body} ');

        final user = getcurryearrestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
