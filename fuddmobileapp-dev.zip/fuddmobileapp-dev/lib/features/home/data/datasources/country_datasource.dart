import 'dart:convert';
import 'dart:developer';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/domain/usecases/country_usecase.dart';
import 'package:fuud/features/home/domain/usecases/update_ctiy_usecase.dart';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';

abstract class CountryDatasource {
  Future<CountryResponse> countryList(CountryParams param);
  Future<String> updateCity(CityParams param);
}

@LazySingleton(as: CountryDatasource)
class CountryDatasourceImpl implements CountryDatasource {
  final Client client;
  CountryDatasourceImpl({required this.client});

  @override
  Future<CountryResponse> countryList(param) async {
    try {
      final response = await client.get(
        Uri.parse("${Apis.getCountry}/${param.userID}"),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('getCountry ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return CountryResponse.fromJson(jsonDecode(response.body));
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }

  @override
  Future<String> updateCity(CityParams param) async {
    // TODO: implement updateCity
    String api="${Apis.setCurrentCity}/${param.sortName}/${param.cityName}/${param.userID}";
    print(api);
    try {
      final response = await client.post(
        Uri.parse(api),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('updateCity ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['message'];
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
