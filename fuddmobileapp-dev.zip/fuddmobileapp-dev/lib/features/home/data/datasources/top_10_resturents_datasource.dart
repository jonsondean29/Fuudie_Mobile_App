import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/top_10_resturents_model.dart';
import 'package:fuud/features/home/domain/usecases/top_10_resturents_usecase.dart';

abstract class TopTenResturentRemoteDatasource {
  Future<List<TopTenrestrolist>> topTenResturentUser(
      TopTenRestaurantParams params);
}

@LazySingleton(as: TopTenResturentRemoteDatasource)
class TopTenResturentRemoteDatasourceImpl
    implements TopTenResturentRemoteDatasource {
  final Client client;
  TopTenResturentRemoteDatasourceImpl({required this.client});

  @override
  Future<List<TopTenrestrolist>> topTenResturentUser(
      TopTenRestaurantParams params) async {
    try {
      final response = await client.get(
        Uri.parse(Apis.getcityrestolist),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        log('newResturent ${response.statusCode}, : ${response.body} ');

        final user = toptenrestrolistFromJson(response.body);
        if (user.isNotEmpty) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
