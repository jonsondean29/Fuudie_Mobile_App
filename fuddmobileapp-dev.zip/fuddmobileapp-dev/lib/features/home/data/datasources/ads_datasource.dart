import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/data/models/ads_model.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';

import '../models/banners.dart';

abstract class AdsRemoteDatasource {
  Future<List<Banners>> adsList(AdsParams params);
}

@LazySingleton(as: AdsRemoteDatasource)
class AdsRemoteDatasourceImpl implements AdsRemoteDatasource {
  final Client client;
  AdsRemoteDatasourceImpl({required this.client});

  @override
  Future<List<Banners>> adsList(AdsParams params) async {
    String adsApi="${Apis.getAds}/${params.adsposition}/${params.selectedCity}";
    print('adsApi==>$adsApi');
    try {
      final response = await client.get(
        Uri.parse(adsApi),
        headers: {
          'content-type': 'application/json',
        },
      );
      log('myAdsResponce ${response.statusCode}, : ${response.body} ');
      if (response.statusCode == 200) {
        List<Banners>list=[];
        for(var v in jsonDecode(response.body)){
          list.add(Banners.fromJson(v));
        }
        return list;
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
