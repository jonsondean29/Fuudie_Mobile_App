import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/home/domain/usecases/resturant_details_usecase.dart';
import 'package:fuud/features/home/data/models/restaurant_details_response_model.dart';

abstract class RestaurantDetailsRemoteDatasource {
  Future<RestaurantDetailsResponse> restaurantDetailsUser(
      RestaurantDetailsParams params);
}

@LazySingleton(as: RestaurantDetailsRemoteDatasource)
class RestaurantDetailsRemoteDatasourceImpl
    implements RestaurantDetailsRemoteDatasource {
  final Client client;
  RestaurantDetailsRemoteDatasourceImpl({required this.client});

  @override
  Future<RestaurantDetailsResponse> restaurantDetailsUser(
      RestaurantDetailsParams params) async {
    log('Url ${"${Apis.restaurantDetails}/${params.id}/${params.userId}"}');
    try {
      final response = await client.get(
        Uri.parse("${Apis.restaurantDetails}/${params.id}/${params.userId}"),
        headers: {
          'content-type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        log('myResponce ${response.statusCode}, : ${response.body} ');

        final responseBody = json.decode(response.body);

        final user = RestaurantDetailsResponse.fromJson(responseBody);
        if (user.id != null) {
          return user;
        } else {
          // throw CacheException();
          throw ServerException(errorMessage: "No Details Found");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
