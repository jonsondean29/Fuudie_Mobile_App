class CountryResponse {
  CountryResponse({
      this.countries, 
      this.selectedcountry, 
      this.selectedcountryflag, 
      this.selectedcity,});

  CountryResponse.fromJson(dynamic json) {
    if (json['countries'] != null) {
      countries = [];
      json['countries'].forEach((v) {
        countries?.add(Countries.fromJson(v));
      });
    }
    selectedcountry = json['selectedcountry'];
    selectedcountryflag = json['selectedcountryflag'];
    selectedcity = json['selectedcity'];
  }
  List<Countries>? countries;
  String? selectedcountry;
  String? selectedcountryflag;
  String? selectedcity;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (countries != null) {
      map['countries'] = countries?.map((v) => v.toJson()).toList();
    }
    map['selectedcountry'] = selectedcountry;
    map['selectedcountryflag'] = selectedcountryflag;
    map['selectedcity'] = selectedcity;
    return map;
  }

}

class Countries {
  Countries({
      this.id, 
      this.countryName, 
      this.addedBy, 
      this.createdAt, 
      this.updatedAt, 
      this.shortName, 
      this.flagimg, 
      this.cities,});

  Countries.fromJson(dynamic json) {
    id = json['id'];
    countryName = json['country_name'];
    addedBy = json['added_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    shortName = json['short_name'];
    flagimg = json['flagimg'];
    if (json['cities'] != null) {
      cities = [];
      json['cities'].forEach((v) {
        cities?.add(City.fromJson(v));
      });
    }
  }
  dynamic id;
  String? countryName;
  String? addedBy;
  String? createdAt;
  dynamic updatedAt;
  String? shortName;
  String? flagimg;
  List<City>? cities;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['country_name'] = countryName;
    map['added_by'] = addedBy;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['short_name'] = shortName;
    map['flagimg'] = flagimg;
    return map;
  }

}
class City {
  City({
      this.name});

  City.fromJson(dynamic json) {
    name = json['name'];
  }
  String? name;



}