import 'dart:convert';
import 'package:freezed_annotation/freezed_annotation.dart';
// ignore_for_file: invalid_annotation_target

// To parse this JSON data, do
//
//     final resturentwithperks = resturentwithperksFromJson(jsonString?);

part 'perkresturent_list.freezed.dart';
part 'perkresturent_list.g.dart';

List<ResturentWithPerks> resturentwithperksFromJson(String str) =>
    List<ResturentWithPerks>.from(
        json.decode(str).map((x) => ResturentWithPerks.fromJson(x)));

String resturentwithperksToJson(List<ResturentWithPerks> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

@freezed
class ResturentWithPerks with _$ResturentWithPerks {
  const factory ResturentWithPerks({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "name") required String? name,
    @JsonKey(name: "added_by") required int? addedBy,
    @JsonKey(name: "categoryid") required String? categoryid,
    @JsonKey(name: "categoryname") required String? categoryname,
    @JsonKey(name: "tags") required String? tags,
    @JsonKey(name: "shortdescription") required String? shortdescription,
    @JsonKey(name: "description") required String? description,
    @JsonKey(name: "location") required String? location,
    @JsonKey(name: "city") required String? city,
    @JsonKey(name: "state") required String? state,
    @JsonKey(name: "docuntry") required dynamic docuntry,
    @JsonKey(name: "totfav") required int? totfav,
    @JsonKey(name: "totbeen") required int? totbeen,
    @JsonKey(name: "tottry") required int? tottry,
    @JsonKey(name: "pincode") required String? pincode,
    @JsonKey(name: "phone") required dynamic phone,
    @JsonKey(name: "lat") required String? lat,
    @JsonKey(name: "lng") required String? lng,
    @JsonKey(name: "fblink") required dynamic fblink,
    @JsonKey(name: "instalink") required String? instalink,
    @JsonKey(name: "rating") required double? rating,
    @JsonKey(name: "totreviews") required int? totreviews,
    @JsonKey(name: "barcode") required dynamic barcode,
    @JsonKey(name: "slug") required String? slug,
    @JsonKey(name: "createdon") required DateTime? createdon,
    @JsonKey(name: "updatedon") required dynamic updatedon,
    @JsonKey(name: "isactive") required int? isactive,
    @JsonKey(name: "isperks") required int? isperks,
    @JsonKey(name: "isexclusive") required int? isexclusive,
    @JsonKey(name: "iswishlist") required int? iswishlist,
    @JsonKey(name: "isbeenlist") required int? isbeenlist,
    @JsonKey(name: "istrylist") required int? istrylist,
    @JsonKey(name: "mainimg") required dynamic mainimg,
    @JsonKey(name: "restrimglist") required dynamic restrimglist,
    @JsonKey(name: "restroreviewlst") required dynamic restroreviewlst,
  }) = _ResturentWithPerks;

  factory ResturentWithPerks.fromJson(Map<String, dynamic> json) =>
      _$ResturentWithPerksFromJson(json);
}
