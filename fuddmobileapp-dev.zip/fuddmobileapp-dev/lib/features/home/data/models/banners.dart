class Banners {
  Banners({
      this.id, 
      this.name, 
      this.categoryid, 
      this.categoryname, 
      this.city, 
      this.state, 
      this.docuntry, 
      this.slug, 
      this.createdon, 
      this.isactive, 
      this.isperks, 
      this.isexclusive, 
      this.mainimg, 
      this.adsposition,});

  Banners.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    categoryid = json['categoryid'];
    categoryname = json['categoryname'];
    city = json['city'];
    state = json['state'];
    docuntry = json['docuntry'];
    slug = json['slug'];
    createdon = json['createdon'];
    isactive = json['isactive'];
    isperks = json['isperks'];
    isexclusive = json['isexclusive'];
    mainimg = json['mainimg'];
    adsposition = json['adsposition'];
  }
  int? id;
  String? name;
  String? categoryid;
  String? categoryname;
  String? city;
  String? state;
  dynamic docuntry;
  String? slug;
  String? createdon;
  int? isactive;
  int? isperks;
  int? isexclusive;
  String? mainimg;
  String? adsposition;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['categoryid'] = categoryid;
    map['categoryname'] = categoryname;
    map['city'] = city;
    map['state'] = state;
    map['docuntry'] = docuntry;
    map['slug'] = slug;
    map['createdon'] = createdon;
    map['isactive'] = isactive;
    map['isperks'] = isperks;
    map['isexclusive'] = isexclusive;
    map['mainimg'] = mainimg;
    map['adsposition'] = adsposition;
    return map;
  }

}