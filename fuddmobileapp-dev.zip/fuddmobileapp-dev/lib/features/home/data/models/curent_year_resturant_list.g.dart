// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'curent_year_resturant_list.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CurryearrestrolistImpl _$$CurryearrestrolistImplFromJson(
        Map<String, dynamic> json) =>
    _$CurryearrestrolistImpl(
      id: (json['id'] as num?)?.toInt(),
      name: json['name'] as String?,
      addedBy: (json['added_by'] as num?)?.toInt(),
      categoryid: json['categoryid'] as String?,
      categoryname: json['categoryname'] as String?,
      tags: json['tags'] as String?,
      shortdescription: json['shortdescription'] as String?,
      description: json['description'] as String?,
      location: json['location'] as String?,
      city: json['city'] as String?,
      state: json['state'] as String?,
      docuntry: json['docuntry'],
      totfav: (json['totfav'] as num?)?.toInt(),
      totbeen: (json['totbeen'] as num?)?.toInt(),
      tottry: (json['tottry'] as num?)?.toInt(),
      pincode: json['pincode'] as String?,
      phone: json['phone'],
      lat: json['lat'] as String?,
      lng: json['lng'] as String?,
      fblink: json['fblink'],
      instalink: json['instalink'] as String?,
      rating: (json['rating'] as num?)?.toDouble(),
      totreviews: (json['totreviews'] as num?)?.toInt(),
      barcode: json['barcode'],
      slug: json['slug'] as String?,
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
      updatedon: json['updatedon'],
      isactive: (json['isactive'] as num?)?.toInt(),
      isperks: (json['isperks'] as num?)?.toInt(),
      isexclusive: (json['isexclusive'] as num?)?.toInt(),
      iswishlist: (json['iswishlist'] as num?)?.toInt(),
      isbeenlist: (json['isbeenlist'] as num?)?.toInt(),
      istrylist: (json['istrylist'] as num?)?.toInt(),
      mainimg: json['mainimg'],
      restrimglist: json['restrimglist'],
      restroreviewlst: json['restroreviewlst'],
    );

Map<String, dynamic> _$$CurryearrestrolistImplToJson(
        _$CurryearrestrolistImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'added_by': instance.addedBy,
      'categoryid': instance.categoryid,
      'categoryname': instance.categoryname,
      'tags': instance.tags,
      'shortdescription': instance.shortdescription,
      'description': instance.description,
      'location': instance.location,
      'city': instance.city,
      'state': instance.state,
      'docuntry': instance.docuntry,
      'totfav': instance.totfav,
      'totbeen': instance.totbeen,
      'tottry': instance.tottry,
      'pincode': instance.pincode,
      'phone': instance.phone,
      'lat': instance.lat,
      'lng': instance.lng,
      'fblink': instance.fblink,
      'instalink': instance.instalink,
      'rating': instance.rating,
      'totreviews': instance.totreviews,
      'barcode': instance.barcode,
      'slug': instance.slug,
      'createdon': instance.createdon?.toIso8601String(),
      'updatedon': instance.updatedon,
      'isactive': instance.isactive,
      'isperks': instance.isperks,
      'isexclusive': instance.isexclusive,
      'iswishlist': instance.iswishlist,
      'isbeenlist': instance.isbeenlist,
      'istrylist': instance.istrylist,
      'mainimg': instance.mainimg,
      'restrimglist': instance.restrimglist,
      'restroreviewlst': instance.restroreviewlst,
    };
