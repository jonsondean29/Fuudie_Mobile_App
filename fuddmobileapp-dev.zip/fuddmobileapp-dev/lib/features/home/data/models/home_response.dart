import 'banners.dart';

class HomeResponse {
  HomeResponse({
      this.restaurantlist,});

  HomeResponse.fromJson(dynamic json) {
    if (json['restaurantlist'] != null) {
      restaurantlist = [];
      json['restaurantlist'].forEach((v) {
        restaurantlist?.add(Restaurantlist.fromJson(v));
      });
    }
  }
  List<Restaurantlist>? restaurantlist;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (restaurantlist != null) {
      map['restaurantlist'] = restaurantlist?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Restaurantlist {
  Restaurantlist({
      this.title, 
      this.restrolist,});

  Restaurantlist.fromJson(dynamic json) {
    title = json['title'];
    if (json['restrolist'] != null) {
      restrolist = [];
      bannerlist = [];
      json['restrolist'].forEach((v) {
        if(json['title']=="Ads"){
          bannerlist?.add(Banners.fromJson(v));
        }else if(json['title']=="Banner Ads"){
          bannerlist?.add(Banners.fromJson(v));
        }else {
          restrolist?.add(Restrolist.fromJson(v));
        }
      });
    }
  }
  String? title;
  List<Restrolist>? restrolist;
  List<Banners>? bannerlist;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    if (restrolist != null) {
      map['restrolist'] = restrolist?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Restrolist {
  Restrolist({
      this.id, 
      this.name, 
      this.addedBy, 
      this.categoryid, 
      this.categoryname, 
      this.tags, 
      this.shortdescription, 
      this.description, 
      this.location, 
      this.city, 
      this.state, 
      this.docuntry, 
      this.totfav, 
      this.totbeen, 
      this.tottry, 
      this.pincode, 
      this.phone, 
      this.lat, 
      this.lng, 
      this.fblink, 
      this.instalink, 
      this.rating, 
      this.totreviews, 
      this.barcode, 
      this.slug, 
      this.createdon, 
      this.updatedon, 
      this.isactive, 
      this.isperks, 
      this.isexclusive, 
      this.iswishlist, 
      this.isbeenlist, 
      this.istrylist, 
      this.mainimg, 
      this.title, 
      this.restrimglist, 
      this.restroreviewlst,});

  Restrolist.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    addedBy = json['added_by'];
    categoryid = json['categoryid'];
    categoryname = json['categoryname'];
    tags = json['tags'];
    shortdescription = json['shortdescription'];
    description = json['description'];
    location = json['location'];
    city = json['city'];
    state = json['state'];
    docuntry = json['docuntry'];
    totfav = json['totfav'];
    totbeen = json['totbeen'];
    tottry = json['tottry'];
    pincode = json['pincode'];
    phone = json['phone'];
    lat = json['lat'];
    lng = json['lng'];
    fblink = json['fblink'];
    instalink = json['instalink'];
    rating = json['rating'];
    totreviews = json['totreviews'];
    barcode = json['barcode'];
    slug = json['slug'];
    createdon = json['createdon'];
    updatedon = json['updatedon'];
    isactive = json['isactive'];
    isperks = json['isperks'];
    isexclusive = json['isexclusive'];
    iswishlist = json['iswishlist'];
    isbeenlist = json['isbeenlist'];
    istrylist = json['istrylist'];
    mainimg = json['mainimg'];
    title = json['title'];
    restrimglist = json['restrimglist'];
    restroreviewlst = json['restroreviewlst'];
  }
  int? id;
  String? name;
  int? addedBy;
  String? categoryid;
  String? categoryname;
  String? tags;
  dynamic shortdescription;
  dynamic description;
  String? location;
  String? city;
  dynamic state;
  dynamic docuntry;
  int? totfav;
  int? totbeen;
  int? tottry;
  dynamic pincode;
  dynamic phone;
  String? lat;
  String? lng;
  dynamic fblink;
  dynamic instalink;
  double? rating;
  int? totreviews;
  dynamic barcode;
  String? slug;
  String? createdon;
  dynamic updatedon;
  int? isactive;
  int? isperks;
  int? isexclusive;
  int? iswishlist;
  int? isbeenlist;
  int? istrylist;
  String? mainimg;
  dynamic title;
  dynamic restrimglist;
  dynamic restroreviewlst;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['added_by'] = addedBy;
    map['categoryid'] = categoryid;
    map['categoryname'] = categoryname;
    map['tags'] = tags;
    map['shortdescription'] = shortdescription;
    map['description'] = description;
    map['location'] = location;
    map['city'] = city;
    map['state'] = state;
    map['docuntry'] = docuntry;
    map['totfav'] = totfav;
    map['totbeen'] = totbeen;
    map['tottry'] = tottry;
    map['pincode'] = pincode;
    map['phone'] = phone;
    map['lat'] = lat;
    map['lng'] = lng;
    map['fblink'] = fblink;
    map['instalink'] = instalink;
    map['rating'] = rating;
    map['totreviews'] = totreviews;
    map['barcode'] = barcode;
    map['slug'] = slug;
    map['createdon'] = createdon;
    map['updatedon'] = updatedon;
    map['isactive'] = isactive;
    map['isperks'] = isperks;
    map['isexclusive'] = isexclusive;
    map['iswishlist'] = iswishlist;
    map['isbeenlist'] = isbeenlist;
    map['istrylist'] = istrylist;
    map['mainimg'] = mainimg;
    map['title'] = title;
    map['restrimglist'] = restrimglist;
    map['restroreviewlst'] = restroreviewlst;
    return map;
  }

}