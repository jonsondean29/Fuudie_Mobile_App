// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$HomeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeEventCopyWith<$Res> {
  factory $HomeEventCopyWith(HomeEvent value, $Res Function(HomeEvent) then) =
      _$HomeEventCopyWithImpl<$Res, HomeEvent>;
}

/// @nodoc
class _$HomeEventCopyWithImpl<$Res, $Val extends HomeEvent>
    implements $HomeEventCopyWith<$Res> {
  _$HomeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'HomeEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements HomeEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$HomeFeatchDetailsImplCopyWith<$Res> {
  factory _$$HomeFeatchDetailsImplCopyWith(_$HomeFeatchDetailsImpl value,
          $Res Function(_$HomeFeatchDetailsImpl) then) =
      __$$HomeFeatchDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int id, int resturentId});
}

/// @nodoc
class __$$HomeFeatchDetailsImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$HomeFeatchDetailsImpl>
    implements _$$HomeFeatchDetailsImplCopyWith<$Res> {
  __$$HomeFeatchDetailsImplCopyWithImpl(_$HomeFeatchDetailsImpl _value,
      $Res Function(_$HomeFeatchDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? resturentId = null,
  }) {
    return _then(_$HomeFeatchDetailsImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      resturentId: null == resturentId
          ? _value.resturentId
          : resturentId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$HomeFeatchDetailsImpl implements HomeFeatchDetails {
  const _$HomeFeatchDetailsImpl({required this.id, required this.resturentId});

  @override
  final int id;
  @override
  final int resturentId;

  @override
  String toString() {
    return 'HomeEvent.featchDetails(id: $id, resturentId: $resturentId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HomeFeatchDetailsImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.resturentId, resturentId) ||
                other.resturentId == resturentId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, resturentId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HomeFeatchDetailsImplCopyWith<_$HomeFeatchDetailsImpl> get copyWith =>
      __$$HomeFeatchDetailsImplCopyWithImpl<_$HomeFeatchDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return featchDetails(id, resturentId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return featchDetails?.call(id, resturentId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (featchDetails != null) {
      return featchDetails(id, resturentId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return featchDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return featchDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (featchDetails != null) {
      return featchDetails(this);
    }
    return orElse();
  }
}

abstract class HomeFeatchDetails implements HomeEvent {
  const factory HomeFeatchDetails(
      {required final int id,
      required final int resturentId}) = _$HomeFeatchDetailsImpl;

  int get id;
  int get resturentId;
  @JsonKey(ignore: true)
  _$$HomeFeatchDetailsImplCopyWith<_$HomeFeatchDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$HomeFeatchImplCopyWith<$Res> {
  factory _$$HomeFeatchImplCopyWith(
          _$HomeFeatchImpl value, $Res Function(_$HomeFeatchImpl) then) =
      __$$HomeFeatchImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$HomeFeatchImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$HomeFeatchImpl>
    implements _$$HomeFeatchImplCopyWith<$Res> {
  __$$HomeFeatchImplCopyWithImpl(
      _$HomeFeatchImpl _value, $Res Function(_$HomeFeatchImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$HomeFeatchImpl implements HomeFeatch {
  const _$HomeFeatchImpl();

  @override
  String toString() {
    return 'HomeEvent.featch()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$HomeFeatchImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return featch();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return featch?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return featch(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return featch?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (featch != null) {
      return featch(this);
    }
    return orElse();
  }
}

abstract class HomeFeatch implements HomeEvent {
  const factory HomeFeatch() = _$HomeFeatchImpl;
}

/// @nodoc
abstract class _$$CountryFeatchImplCopyWith<$Res> {
  factory _$$CountryFeatchImplCopyWith(
          _$CountryFeatchImpl value, $Res Function(_$CountryFeatchImpl) then) =
      __$$CountryFeatchImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int id});
}

/// @nodoc
class __$$CountryFeatchImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$CountryFeatchImpl>
    implements _$$CountryFeatchImplCopyWith<$Res> {
  __$$CountryFeatchImplCopyWithImpl(
      _$CountryFeatchImpl _value, $Res Function(_$CountryFeatchImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
  }) {
    return _then(_$CountryFeatchImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$CountryFeatchImpl implements CountryFeatch {
  const _$CountryFeatchImpl({required this.id});

  @override
  final int id;

  @override
  String toString() {
    return 'HomeEvent.fetchCountry(id: $id)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CountryFeatchImpl &&
            (identical(other.id, id) || other.id == id));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CountryFeatchImplCopyWith<_$CountryFeatchImpl> get copyWith =>
      __$$CountryFeatchImplCopyWithImpl<_$CountryFeatchImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return fetchCountry(id);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return fetchCountry?.call(id);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (fetchCountry != null) {
      return fetchCountry(id);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return fetchCountry(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return fetchCountry?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (fetchCountry != null) {
      return fetchCountry(this);
    }
    return orElse();
  }
}

abstract class CountryFeatch implements HomeEvent {
  const factory CountryFeatch({required final int id}) = _$CountryFeatchImpl;

  int get id;
  @JsonKey(ignore: true)
  _$$CountryFeatchImplCopyWith<_$CountryFeatchImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$setCityImplCopyWith<$Res> {
  factory _$$setCityImplCopyWith(
          _$setCityImpl value, $Res Function(_$setCityImpl) then) =
      __$$setCityImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String sortName, String cityName, int id});
}

/// @nodoc
class __$$setCityImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$setCityImpl>
    implements _$$setCityImplCopyWith<$Res> {
  __$$setCityImplCopyWithImpl(
      _$setCityImpl _value, $Res Function(_$setCityImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sortName = null,
    Object? cityName = null,
    Object? id = null,
  }) {
    return _then(_$setCityImpl(
      sortName: null == sortName
          ? _value.sortName
          : sortName // ignore: cast_nullable_to_non_nullable
              as String,
      cityName: null == cityName
          ? _value.cityName
          : cityName // ignore: cast_nullable_to_non_nullable
              as String,
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$setCityImpl implements setCity {
  const _$setCityImpl(
      {required this.sortName, required this.cityName, required this.id});

  @override
  final String sortName;
  @override
  final String cityName;
  @override
  final int id;

  @override
  String toString() {
    return 'HomeEvent.setCity(sortName: $sortName, cityName: $cityName, id: $id)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$setCityImpl &&
            (identical(other.sortName, sortName) ||
                other.sortName == sortName) &&
            (identical(other.cityName, cityName) ||
                other.cityName == cityName) &&
            (identical(other.id, id) || other.id == id));
  }

  @override
  int get hashCode => Object.hash(runtimeType, sortName, cityName, id);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$setCityImplCopyWith<_$setCityImpl> get copyWith =>
      __$$setCityImplCopyWithImpl<_$setCityImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return setCity(sortName, cityName, id);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return setCity?.call(sortName, cityName, id);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (setCity != null) {
      return setCity(sortName, cityName, id);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return setCity(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return setCity?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (setCity != null) {
      return setCity(this);
    }
    return orElse();
  }
}

abstract class setCity implements HomeEvent {
  const factory setCity(
      {required final String sortName,
      required final String cityName,
      required final int id}) = _$setCityImpl;

  String get sortName;
  String get cityName;
  int get id;
  @JsonKey(ignore: true)
  _$$setCityImplCopyWith<_$setCityImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$searchRestroImplCopyWith<$Res> {
  factory _$$searchRestroImplCopyWith(
          _$searchRestroImpl value, $Res Function(_$searchRestroImpl) then) =
      __$$searchRestroImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String q});
}

/// @nodoc
class __$$searchRestroImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$searchRestroImpl>
    implements _$$searchRestroImplCopyWith<$Res> {
  __$$searchRestroImplCopyWithImpl(
      _$searchRestroImpl _value, $Res Function(_$searchRestroImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? q = null,
  }) {
    return _then(_$searchRestroImpl(
      q: null == q
          ? _value.q
          : q // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$searchRestroImpl implements searchRestro {
  const _$searchRestroImpl({required this.q});

  @override
  final String q;

  @override
  String toString() {
    return 'HomeEvent.search(q: $q)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$searchRestroImpl &&
            (identical(other.q, q) || other.q == q));
  }

  @override
  int get hashCode => Object.hash(runtimeType, q);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$searchRestroImplCopyWith<_$searchRestroImpl> get copyWith =>
      __$$searchRestroImplCopyWithImpl<_$searchRestroImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(int id, int resturentId) featchDetails,
    required TResult Function() featch,
    required TResult Function(int id) fetchCountry,
    required TResult Function(String sortName, String cityName, int id) setCity,
    required TResult Function(String q) search,
  }) {
    return search(q);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(int id, int resturentId)? featchDetails,
    TResult? Function()? featch,
    TResult? Function(int id)? fetchCountry,
    TResult? Function(String sortName, String cityName, int id)? setCity,
    TResult? Function(String q)? search,
  }) {
    return search?.call(q);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(int id, int resturentId)? featchDetails,
    TResult Function()? featch,
    TResult Function(int id)? fetchCountry,
    TResult Function(String sortName, String cityName, int id)? setCity,
    TResult Function(String q)? search,
    required TResult orElse(),
  }) {
    if (search != null) {
      return search(q);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(HomeFeatchDetails value) featchDetails,
    required TResult Function(HomeFeatch value) featch,
    required TResult Function(CountryFeatch value) fetchCountry,
    required TResult Function(setCity value) setCity,
    required TResult Function(searchRestro value) search,
  }) {
    return search(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(HomeFeatchDetails value)? featchDetails,
    TResult? Function(HomeFeatch value)? featch,
    TResult? Function(CountryFeatch value)? fetchCountry,
    TResult? Function(setCity value)? setCity,
    TResult? Function(searchRestro value)? search,
  }) {
    return search?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(HomeFeatchDetails value)? featchDetails,
    TResult Function(HomeFeatch value)? featch,
    TResult Function(CountryFeatch value)? fetchCountry,
    TResult Function(setCity value)? setCity,
    TResult Function(searchRestro value)? search,
    required TResult orElse(),
  }) {
    if (search != null) {
      return search(this);
    }
    return orElse();
  }
}

abstract class searchRestro implements HomeEvent {
  const factory searchRestro({required final String q}) = _$searchRestroImpl;

  String get q;
  @JsonKey(ignore: true)
  _$$searchRestroImplCopyWith<_$searchRestroImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$HomeState {
  RestaurantDetailsEntity? get restaurantDetailsEntity =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  CountryResponse? get countryResponse => throw _privateConstructorUsedError;
  HomeResponse? get homeResponse => throw _privateConstructorUsedError;
  List<Banners>? get bannerList => throw _privateConstructorUsedError;
  List<Banners>? get bannerTopList => throw _privateConstructorUsedError;
  List<Banners>? get bannerBottomList => throw _privateConstructorUsedError;
  List<Restrolist>? get searchList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $HomeStateCopyWith<HomeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeStateCopyWith<$Res> {
  factory $HomeStateCopyWith(HomeState value, $Res Function(HomeState) then) =
      _$HomeStateCopyWithImpl<$Res, HomeState>;
  @useResult
  $Res call(
      {RestaurantDetailsEntity? restaurantDetailsEntity,
      bool isLoading,
      CountryResponse? countryResponse,
      HomeResponse? homeResponse,
      List<Banners>? bannerList,
      List<Banners>? bannerTopList,
      List<Banners>? bannerBottomList,
      List<Restrolist>? searchList});
}

/// @nodoc
class _$HomeStateCopyWithImpl<$Res, $Val extends HomeState>
    implements $HomeStateCopyWith<$Res> {
  _$HomeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? restaurantDetailsEntity = freezed,
    Object? isLoading = null,
    Object? countryResponse = freezed,
    Object? homeResponse = freezed,
    Object? bannerList = freezed,
    Object? bannerTopList = freezed,
    Object? bannerBottomList = freezed,
    Object? searchList = freezed,
  }) {
    return _then(_value.copyWith(
      restaurantDetailsEntity: freezed == restaurantDetailsEntity
          ? _value.restaurantDetailsEntity
          : restaurantDetailsEntity // ignore: cast_nullable_to_non_nullable
              as RestaurantDetailsEntity?,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      countryResponse: freezed == countryResponse
          ? _value.countryResponse
          : countryResponse // ignore: cast_nullable_to_non_nullable
              as CountryResponse?,
      homeResponse: freezed == homeResponse
          ? _value.homeResponse
          : homeResponse // ignore: cast_nullable_to_non_nullable
              as HomeResponse?,
      bannerList: freezed == bannerList
          ? _value.bannerList
          : bannerList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      bannerTopList: freezed == bannerTopList
          ? _value.bannerTopList
          : bannerTopList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      bannerBottomList: freezed == bannerBottomList
          ? _value.bannerBottomList
          : bannerBottomList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      searchList: freezed == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HomeStateImplCopyWith<$Res>
    implements $HomeStateCopyWith<$Res> {
  factory _$$HomeStateImplCopyWith(
          _$HomeStateImpl value, $Res Function(_$HomeStateImpl) then) =
      __$$HomeStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {RestaurantDetailsEntity? restaurantDetailsEntity,
      bool isLoading,
      CountryResponse? countryResponse,
      HomeResponse? homeResponse,
      List<Banners>? bannerList,
      List<Banners>? bannerTopList,
      List<Banners>? bannerBottomList,
      List<Restrolist>? searchList});
}

/// @nodoc
class __$$HomeStateImplCopyWithImpl<$Res>
    extends _$HomeStateCopyWithImpl<$Res, _$HomeStateImpl>
    implements _$$HomeStateImplCopyWith<$Res> {
  __$$HomeStateImplCopyWithImpl(
      _$HomeStateImpl _value, $Res Function(_$HomeStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? restaurantDetailsEntity = freezed,
    Object? isLoading = null,
    Object? countryResponse = freezed,
    Object? homeResponse = freezed,
    Object? bannerList = freezed,
    Object? bannerTopList = freezed,
    Object? bannerBottomList = freezed,
    Object? searchList = freezed,
  }) {
    return _then(_$HomeStateImpl(
      restaurantDetailsEntity: freezed == restaurantDetailsEntity
          ? _value.restaurantDetailsEntity
          : restaurantDetailsEntity // ignore: cast_nullable_to_non_nullable
              as RestaurantDetailsEntity?,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      countryResponse: freezed == countryResponse
          ? _value.countryResponse
          : countryResponse // ignore: cast_nullable_to_non_nullable
              as CountryResponse?,
      homeResponse: freezed == homeResponse
          ? _value.homeResponse
          : homeResponse // ignore: cast_nullable_to_non_nullable
              as HomeResponse?,
      bannerList: freezed == bannerList
          ? _value._bannerList
          : bannerList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      bannerTopList: freezed == bannerTopList
          ? _value._bannerTopList
          : bannerTopList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      bannerBottomList: freezed == bannerBottomList
          ? _value._bannerBottomList
          : bannerBottomList // ignore: cast_nullable_to_non_nullable
              as List<Banners>?,
      searchList: freezed == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<Restrolist>?,
    ));
  }
}

/// @nodoc

class _$HomeStateImpl implements _HomeState {
  _$HomeStateImpl(
      {required this.restaurantDetailsEntity,
      required this.isLoading,
      required this.countryResponse,
      required this.homeResponse,
      required final List<Banners>? bannerList,
      required final List<Banners>? bannerTopList,
      required final List<Banners>? bannerBottomList,
      required final List<Restrolist>? searchList})
      : _bannerList = bannerList,
        _bannerTopList = bannerTopList,
        _bannerBottomList = bannerBottomList,
        _searchList = searchList;

  @override
  final RestaurantDetailsEntity? restaurantDetailsEntity;
  @override
  final bool isLoading;
  @override
  final CountryResponse? countryResponse;
  @override
  final HomeResponse? homeResponse;
  final List<Banners>? _bannerList;
  @override
  List<Banners>? get bannerList {
    final value = _bannerList;
    if (value == null) return null;
    if (_bannerList is EqualUnmodifiableListView) return _bannerList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Banners>? _bannerTopList;
  @override
  List<Banners>? get bannerTopList {
    final value = _bannerTopList;
    if (value == null) return null;
    if (_bannerTopList is EqualUnmodifiableListView) return _bannerTopList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Banners>? _bannerBottomList;
  @override
  List<Banners>? get bannerBottomList {
    final value = _bannerBottomList;
    if (value == null) return null;
    if (_bannerBottomList is EqualUnmodifiableListView)
      return _bannerBottomList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Restrolist>? _searchList;
  @override
  List<Restrolist>? get searchList {
    final value = _searchList;
    if (value == null) return null;
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'HomeState(restaurantDetailsEntity: $restaurantDetailsEntity, isLoading: $isLoading, countryResponse: $countryResponse, homeResponse: $homeResponse, bannerList: $bannerList, bannerTopList: $bannerTopList, bannerBottomList: $bannerBottomList, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HomeStateImpl &&
            (identical(
                    other.restaurantDetailsEntity, restaurantDetailsEntity) ||
                other.restaurantDetailsEntity == restaurantDetailsEntity) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.countryResponse, countryResponse) ||
                other.countryResponse == countryResponse) &&
            (identical(other.homeResponse, homeResponse) ||
                other.homeResponse == homeResponse) &&
            const DeepCollectionEquality()
                .equals(other._bannerList, _bannerList) &&
            const DeepCollectionEquality()
                .equals(other._bannerTopList, _bannerTopList) &&
            const DeepCollectionEquality()
                .equals(other._bannerBottomList, _bannerBottomList) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      restaurantDetailsEntity,
      isLoading,
      countryResponse,
      homeResponse,
      const DeepCollectionEquality().hash(_bannerList),
      const DeepCollectionEquality().hash(_bannerTopList),
      const DeepCollectionEquality().hash(_bannerBottomList),
      const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      __$$HomeStateImplCopyWithImpl<_$HomeStateImpl>(this, _$identity);
}

abstract class _HomeState implements HomeState {
  factory _HomeState(
      {required final RestaurantDetailsEntity? restaurantDetailsEntity,
      required final bool isLoading,
      required final CountryResponse? countryResponse,
      required final HomeResponse? homeResponse,
      required final List<Banners>? bannerList,
      required final List<Banners>? bannerTopList,
      required final List<Banners>? bannerBottomList,
      required final List<Restrolist>? searchList}) = _$HomeStateImpl;

  @override
  RestaurantDetailsEntity? get restaurantDetailsEntity;
  @override
  bool get isLoading;
  @override
  CountryResponse? get countryResponse;
  @override
  HomeResponse? get homeResponse;
  @override
  List<Banners>? get bannerList;
  @override
  List<Banners>? get bannerTopList;
  @override
  List<Banners>? get bannerBottomList;
  @override
  List<Restrolist>? get searchList;
  @override
  @JsonKey(ignore: true)
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
