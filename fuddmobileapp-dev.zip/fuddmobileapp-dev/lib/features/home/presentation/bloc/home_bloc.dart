import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import 'package:fuud/features/home/domain/usecases/country_usecase.dart';
import 'package:fuud/features/home/domain/usecases/home_usecase.dart';
import 'package:fuud/features/home/domain/usecases/search_usecase.dart';
import 'package:injectable/injectable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';
import 'package:fuud/features/home/domain/entities/ads_entities.dart';
import 'package:fuud/features/home/domain/entities/restaurant_details_entity.dart';
import 'package:fuud/features/home/domain/usecases/resturant_details_usecase.dart';
import '../../data/models/banners.dart';
import '../../domain/usecases/update_ctiy_usecase.dart';
part 'home_event.dart';
part 'home_state.dart';
part 'home_bloc.freezed.dart';

@injectable
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final UpdateCtiyUsecase updateCtiyUsecase;
  final CountryUsecase countryUsecase;
  final HomeUsecase homeUsecase;
  final SearchUsecase searchUsecase;
  final RestaurantDetailsUsecase restaurantDetailsUsecase;
  final AdsUsecase adsUsecase;
  List<Banners>bannerList=[];
  List<Banners>bannerTopList=[];
  List<Banners>bannerBottomList=[];
  HomeBloc(
      {
      required this.countryUsecase,
      required this.updateCtiyUsecase,
      required this.restaurantDetailsUsecase,
      required this.homeUsecase,
      required this.adsUsecase,
      required this.searchUsecase
      })
      : super(HomeState.initial()) {

    on<HomeFeatchDetails>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await restaurantDetailsUsecase.call(
          RestaurantDetailsParams(id: event.resturentId, userId: event.id));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        print(
            'function Details rid: ${event.resturentId} uid: ${event.id} name: ${r.name}');
        emit(state.copyWith(restaurantDetailsEntity: r, isLoading: false));
      });
    });

    on<CountryFeatch>((event, emit) async {
      if(countryResponse.value!=null){
        emit(state.copyWith(countryResponse: countryResponse.value, isLoading: false));
        return;
      }
      emit(state.copyWith(isLoading: true));
      countryUsecase.call(CountryParams(userID: event.id)).then((result) {
        result.fold((l) {
          emit(state.copyWith(isLoading: false));
          print('function error $l');
        }, (r) async {
          countryResponse.value=r;
          Map<String,dynamic> res= await getDefaultCountry();
          if(res.isEmpty){
            setDefaultCountry({
              "selectedcountry":r.selectedcountry,
              "selectedcity":r.selectedcity,
              "selectedcountryflag":r.selectedcountryflag,
            });
            add(const HomeEvent.featch());
          }else{
            add(HomeEvent.fetchCountry(id: event.id));
          }
        });
      },);
    });

    on<setCity>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final result = await updateCtiyUsecase.call(CityParams(userID: event.id, sortName: event.sortName,cityName: event.cityName));
      result.fold((l) {
        emit(state.copyWith(isLoading: false));
        print('function error $l');
      }, (r) {
        Fluttertoast.showToast(
            msg: r,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.white,
            textColor: Colors.black,
            fontSize: 16.0);
       emit(state.copyWith(isLoading: false));
       add(const HomeEvent.featch());
      });
    });

    on<HomeFeatch>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      Map<String,dynamic>map=await getDefaultCountry();
     /* final adsRes = await adsUsecase
          .call(AdsParams(adsposition: 'banner',selectedCity: map['selectedcity']));
      adsRes.fold((l) {}, (r) {
        bannerList=r;
      });
*/
      final userId = await getIntValue('id') ?? 0;
      final homeRes = await homeUsecase
          .call(HomeParams(userID: userId, count: 0, sortName: map['selectedcountry'], city: map['selectedcity']));
      homeRes.fold((l) {}, (r) {
        emit(state.copyWith(homeResponse: r, bannerList:bannerList,isLoading: false));
      });

   /*   final adsResTop = await adsUsecase
          .call(AdsParams(adsposition: 'top',selectedCity: map['selectedcity']));
      adsResTop.fold((l) {}, (r) {
        bannerTopList=r;
      });

      final adsResBottom = await adsUsecase
          .call(AdsParams(adsposition: 'bottom',selectedCity: map['selectedcity']));
      adsResBottom.fold((l) {}, (r) {
        bannerBottomList=r;
        emit(state.copyWith(bannerTopList: bannerTopList,bannerBottomList:bannerBottomList));
      });*/

    });

    on<searchRestro>((event, emit) async {
      emit(state.copyWith(isLoading: true));
      final res = await searchUsecase.call(event.q);
      res.fold((l) {
        emit(state.copyWith(searchList: [],isLoading: false));
      }, (r) {
        emit(state.copyWith(searchList: r,isLoading: false));
      });
    });
  }
}
