part of 'home_bloc.dart';

@freezed
class HomeState with _$HomeState {
  factory HomeState({
    required RestaurantDetailsEntity? restaurantDetailsEntity,
    required bool isLoading,
    required CountryResponse? countryResponse,
    required HomeResponse? homeResponse,
    required List<Banners>? bannerList,
    required List<Banners>? bannerTopList,
    required List<Banners>? bannerBottomList,
    required List<Restrolist>? searchList,
  }) = _HomeState;
  factory HomeState.initial() => HomeState(
      restaurantDetailsEntity: null,
      isLoading: false,
    countryResponse:null,
    homeResponse:null,
    bannerList:[],
    bannerTopList:[],
    bannerBottomList:[],
    searchList:[],
  );
}
