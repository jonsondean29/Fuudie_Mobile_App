import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:fuud/features/widgets/loading_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
// import 'package:open_file_plus/open_file_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../generated/assets.dart';
import '../../../map/presentation/bloc/map_bloc.dart';
import '../../data/repositories/utils_repo.dart';
import '../../domain/entities/restaurant_details_entity.dart';

@RoutePage()
class ResturantDetailsPage extends StatefulWidget {
  const ResturantDetailsPage({super.key});
  static const routeName = '/restuarantDetails';

  @override
  State<ResturantDetailsPage> createState() => _ResturantDetailsPageState();
}

class _ResturantDetailsPageState extends State<ResturantDetailsPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  bool isLoading=false;
  int currentIndex = 0;
  RestaurantDetailsEntity? data;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      persistentFooterButtons: [
        Container(
          child: Row(
            children: [
              Expanded(flex: 1,
                child: TextButton(onPressed: () {
                  viewDocument(data!.menufilesrc!);
              },
                child:isLoading?const Row(
                  children: [
                    SizedBox(height: 15,width: 15,
                      child: CircularProgressIndicator(strokeWidth: 2,),),
                    SizedBox(width: 5,),
                    Text("Loading...",style: TextStyle(
                      fontSize: 10
                    ),)
                  ],
                ): const Text("Menu",style: TextStyle(
                fontSize: 16,
                color: Colors.black
              ),),),),
              const SizedBox(
                height: 20,
                child: VerticalDivider(),
              ),
              Expanded(flex: 1,
                child: TextButton(onPressed: () {
                  _launchURL('${data!.booking_url}?userId=${auth.value!.id}&is_reg=true');
                },
                  child: const Text("Book",style: TextStyle(
                      fontSize: 16,
                      color: Colors.black
                  ),),),),
              const SizedBox(
                height: 20,
                child: VerticalDivider(),
              ),
              Expanded(flex: 1,
                child: TextButton(onPressed: () {
                  if(data!=null) {
                    // MapsLauncher.launchCoordinates(double.parse(data!.lat??"0"), double.parse(data!.lng??"0"));
                  }
                },
                  child: const Text("Direction",style: TextStyle(
                      fontSize: 16,
                      color: Colors.black
                  ),),),)
            ],
          ),
        )
      ],
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true),
      endDrawer: const AppDrawer(),
      body: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          if (state.isLoading) {
            return LoadingWidget(type: LoadingType.BANNER,);
          }
          data=state.restaurantDetailsEntity;
          return state.restaurantDetailsEntity != null
              ? Column(
                  children: [
                    Container(
                      height: 50,
                      color: Colors.black,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                           BackButton(
                            color: Colors.white,
                            onPressed: () {
                              context.back();
                            },
                          ),
                          state.restaurantDetailsEntity != null
                              ? Text(
                                  state.restaurantDetailsEntity!.name ?? '',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18),
                                )
                              : const Text(''),
                          GestureDetector(
                            onTap: () {
                              Share.share('${data!.name} ${data!.booking_url}');
                            },
                            child: const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: ImageIcon(
                                AssetImage('assets/images/icon-ma.png'),
                                color: Colors.white,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        children: [
                          Column(
                            children: [
                              state.restaurantDetailsEntity == null
                                  ? Container()
                                  : Column(
                                      children: [
                                        CarouselSlider(
                                          options: CarouselOptions(
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.4,
                                            autoPlay: true,
                                            onPageChanged: (index, reason) {
                                              setState(() {
                                                currentIndex = index;
                                              });
                                            },
                                            enlargeCenterPage: true,
                                            viewportFraction: 1,
                                          ),
                                          items: state.restaurantDetailsEntity
                                              ?.restrimglist
                                              ?.map((i) {
                                            return Builder(
                                              builder: (BuildContext context) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0),
                                                    color: AppColors.black,
                                                  ),
                                                  height: 60,
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        const BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    0)),
                                                    child: NetworkImageWidget(url: '${Apis.baseUrl}/${i.imgfile}',
                                                        fit: BoxFit.cover,),
                                                  ),
                                                );
                                              },
                                            );
                                          }).toList(),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: state
                                              .restaurantDetailsEntity!
                                              .restrimglist!
                                              .asMap()
                                              .entries
                                              .map(
                                            (entry) {
                                              final int index = entry.key;
                                              return currentIndex == index
                                                  ? Container(
                                                      width: 8.0,
                                                      height: 8.0,
                                                      margin: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 10.0,
                                                          horizontal: 2.0),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: currentIndex ==
                                                                index
                                                            ? Colors.blue
                                                            : Colors.grey,
                                                      ),
                                                    )
                                                  : Container(
                                                      width: 5.0,
                                                      height: 5.0,
                                                      margin: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 10.0,
                                                          horizontal: 2.0),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: currentIndex ==
                                                                index
                                                            ? AppColors.black
                                                            : Colors.grey,
                                                      ),
                                                    );
                                            },
                                          ).toList(),
                                        ),
                                      ],
                                    ),

                              Container(
                                padding: const EdgeInsets.all(10),
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                     Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Column(
                                              children: [
                                                IconButton(onPressed: () {
                                                  setState(() {
                                                    state.restaurantDetailsEntity!.iswishlist=state.restaurantDetailsEntity!.iswishlist==1?0:1;
                                                    int a=state.restaurantDetailsEntity!.iswishlist==0?state.restaurantDetailsEntity!.totfav!-1:state.restaurantDetailsEntity!.totfav!+1;
                                                  if(a>=0){
                                                    state.restaurantDetailsEntity!.totfav=a;
                                                  }
                                                  });
                                                  context
                                                      .read<MapBloc>()
                                                      .add(MapEvent.addToWish(resId: state.restaurantDetailsEntity!.id!));
                                                }, icon: state.restaurantDetailsEntity!.iswishlist==1?Image.asset(Assets.imagesWishSelected,width: 25,):
                                                Image.asset(Assets.imagesWish,width: 25,)),
                                                const Text('Favourite')
                                              ],
                                            ),
                                            const Gap(20),
                                            Column(
                                              children: [
                                                IconButton(onPressed: () {
                                                  setState(() {
                                                    state.restaurantDetailsEntity!.isbeenlist=state.restaurantDetailsEntity!.isbeenlist==1?0:1;
                                                    int b=state.restaurantDetailsEntity!.isbeenlist==0?state.restaurantDetailsEntity!.totbeen!-1:state.restaurantDetailsEntity!.totbeen!+1;
                                                  if(b>=0){
                                                    state.restaurantDetailsEntity!.totbeen=b;
                                                  }
                                                  });
                                                  context
                                                      .read<MapBloc>()
                                                      .add(MapEvent.addToTested(resId: state.restaurantDetailsEntity!.id!));
                                                }, icon: state.restaurantDetailsEntity!.isbeenlist==1?Image.asset(Assets.imagesBeenSelected,width: 25,):
                                                Image.asset(Assets.imagesBeen,width: 25,)),
                                                const Text('Tested')
                                              ],
                                            ),
                                            const Gap(20),
                                            Column(
                                              children: [
                                                IconButton(onPressed: () {
                                                  setState(() {
                                                    state.restaurantDetailsEntity!.istrylist=state.restaurantDetailsEntity!.istrylist==1?0:1;
                                                    int c=state.restaurantDetailsEntity!.istrylist==0?state.restaurantDetailsEntity!.tottry!-1:state.restaurantDetailsEntity!.tottry!+1;
                                                    if(c>=0){
                                                      state.restaurantDetailsEntity!.tottry=c;
                                                    }
                                                  });
                                                  context
                                                      .read<MapBloc>()
                                                      .add(MapEvent.addToTry(resId: state.restaurantDetailsEntity!.id!));
                                                }, icon: state.restaurantDetailsEntity!.istrylist==1? Image.asset(Assets.imagesFlagTrySelected,width: 20,):
                                                Image.asset(Assets.imagesFlagTry,width: 20,)),
                                                const Text('Go Try')
                                              ],
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                    const Gap(10),
                                    state.restaurantDetailsEntity != null
                                        ? Row(
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.totfav} '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: ' Favourite, ')
                                                  ],
                                                ),
                                              ),
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.totbeen}  '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: ' Tested, ')
                                                  ],
                                                ),
                                              ),
                                              RichText(
                                                text: TextSpan(
                                                  style: const TextStyle(
                                                      color: Colors.black),
                                                  children: [
                                                    TextSpan(
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                        text:
                                                            '${state.restaurantDetailsEntity!.tottry} '),
                                                    const TextSpan(
                                                        style: TextStyle(
                                                            color:
                                                                Colors.black54),
                                                        text: 'Go Try')
                                                  ],
                                                ),
                                              ),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Gap(10),
                                    state.restaurantDetailsEntity != null
                                        ? Text(state.restaurantDetailsEntity!
                                                .description ??
                                            "")
                                        : const SizedBox(),
                                    const Divider(),
                                    const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Tags :',
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                    const Gap(5),
                                    state.restaurantDetailsEntity!.tags != null
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: Wrap(
                                                    alignment:
                                                        WrapAlignment.start,
                                                    spacing: 5,
                                                    direction: Axis.horizontal,
                                                    children: List.generate(
                                                      state
                                                          .restaurantDetailsEntity!
                                                          .tags!
                                                          .split(',')
                                                          .length,
                                                      (index) => tagWidget(state
                                                          .restaurantDetailsEntity!
                                                          .tags!
                                                          .split(',')[index]),
                                                    )),
                                              ),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Divider(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            const Gap(10),
                                            Text(
                                              "${state.restaurantDetailsEntity!.rating ?? 0}",
                                              style: const TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Gap(20),
                                            const Text(
                                                "Review aren't verified"),
                                          ],
                                        ),
                                        IconButton(
                                            onPressed: () async {
                                              _launchURL(state
                                                  .restaurantDetailsEntity!
                                                  .rating_link ??
                                                  '');
                                              },
                                            icon:
                                                const Icon(Icons.info_outline))
                                      ],
                                    ),
                                    RatingBarIndicator(itemBuilder: (context, index) {
                                      return const Icon(Icons.star,color: Colors.amber,);
                                    },itemSize: 35,itemCount: 5,rating: state
                                        .restaurantDetailsEntity!
                                        .rating ??
                                        0,),
                                    // Image.asset('assets/images/details.png'),
                                    // const Gap(10),
                                    //  Text("${state.restaurantDetailsEntity!.description}"),
                                    const Gap(10),
                                    const Divider(),
                                    const Gap(10),
                                    Text(
                                        "Address: \n ${state.restaurantDetailsEntity!.location ?? ''}, ${state.restaurantDetailsEntity!.city ?? ''}, ${state.restaurantDetailsEntity!.state ?? ''}"),
                                    state.restaurantDetailsEntity!.phone != null
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(state
                                                      .restaurantDetailsEntity!
                                                      .phone ??
                                                  ''),
                                            ],
                                          )
                                        : const SizedBox(),
                                    const Gap(5),
                                    if(state
                                        .restaurantDetailsEntity!
                                        .instalink!=null&&state
                                        .restaurantDetailsEntity!
                                        .instalink!="N/A"&&state
                                        .restaurantDetailsEntity!
                                        .instalink!="")...{
                                      GestureDetector(
                                        onTap: () {
                                          _launchURL(state
                                              .restaurantDetailsEntity!
                                              .instalink ??
                                              '');
                                        },
                                        child: const Text(
                                          'Check it out on instagram',
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            decorationColor: Colors.blue,
                                            decoration:
                                            TextDecoration.underline,
                                            color: Colors.blue,
                                          ),
                                        ),
                                      ),
                                      const Gap(5),
                                    },
                                    if(state
                                        .restaurantDetailsEntity!
                                        .fblink!=null&&state
                                        .restaurantDetailsEntity!
                                        .fblink!="N/A"&&state
                                        .restaurantDetailsEntity!
                                        .fblink!="")
                                      GestureDetector(
                                        onTap: () {
                                          _launchURL(state
                                              .restaurantDetailsEntity!
                                              .fblink ??
                                              '');
                                        },
                                        child: const Text(
                                          'Check it out on Facebook',
                                          style: TextStyle(
                                            decorationColor: Colors.blue,
                                            decoration:
                                            TextDecoration.underline,
                                            color: Colors.blue,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : const SizedBox();
        },
      ),
    );
  }
  Future<void> viewDocument(String url) async {
    setState(() {
      isLoading=true;
    });
    String name=url.split('/').last;
    String path = '${Apis.baseUrl}/$url';
    download(path, name).then((value) {
      setState(() {
        isLoading=false;
      });
      // OpenFile.open(value);
    });
  }

}

Widget tagWidget(String name) {
  return Padding(
    padding: const EdgeInsets.all(4.0),
    child: Container(
      decoration: BoxDecoration(
        border: Border.all(width: 1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Padding(
        padding: const EdgeInsets.only(top: 5, bottom: 5, left: 10, right: 10),
        child: Text(name),
      ),
    ),
  );
}
void _launchURL(String url) async {
  if (await canLaunchUrl(Uri.parse(url))) {
    await launchUrl(Uri.parse(url));
  } else {
    throw 'Could not launch $url';
  }
}
