import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../../../core/constants/urls.dart';

class NetworkImageWidget extends StatelessWidget {
String url;
double? width;
double? height;
BoxFit fit;
NetworkImageWidget({required this.url,this.width,this.height,this.fit=BoxFit.fill});

  @override
  Widget build(BuildContext context) {
    double wid=width??MediaQuery.of(context).size.width;
    return Stack(
      children: [
        SizedBox(height: height,),
        if(url.isEmpty)...{
          Image.asset(
            'assets/images/no-image.png',
            width: wid,
            fit: BoxFit.cover,
            height: height,
          )
        }else
        Center(
          child: CachedNetworkImage(
            imageUrl: url,
            placeholder: (context, url) => LottieBuilder.asset('assets/json/image_loading.json',
              width: wid,
              fit: BoxFit.contain,
              height: height,),
            errorWidget: (context, url, error) => Image.asset(
              'assets/images/no-image.png',
              width: wid,
              fit: BoxFit.cover,
              height: height,
            ),
            fit: fit,
            height: height,
            width: wid,
          ),
        ),
      ],
    );
  }
}
