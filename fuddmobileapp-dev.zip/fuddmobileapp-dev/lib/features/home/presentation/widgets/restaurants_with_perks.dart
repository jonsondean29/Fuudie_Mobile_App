import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import 'package:fuud/features/home/domain/entities/perks_resturent_list_entity.dart';

class RestaurantsWithPerks extends StatelessWidget {
  const RestaurantsWithPerks(
      {super.key, required this.perksResturentEntityList});
  final List<PerksResturentEntity> perksResturentEntityList;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(padding: EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Authentic Food',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('See More',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))
          ],
        ),),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: perksResturentEntityList.length,
              itemBuilder: (context, index) {
                print('resturent len ${perksResturentEntityList.length}');
                return RestaurantsCard(
                  resturentId: perksResturentEntityList[index].id ?? 0,
                  isPerksResturent: true,
                  name: perksResturentEntityList[index].name ?? "",
                  image: perksResturentEntityList[index].mainimg != null
                      ? "${Apis.baseUrl}/${perksResturentEntityList[index].mainimg}"
                      : "assets/images/images_11.jpeg",
                );
              }),
        ),
      ],
    );
  }
}
