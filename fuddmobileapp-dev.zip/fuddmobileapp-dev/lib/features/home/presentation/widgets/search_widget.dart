import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:fuud/config/routes/app_router.dart';

class SerachWidget extends StatelessWidget {
  final searchController = TextEditingController();

  SerachWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(50)),
      child: InkWell(
        onTap: (){
          context.router.push(SearchRoute());
        },
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: searchController,
                enabled: false,
                decoration: const InputDecoration(
                    border: InputBorder.none,
                    prefixIcon: ImageIcon(
                      AssetImage(
                        'assets/images/b-1.png',
                      ),
                      color: Colors.black,
                    ),
                    contentPadding: EdgeInsets.only(left: 30)),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                margin: const EdgeInsets.only(right: 5),
                width: 80,
                height: 30,
                decoration: BoxDecoration(
                    color: Colors.black, borderRadius: BorderRadius.circular(10)),
                child: const Center(
                  child: Text(
                    'Search',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
