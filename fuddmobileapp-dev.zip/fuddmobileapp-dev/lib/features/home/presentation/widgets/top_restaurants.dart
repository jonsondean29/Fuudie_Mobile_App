import 'package:flutter/material.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';

class TopRestaurants extends StatelessWidget {
  TopRestaurants({super.key});
  final List imageList = [
    'assets/images/images_1.jpeg',
    'assets/images/images_2.jpeg',
    'assets/images/images_3.jpeg',
    'assets/images/images_4.jpeg',
    'assets/images/images_5.jpeg',
    'assets/images/images_6.jpeg',
    'assets/images/images_7.jpeg',
    'assets/images/images_8.jpeg',
    'assets/images/images_9.jpeg',
    'assets/images/images_10.jpeg'
  ];
  final List<String> londonRestaurantsList3 = [
    "Ethereal Eats",
    "The Culinary Caravan",
    "Sizzle Street",
    "Divine Dining",
    "Bountiful Bites",
    "The Epicurean Emporium",
    "Flavorful Fête",
    "Aroma Avenue",
    "Tender Touch Cuisine",
    "Gastronomy Grove",
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Top 10 in Landon'),
            TextButton(
                onPressed: () {},
                child: const Text(
                  'See More',
                  style: TextStyle(color: Colors.black),
                ))
          ],
        ),
        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: 10,
              itemBuilder: (context, index) {
                // final randomNumber = Random().nextInt(3);
                return GestureDetector(
                  onTap: () async {
                    // final id = await getIntValue('id');
                    // print('user id $id');
                    // context.read<HomeBloc>().add(const HomeFeatchDetails());
                    // context.router.push(ResturantDetailsRoute());
                  },
                  child: RestaurantsCard(
                    resturentId: 0,
                    isPerksResturent: false,
                    // isNetworkImage: false,
                    name: londonRestaurantsList3[index],
                    image: imageList[index],
                  ),
                );
              }),
        ),
      ],
    );
  }
}
