import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:gap/gap.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';

class RestaurantsCard extends StatelessWidget {
  const RestaurantsCard({
    Key? key,
    required this.image,
    required this.name,
    required this.isPerksResturent,
    required this.resturentId,
  }) : super(key: key);
  final String image;
  final String name;
  final int resturentId;

  final bool isPerksResturent;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 180,
      child: GestureDetector(
        onTap: () async {
          final userid = await getIntValue('id') ?? 0;
          if (context.mounted) {
            context
                .read<HomeBloc>()
                .add(HomeFeatchDetails(id: userid, resturentId: resturentId));
            context.router.push(ResturantDetailsRoute());
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Stack(
                children: [
                  Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child:NetworkImageWidget(url: image,
                        fit: BoxFit.cover,
                        height: 135,
                        width: 155,),
                    ),
                  ),
                  isPerksResturent
                      ? Positioned(
                    right: 0,
                    child: SizedBox(
                        height: 30,
                        child: Image.asset(
                          'assets/images/diamond.png',
                          color: Colors.white,
                        )),
                  )
                      : const SizedBox()
                ],
              ),
              const Gap(5),
              Text(
                name,
                softWrap: true,
                maxLines: 2,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    overflow: TextOverflow.ellipsis,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              )
            ],
          ),
        ),
      ),
    );
  }
}
