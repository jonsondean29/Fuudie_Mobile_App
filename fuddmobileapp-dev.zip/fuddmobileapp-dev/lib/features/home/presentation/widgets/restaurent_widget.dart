import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import '../../data/models/home_response.dart';

class RestaurentWidget extends StatelessWidget {
   RestaurentWidget(
      {super.key, required this.data});
   List<Restrolist> data;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 196,
      child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemCount: data.length>10?10:data.length,
          itemBuilder: (context, index) {
            return RestaurantsCard(
              resturentId: data[index].id ?? 0,
              isPerksResturent:
              data[index].isperks == 1,
              name: data[index].name ?? "",
              image: data[index].mainimg != null
                  ? "${Apis.baseUrl}/${data[index].mainimg}"
                  : "assets/images/images_11.jpeg",
            );
          }),
    );
  }
}
