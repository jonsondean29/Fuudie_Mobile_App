import 'package:flutter/material.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/features/home/presentation/widgets/restaurants_card.dart';
import 'package:fuud/features/home/domain/entities/current_year_resturent_list_entity.dart';

class CurrentYearResturent extends StatelessWidget {
  const CurrentYearResturent(
      {super.key, required this.currentYearResturantListEntity});
  final List<CurryearrestrolistEntity> currentYearResturantListEntity;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(padding: EdgeInsets.symmetric(horizontal: 8),child:Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Opened in 2024',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('See More',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))
          ],
        ),),

        SizedBox(
          height: 196,
          child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: currentYearResturantListEntity.length,
              itemBuilder: (context, index) {
                print('resturent len ${currentYearResturantListEntity.length}');
                return RestaurantsCard(
                  isPerksResturent:
                      currentYearResturantListEntity[index].isperks == 1,
                  // isNetworkImage: true,
                  name: currentYearResturantListEntity[index].name ?? "",
                  image: currentYearResturantListEntity[index].mainimg != null
                      ? "${Apis.baseUrl}/${currentYearResturantListEntity[index].mainimg}"
                      : "assets/images/images_11.jpeg",
                  resturentId: currentYearResturantListEntity[index].id ?? 0,
                );
              }),
        ),
      ],
    );
  }
}
