import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import '../../data/models/banners.dart';

class BannerSlider extends StatefulWidget {
  final List<Banners> bannerAdsList;
  double? height;
  bool? showTitle;
   BannerSlider({
    Key? key,
    required this.bannerAdsList,
     this.height,
     this.showTitle=false,
  }) : super(key: key);

  @override
  BannerSliderState createState() => BannerSliderState();
}

class BannerSliderState extends State<BannerSlider> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    if(widget.bannerAdsList.length==1){
      return GestureDetector(
        onTap: () async {
          final userid = await getIntValue('id') ?? 0;
          if (context.mounted) {
            context.read<HomeBloc>().add(
                HomeFeatchDetails(id: userid, resturentId: widget.bannerAdsList.first.id ?? 0));
            context.router.push(const ResturantDetailsRoute());
          }
        },
        child: Container(
          height: widget.height??250.0,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Stack(
            children: [
              Container(
                padding: const EdgeInsets.only(bottom: 25),
                child: NetworkImageWidget(url:'${Apis.baseUrl}/${widget.bannerAdsList.first.mainimg}'),
              ),
              Container(
                color: Colors.black.withOpacity(0.6),
                child: const Padding(
                  padding: EdgeInsets.all(2.0),
                  child: Text(
                    'Ad  ',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              // if(widget.showTitle!)
              Positioned(bottom: 2,left: 10,right:10,
                child: Text('${widget.bannerAdsList.first.name}',
                  style: const TextStyle(
                      overflow: TextOverflow.ellipsis,
                      fontSize: 14,
                      fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                ),)
            ],
          ),
        ),
      );
    }
    return Column(
      children: [
        CarouselSlider(
          options: CarouselOptions(
            height: widget.height??250.0,
            autoPlay: true,
            onPageChanged: (index, reason) {
              setState(() {
                _currentIndex = index;
              });
            },
            enlargeCenterPage: true,
            viewportFraction: 0.8,
          ),
          items: widget.bannerAdsList.map(
                (i) {
              return GestureDetector(
                onTap: () async {
                  final userid = await getIntValue('id') ?? 0;
                  if (context.mounted) {
                    context.read<HomeBloc>().add(
                        HomeFeatchDetails(id: userid, resturentId: i.id ?? 0));
                    context.router.push(const ResturantDetailsRoute());
                  }
                },
                child: Stack(
                  children: [
                    Container(
                      padding: const EdgeInsets.only(bottom: 25),
                      child: NetworkImageWidget(url:'${Apis.baseUrl}/${i.mainimg}'),
                    ),
                    Container(
                      color: Colors.black.withOpacity(0.6),
                      child: const Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Text(
                          'Ad  ',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    // if(widget.showTitle!)
                      Positioned(bottom: 2,left: 10,right:10,
                        child: Text('${i.name}',
                          style: const TextStyle(
                              overflow: TextOverflow.ellipsis,
                              fontSize: 14,
                              fontWeight: FontWeight.w600),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                        ),)
                  ],
                ),
              );
            },
          ).toList(),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: widget.bannerAdsList.asMap().entries.map(
                (entry) {
              final int index = entry.key;
              return _currentIndex == index
                  ? Container(
                width: 8.0,
                height: 8.0,
                margin: const EdgeInsets.symmetric(
                    vertical: 10.0, horizontal: 2.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _currentIndex == index
                      ? AppColors.black
                      : Colors.grey,
                ),
              )
                  : Container(
                width: 5.0,
                height: 5.0,
                margin: const EdgeInsets.symmetric(
                    vertical: 10.0, horizontal: 2.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _currentIndex == index
                      ? AppColors.black
                      : Colors.grey,
                ),
              );
            },
          ).toList(),
        ),
      ],
    );
  }
}
