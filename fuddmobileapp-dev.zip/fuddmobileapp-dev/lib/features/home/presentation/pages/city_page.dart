import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import '../../../../core/constants/urls.dart';
import '../../../map/presentation/bloc/map_bloc.dart';
import '../../../widgets/loading_widget.dart';

@RoutePage()
class CityPage extends StatefulWidget {
  CityPage({super.key});
  static const routeName = 'city';
  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<CityPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  CountryResponse? response;
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(const Duration(milliseconds: 500),() async {
      final userid = await getIntValue('id') ?? 0;
      if(countryResponse.value==null) {
        context.read<HomeBloc>().add(HomeEvent.fetchCountry(id:userid));
      }else{
        setState(() {
          response=countryResponse.value;
        });
      }
    },);
    context.read<HomeBloc>().stream.listen((state) {
      if(state.countryResponse!=null&&mounted) {
        setState(() {
          response=state.countryResponse;
        });
      }
    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      appBar: PreferredSize(
        preferredSize:  const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Stack(
            children: [
              Image.asset(
                'assets/images/top-bg.png',
                height: 80,
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      IconButton(onPressed: () {
                        context.popRoute();
                      }, icon: const Icon(Icons.arrow_back,size: 35,)),
                      const Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Text(
                          'Change City',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Image.asset(
                        'assets/images/logo3.png',
                        fit: BoxFit.cover,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: body(),
    );
  }
  Widget countryTile(Countries data,context){
    return Card(
      color: Colors.white,
      child: Container(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: Text("${data.countryName}",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold
                ),)),
                const SizedBox(width: 10,),
                NetworkImageWidget(url: '${Apis.baseUrl}/${data.flagimg}',height: 25,width: 40,),
              ],
            ),
            const SizedBox(height: 10,),
            ListView.builder(itemBuilder: (context, index) {
              return cityTile(data.cities![index],(city) async {
                await setDefaultCountry({
                  "selectedcountry":data.shortName,
                  "selectedcity":city.name,
                  "selectedcountryflag":data.flagimg,
                });
                context.read<MapBloc>().add(const MapEvent.userMove());
                final userid = await getIntValue('id') ?? 0;
                context.read<HomeBloc>().add(HomeEvent.setCity(sortName:data.shortName!,cityName:city.name!,id:userid));
                context.popRoute();
                },);
            },primary: false,shrinkWrap: true,itemCount: data.cities!.length,)
          ],
        ),
      ),
    );
  }
  Widget cityTile(City data,Function(City data)onTap){
    return Card(
      color: Colors.white,
      child: InkWell(
        child: Container(
          padding: const EdgeInsets.all(10),
          child: Text("${data.name}"),
        ),
        onTap: ()  {
          onTap.call(data);
        },
      ),
    );
  }
  Widget body(){
    if(response==null){
      return LoadingWidget(type: LoadingType.LIST,);
    }
    return ListView.builder(itemBuilder: (context, index) {
      return countryTile(response!.countries![index],context);
    },shrinkWrap: true,itemCount: response!.countries!.length,);
  }
}
