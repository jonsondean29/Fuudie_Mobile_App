import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import 'package:rxdart/rxdart.dart';
import '../../../../config/routes/app_router.dart';
import '../../../../core/constants/urls.dart';
import '../../../explore/presentation/widgets/search_widget.dart';
import '../../data/models/home_response.dart';

@RoutePage()
class SearchPage extends StatefulWidget {
  SearchPage({super.key});
  static const routeName = 'search';
  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<SearchPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  List<Restrolist> list=[];
  final searchOnChange =  BehaviorSubject<String>();
  var searchCon=TextEditingController();
  bool isLoading=false;
  @override
  void initState() {
    // TODO: implement initState
    context.read<HomeBloc>().stream.listen((state) {
      if(isLoading!=state.isLoading){
        setState(() {
          isLoading=state.isLoading;
        });
      }
      if(state.searchList!=null&&mounted) {
        setState(() {
          list=state.searchList!;
        });
      }
    },);
    initSearch();
    super.initState();
  }
  void initSearch(){
    searchOnChange.debounceTime(const Duration(milliseconds: 300))
        .listen((queryString) async {
      context.read<HomeBloc>().add(HomeEvent.search(q: queryString));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      appBar: PreferredSize(
        preferredSize:  const Size.fromHeight(155),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Image.asset(
                    'assets/images/top-bg.png',
                    height: 80,
                  ),
                  Container(
                    alignment: Alignment.bottomLeft,
                    padding: const EdgeInsets.only(left: 8,right: 8,top: 35,bottom: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        IconButton(onPressed: () {
                          context.back();
                        }, icon: const Icon(Icons.arrow_back,size: 35,)),
                        const Padding(
                          padding: EdgeInsets.only(bottom: 10),
                          child: Text(
                            'Search',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Image.asset(
                          'assets/images/logo3.png',
                          fit: BoxFit.cover,
                          height: 50,
                        ),
                      ],
                    )
                  ),
                ],
              ),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SearchWidget(
                hintText: 'search for a place, area',
                searchController: searchCon,
                isLoading: isLoading,
                onChanged: (s) {
                  searchOnChange.add(s);
                },
              ),),
              if(searchCon.text.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                child: Text('Breakfast to "Result for ${searchCon.text}"',
                style: const TextStyle(
                  fontWeight: FontWeight.bold
                ),),
              )
            ],
          ),
        ),
      ),
      body: body(),
    );
  }
  Widget _card(Restrolist data){
    return Card(
      color: Colors.white,
      child: InkWell(
        onTap: () async {
          final userid = await getIntValue('id') ?? 0;
          if (context.mounted) {
            context
                .read<HomeBloc>()
                .add(HomeFeatchDetails(id: userid, resturentId: data.id!));
            context.router.push(const ResturantDetailsRoute());
          }
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: NetworkImageWidget(url: "${Apis.baseUrl}/${data.mainimg}",
                  height: 100,
                  width: 100,),
              ),
              const SizedBox(width: 10,),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${data.name}',
                    softWrap: true,
                    maxLines: 2,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    '${data.location}',
                    softWrap: true,
                    maxLines: 2,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        color: Colors.grey,
                        fontSize: 12),
                  ),
                  RatingBarIndicator(itemBuilder: (context, index) {
                    return const Icon(Icons.star);
                  },itemCount: 5,itemSize: 18,
                    rating:data.rating??0,),
                  Text(
                    data.description??"",
                    softWrap: true,
                    maxLines: 1,
                    style: const TextStyle(
                        overflow: TextOverflow.ellipsis,
                        color: Colors.grey,
                        fontSize: 12),
                  ),

                ],
              ))
            ],
          ),
        ),
      ),
    );
  }
  Widget body(){
    if(list.isEmpty){
      return const Center(
        child: Text("No result found"),
      );
    }
    return ListView.builder(itemBuilder: (context, index) {
      return _card(list[index]);
    },shrinkWrap: true,itemCount:list.length,);
  }
}
