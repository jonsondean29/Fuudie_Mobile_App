import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/core/widgets/appdrawer.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/search_widget.dart';
import '../../../widgets/loading_widget.dart';
import '../../data/models/home_response.dart';
import '../widgets/banner_widget.dart';
import '../widgets/restaurent_widget.dart';

@RoutePage()
class HomePage extends StatefulWidget {
  HomePage({super.key});
  static const routeName = 'home';
  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  HomeResponse? homeResponse;

  @override
  void initState() {
    // TODO: implement initState
    getSession();
    Future.delayed(const Duration(milliseconds: 500),() {
      getDefaultCountry().then((value) async {
        if(value.isEmpty){
          final userid = await getIntValue('id') ?? 0;
          context.read<HomeBloc>().add(HomeEvent.fetchCountry(id: userid));
        }else{
          context.read<HomeBloc>().add(const HomeEvent.featch());
        }
      },);
    },);
    context.read<HomeBloc>().stream.listen((state) {
      if(state.homeResponse!=null&&mounted) {
        setState(() {
          homeResponse=state.homeResponse;
        });
      }
    },);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      appBar: customAppBar(
          title: '', scaffoldKey: _scaffoldKey, locationImage: true,
        changeCity: () {
          context.router.push(CityRoute()).then((value) {
            setState(() {});
          },);
        },
      ),
      endDrawer: const AppDrawer(),
      body: Column(
        children: [
          Container(
              padding: const EdgeInsets.only(left: 8, right: 8, top: 10,bottom: 10),
              color: Colors.black,
              child: SerachWidget()),
          Expanded(
            child: _body(),
          )
        ],
      ),
    );
  }
  Widget tile(Restaurantlist data){
    if(data.restrolist!.isEmpty&&data.bannerlist!.isEmpty){
      return const SizedBox();
    }
    print("title==>${data.title}");
    if(data.title=="Banner Ads"){
      return BannerSlider(bannerAdsList: data.bannerlist!,);
    }if(data.title=="Ads"){
      return BannerSlider(bannerAdsList: data.bannerlist!,height: 180,showTitle: true,);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
          margin: const EdgeInsets.only(top: 10),
          color: Colors.white,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${data.title}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
               InkWell(
                onTap: (){
                  context.router.push(RestaurentListRoute(data: data));
                },
                child: const Text('See More',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.bold)),
              )
            ],
          ),),
        RestaurentWidget(data:data.restrolist!),

      ],
    );
  }
  Widget _body(){
    if(homeResponse==null){
      return LoadingWidget(type: LoadingType.DASHBOARD,);
    }
    return ListView.builder(itemBuilder: (context, index) {
      return tile(homeResponse!.restaurantlist![index]);
    },shrinkWrap: true,itemCount: homeResponse!.restaurantlist!.length,
      primary: true,padding: const EdgeInsets.only(top: 10),);
  }
}
