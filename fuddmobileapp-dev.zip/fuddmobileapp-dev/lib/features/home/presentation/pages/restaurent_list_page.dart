import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fuud/core/constants/constants.dart';
import 'package:fuud/core/constants/storege.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/presentation/bloc/home_bloc.dart';
import 'package:fuud/features/home/presentation/widgets/network_image_widget.dart';
import '../../../../config/routes/app_router.dart';
import '../../../../core/constants/urls.dart';
import '../../../map/presentation/bloc/map_bloc.dart';
import '../../../widgets/loading_widget.dart';
import '../../data/models/home_response.dart';

@RoutePage()
class RestaurentListPage extends StatefulWidget {
  RestaurentListPage({super.key,required this.data});
  static const routeName = 'restaurant_list';
  final Restaurantlist data;
  @override
  _PageState createState() => _PageState();
}

class _PageState extends State<RestaurentListPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      appBar: PreferredSize(
        preferredSize:  const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Stack(
            children: [
              Image.asset(
                'assets/images/top-bg.png',
                height: 80,
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      IconButton(onPressed: () {
                        context.popRoute();
                      }, icon: const Icon(Icons.arrow_back,size: 35,)),
                       Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Text(
                          '${widget.data.title}',
                          style: const TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Image.asset(
                        'assets/images/logo3.png',
                        fit: BoxFit.cover,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: body(),
    );
  }
  Widget _card(Restrolist data){
    return Card(
      color: Colors.white,
      child: InkWell(
        onTap: () async {
          final userid = await getIntValue('id') ?? 0;
          if (context.mounted) {
            context
                .read<HomeBloc>()
                .add(HomeFeatchDetails(id: userid, resturentId: data!.id!));
            context.router.push(const ResturantDetailsRoute());
          }
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: NetworkImageWidget(url: "${Apis.baseUrl}/${data!.mainimg}",
                  height: 100,
                  width: 100,),
              ),
              const SizedBox(width: 10,),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${data.name}',
                    softWrap: true,
                    maxLines: 2,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    '${data.location}',
                    softWrap: true,
                    maxLines: 2,
                    style: const TextStyle(
                        overflow: TextOverflow.clip,
                        color: Colors.grey,
                        fontSize: 12),
                  ),
                  RatingBarIndicator(itemBuilder: (context, index) {
                    return const Icon(Icons.star);
                  },itemCount: 5,itemSize: 18,
                  rating:data.rating??0,),
                  Text(
                    data.description??"",
                    softWrap: true,
                    maxLines: 1,
                    style: const TextStyle(
                        overflow: TextOverflow.ellipsis,
                        color: Colors.grey,
                        fontSize: 12),
                  ),

                ],
              ))
            ],
          ),
        ),
      ),
    );
  }
  Widget body(){
    if(widget.data.restrolist==null){
      return const Text("No Record Found");
    }
    return ListView.builder(itemBuilder: (context, index) {
      return _card(widget.data.restrolist![index]);
    },shrinkWrap: true,itemCount: widget.data.restrolist!.length,);
  }
}
