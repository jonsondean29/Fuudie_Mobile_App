import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/exclusive_resturent_usecase.dart';
import 'package:fuud/features/home/domain/entities/exclusive_resturent_list_entity.dart';

abstract class ExclusiveRestaurantRepository {
  Future<Either<Failure, List<ExclusiveResturantListEntity>>> getExclusiveRestaurant(ExclusiveRestaurantParams params);
}
