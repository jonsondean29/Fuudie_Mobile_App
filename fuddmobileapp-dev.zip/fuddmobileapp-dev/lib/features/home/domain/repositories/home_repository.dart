import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import '../../data/models/home_response.dart';
import '../usecases/home_usecase.dart';

abstract class HomeRepository {
  Future<Either<Failure, HomeResponse>> getHome(HomeParams params);
  Future<Either<Failure, List<Restrolist>>> search(String q);
}
