import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/entities/restaurant_details_entity.dart';
import 'package:fuud/features/home/domain/usecases/resturant_details_usecase.dart';

abstract class RestaurantDetailsRepository {
  Future<Either<Failure, RestaurantDetailsEntity>> getRestaurantdetails(
      RestaurantDetailsParams params);
}
