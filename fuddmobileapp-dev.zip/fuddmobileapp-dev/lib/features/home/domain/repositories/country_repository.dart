import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/domain/usecases/country_usecase.dart';

import '../usecases/update_ctiy_usecase.dart';

abstract class CountryRepository {
  Future<Either<Failure, CountryResponse>> getCountry(CountryParams params);
  Future<Either<Failure, String>> setCity(CityParams params);
}
