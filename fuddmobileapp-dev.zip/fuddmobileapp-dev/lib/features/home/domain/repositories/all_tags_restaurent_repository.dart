import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/all_tag_restaurent_usecase.dart';
import 'package:fuud/features/home/domain/entities/all_tags_resturent_list_entity.dart';

abstract class AllTagsRestaurantRepository {
  Future<Either<Failure, List<AllTagsrestrolistEntity>>> getAllTagsRestaurant(
      AllTagsRestaurantParams params);
}
