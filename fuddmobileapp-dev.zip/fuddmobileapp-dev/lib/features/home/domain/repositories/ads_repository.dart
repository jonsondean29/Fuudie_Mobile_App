import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/home/domain/usecases/ads_usecase.dart';
import '../../data/models/banners.dart';

abstract class AdsRepository {
  Future<Either<Failure, List<Banners>>> getAds(AdsParams params);
}
