import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/top_10_resturents_entity.dart';
import 'package:fuud/features/home/domain/repositories/top_10_resurents_repository.dart';
// import 'package:fuud/features/home/domain/entities/topten_opening_resturent_entity.dart';
// import 'package:fuud/features/home/domain/repositories/topten_restaurent_repository.dart';

@LazySingleton()
class TopTenRestaurantUsecase
    implements UseCaseWithParams<void, TopTenRestaurantParams> {
  final TopTenRestaurantRepository toptenRestaurantRepository;

  TopTenRestaurantUsecase({required this.toptenRestaurantRepository});
  @override
  Future<Either<Failure, List<TopTenResturentEntity>>> call(params) {
    return toptenRestaurantRepository.getTopTenRestaurant(params);
  }
}

class TopTenRestaurantParams extends Equatable {
  final int count;
  final int userId;

  const TopTenRestaurantParams({required this.count, required this.userId});
  @override
  List<Object?> get props => [id, userId];
}
