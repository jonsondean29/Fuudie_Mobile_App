import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import '../repositories/country_repository.dart';
import '../repositories/home_repository.dart';

@LazySingleton()
class SearchUsecase implements UseCaseWithParams<void, String> {
  final HomeRepository repository;

  SearchUsecase({required this.repository});
  @override
  Future<Either<Failure, List<Restrolist>>> call(params) {
    return repository.search(params);
  }
}

