import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import '../repositories/country_repository.dart';

@LazySingleton()
class UpdateCtiyUsecase implements UseCaseWithParams<void, CityParams> {
  final CountryRepository countryRepository;
  UpdateCtiyUsecase({required this.countryRepository});
  @override
  Future<Either<Failure, String>> call(params) {
    return countryRepository.setCity(params);
  }
}

class CityParams extends Equatable {
  int userID;
  String sortName;
  String cityName;
  CityParams({required this.userID,required this.sortName,required this.cityName});
  @override
  List<Object?> get props => [userID,sortName,cityName];
}
