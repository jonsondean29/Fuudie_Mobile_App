import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/all_tags_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/all_tags_restaurent_repository.dart';

@LazySingleton()
class AllTagsRestaurantUsecase
    implements UseCaseWithParams<void, AllTagsRestaurantParams> {
  final AllTagsRestaurantRepository allTagsRestaurantRepository;

  AllTagsRestaurantUsecase({required this.allTagsRestaurantRepository});
  @override
  Future<Either<Failure, List<AllTagsrestrolistEntity>>> call(params) {
    return allTagsRestaurantRepository.getAllTagsRestaurant(params);
  }
}

class AllTagsRestaurantParams extends Equatable {
  final int count;
  final int userId;

  const AllTagsRestaurantParams({required this.count, required this.userId});
  @override
  List<Object?> get props => [id, userId];
}
