import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/restaurant_details_entity.dart';
import 'package:fuud/features/home/domain/repositories/restaurant_details_entity.dart';

@LazySingleton()
class RestaurantDetailsUsecase
    implements UseCaseWithParams<void, RestaurantDetailsParams> {
  final RestaurantDetailsRepository restaurantDetailsRepository;

  RestaurantDetailsUsecase({required this.restaurantDetailsRepository});
  @override
  Future<Either<Failure, RestaurantDetailsEntity>> call(params) {
    return restaurantDetailsRepository.getRestaurantdetails(params);
  }
}

class RestaurantDetailsParams extends Equatable {
  final int id;
  final int userId;

  const RestaurantDetailsParams({required this.id, required this.userId});
  @override
  List<Object?> get props => [id, userId];
}
