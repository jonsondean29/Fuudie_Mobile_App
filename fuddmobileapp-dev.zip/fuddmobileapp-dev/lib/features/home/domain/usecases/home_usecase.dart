import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/home/data/models/home_response.dart';
import 'package:fuud/features/home/domain/repositories/home_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';

@LazySingleton()
class HomeUsecase implements UseCaseWithParams<void, HomeParams> {
  final HomeRepository repository;

  HomeUsecase({required this.repository});
  @override
  Future<Either<Failure, HomeResponse>> call(params) {
    return repository.getHome(params);
  }
}

class HomeParams extends Equatable {
  int userID;
  int count;
  String sortName;
  String city;
  HomeParams({required this.userID,required this.count,required this.sortName,required this.city});
  @override
  List<Object?> get props => [userID,count,city,sortName];
}
