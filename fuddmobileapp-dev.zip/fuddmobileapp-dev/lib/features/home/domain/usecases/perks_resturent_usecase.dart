import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/home/domain/entities/perks_resturent_list_entity.dart';
import 'package:fuud/features/home/domain/repositories/perks_resturent_repository.dart';

@LazySingleton()
class PerksRestaurantUsecase
    implements UseCaseWithParams<void, PerksRestaurantParams> {
  final PerksRestaurantRepository perksRestaurantRepository;

  PerksRestaurantUsecase({required this.perksRestaurantRepository});
  @override
  Future<Either<Failure, List<PerksResturentEntity>>> call(params) {
    return perksRestaurantRepository.getPerksRestaurant(params);
  }
}

class PerksRestaurantParams extends Equatable {
  final int count;
  final int userId;

  const PerksRestaurantParams({required this.count, required this.userId});
  @override
  List<Object?> get props => [id, userId];
}
