import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:fuud/features/home/data/models/country_response.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import '../repositories/country_repository.dart';

@LazySingleton()
class CountryUsecase implements UseCaseWithParams<void, CountryParams> {
  final CountryRepository countryRepository;

  CountryUsecase({required this.countryRepository});
  @override
  Future<Either<Failure, CountryResponse>> call(params) {
    return countryRepository.getCountry(params);
  }
}

class CountryParams extends Equatable {
  int userID;
   CountryParams({required this.userID});
  @override
  List<Object?> get props => [userID];
}
