class TopTenResturentEntity {
  final int? id;
  final String? name;
  final int? addedBy;
  final String? categoryid;
  final String? categoryname;
  final String? tags;
  final String? shortdescription;
  final String? description;
  final String? location;
  final String? city;
  final String? state;
  final dynamic docuntry;
  final int? totfav;
  final int? totbeen;
  final int? tottry;
  final String? pincode;
  final dynamic phone;
  final String? lat;
  final String? lng;
  final dynamic fblink;
  final String? instalink;
  final double? rating;
  final int? totreviews;
  final dynamic barcode;
  final String? slug;
  final DateTime? createdon;
  final dynamic updatedon;
  final int? isactive;
  final int? isperks;
  final int? isexclusive;
  final int? iswishlist;
  final int? isbeenlist;
  final int? istrylist;
  final dynamic mainimg;
  final dynamic restrimglist;
  final dynamic restroreviewlst;

  TopTenResturentEntity(
      {required this.id,
      required this.name,
      required this.addedBy,
      required this.categoryid,
      required this.categoryname,
      required this.tags,
      required this.shortdescription,
      required this.description,
      required this.location,
      required this.city,
      required this.state,
      required this.docuntry,
      required this.totfav,
      required this.totbeen,
      required this.tottry,
      required this.pincode,
      required this.phone,
      required this.lat,
      required this.lng,
      required this.fblink,
      required this.instalink,
      required this.rating,
      required this.totreviews,
      required this.barcode,
      required this.slug,
      required this.createdon,
      required this.updatedon,
      required this.isactive,
      required this.isperks,
      required this.isexclusive,
      required this.iswishlist,
      required this.isbeenlist,
      required this.istrylist,
      required this.mainimg,
      required this.restrimglist,
      required this.restroreviewlst});
}
