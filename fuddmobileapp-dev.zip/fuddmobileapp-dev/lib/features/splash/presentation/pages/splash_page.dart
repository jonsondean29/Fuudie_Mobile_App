import 'dart:async';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:video_player/video_player.dart';

@RoutePage()
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  static const routeName = '/';

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset("assets/images/bg_video.mp4")
      ..initialize().then((_) {
        _controller.play();
        _controller.setLooping(true);
        _controller.setPlaybackSpeed(1);
        setState(() {});
      });
    Timer(const Duration(seconds: 4), () async {
      context.router.replace(const DashboardRoute());
    });
  }

  @override
  Widget build(BuildContext context) {
    double width=MediaQuery.of(context).size.width;
    double height=MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: Colors.white,
        body:Container(
          alignment: AlignmentDirectional.center,
          child: SizedBox(
            height: height-100,
            child: VideoPlayer(_controller),
          ),
        ),
    );
  }
}
