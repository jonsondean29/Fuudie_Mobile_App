import 'dart:convert';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/constants/urls.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';
import 'package:fuud/features/auth/data/models/signup_responce_model.dart';

abstract class SigUpRemoteDatasource {
  Future<SignUpResponce> signUpUser(SignUpParams params);
}

@LazySingleton(as: SigUpRemoteDatasource)
class SigUpRemoteDatasourceImpl implements SigUpRemoteDatasource {
  final Client client;
  SigUpRemoteDatasourceImpl({required this.client});

  @override
  Future<SignUpResponce> signUpUser(SignUpParams params) async {
    debugPrint('params ${jsonEncode(params.toJson())}');
    try {
      final response = await client.post(
        Uri.parse(Apis.signUp),
        body: jsonEncode(params.toJson()),
        headers: {
          'content-type': 'application/json',
        },
      );
      debugPrint("responseBody ${json.decode(response.body)}");

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);

        final user = SignUpResponce.fromJson(responseBody);
        if (user.messageType == 1 && user.message != null) {
          return user;
        } else {
          throw ServerException(errorMessage: user.message ?? "Signup Failde");
        }
      } else {
        throw CacheException();
      }
    } catch (e) {
      debugPrint('error $e');
      // Handle network errors or JSON decoding errors
      throw ServerException(errorMessage: e.toString());
    }
  }
}
