import 'package:dartz/dartz.dart';
import 'package:fuud/features/auth/domain/usecases/forget_password_usecase.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
import 'package:fuud/features/auth/data/datasources/signin_datasource.dart';
import 'package:fuud/features/auth/domain/repositories/sign_in_repositories.dart';
import 'package:fuud/features/auth/data/models/extentions/sigin_in_extention.dart';

@LazySingleton(as: SignInRepository)
class SignInRepoImpl implements SignInRepository {
  final SignInRemoteDatasource sigInRemoteDatasource;

  SignInRepoImpl({required this.sigInRemoteDatasource});

  @override
  Future<Either<Failure, SignInEntity>> signinUser(params) async {
    try {
      final result = await sigInRemoteDatasource.signInUser(params);
      return right(result.toEntity());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }

  @override
  Future<Either<Failure, SignInEntity>> forgetPassword(ForgetPasswordParams params) async {
    try {
      final result = await sigInRemoteDatasource.forgetPassword(params);
      return right(result.toEntity());
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        const ConnectionFailure('Check internet Connection'),
      );
    }
  }
}
