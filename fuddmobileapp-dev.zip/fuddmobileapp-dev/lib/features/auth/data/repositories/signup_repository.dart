import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/error/exceptions.dart';
import 'package:fuud/features/auth/domain/entities/sign_up_entity.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';
import 'package:fuud/features/auth/data/datasources/signup_datasource.dart';
import 'package:fuud/features/auth/domain/repositories/sign_up_repository.dart';

@LazySingleton(as: SignUpRepository)
class SignUpRepoImpl implements SignUpRepository {
  final SigUpRemoteDatasource sigUpRemoteDatasource;

  SignUpRepoImpl({required this.sigUpRemoteDatasource});

  @override
  Future<Either<Failure, SignUpEntity>> signupUser(SignUpParams params) async {
    try {
      final result = await sigUpRemoteDatasource.signUpUser(params);
      return right(
        SignUpEntity(
            messageType: result.messageType,
            message: result.message,
            returnId: result.returnId),
      );
    } on ServerException catch (e) {
      return left(
        ServerFailure(e.errorMessage),
      );
    } catch (e) {
      return left(
        ServerFailure(
          e.toString(),
        ),
      );
    }
  }
}
