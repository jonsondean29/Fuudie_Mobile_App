// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signup_responce_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SignUpResponceImpl _$$SignUpResponceImplFromJson(Map<String, dynamic> json) =>
    _$SignUpResponceImpl(
      messageType: (json['messageType'] as num?)?.toInt(),
      message: json['message'] as String?,
      returnId: json['returnId'] == null
          ? null
          : ReturnId.fromJson(json['returnId'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$SignUpResponceImplToJson(
        _$SignUpResponceImpl instance) =>
    <String, dynamic>{
      'messageType': instance.messageType,
      'message': instance.message,
      'returnId': instance.returnId,
    };

_$ReturnIdImpl _$$ReturnIdImplFromJson(Map<String, dynamic> json) =>
    _$ReturnIdImpl(
      id: (json['id'] as num?)?.toInt(),
      name: json['name'] as String?,
      email: json['email'] as String?,
      password: json['password'] as String?,
      token: json['token'],
      usertype: (json['usertype'] as num?)?.toInt(),
      refercode: json['refercode'] as String?,
      referbyid: (json['referbyid'] as num?)?.toInt(),
      profileimg: json['profileimg'] as String?,
      phone: json['phone'],
      address: json['address'],
      city: json['city'],
      state: json['state'],
      country: json['country'],
      pincode: json['pincode'],
      createdon: json['createdon'] == null
          ? null
          : DateTime.parse(json['createdon'] as String),
      userrole: (json['userrole'] as num?)?.toInt(),
      isactive: (json['isactive'] as num?)?.toInt(),
      updatedon: json['updatedon'],
      issubscribed: (json['issubscribed'] as num?)?.toInt(),
      totbooked: (json['totbooked'] as num?)?.toInt(),
      lastbookedon: json['lastbookedon'] == null
          ? null
          : DateTime.parse(json['lastbookedon'] as String),
      mainimg: json['mainimg'],
      adminmanage: (json['adminmanage'] as num?)?.toInt(),
      customermanage: (json['customermanage'] as num?)?.toInt(),
      orderlist: (json['orderlist'] as num?)?.toInt(),
      productmodule: (json['productmodule'] as num?)?.toInt(),
      manufacturermodule: (json['manufacturermodule'] as num?)?.toInt(),
      recipemodule: (json['recipemodule'] as num?)?.toInt(),
      newslettermanage: (json['newslettermanage'] as num?)?.toInt(),
      taxdiscountmanage: (json['taxdiscountmanage'] as num?)?.toInt(),
      couponmanage: (json['couponmanage'] as num?)?.toInt(),
      pagemanage: (json['pagemanage'] as num?)?.toInt(),
      generalsettings: (json['generalsettings'] as num?)?.toInt(),
      notifytolowstock: (json['notifytolowstock'] as num?)?.toInt(),
      userright: json['userright'],
    );

Map<String, dynamic> _$$ReturnIdImplToJson(_$ReturnIdImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'email': instance.email,
      'password': instance.password,
      'token': instance.token,
      'usertype': instance.usertype,
      'refercode': instance.refercode,
      'referbyid': instance.referbyid,
      'profileimg': instance.profileimg,
      'phone': instance.phone,
      'address': instance.address,
      'city': instance.city,
      'state': instance.state,
      'country': instance.country,
      'pincode': instance.pincode,
      'createdon': instance.createdon?.toIso8601String(),
      'userrole': instance.userrole,
      'isactive': instance.isactive,
      'updatedon': instance.updatedon,
      'issubscribed': instance.issubscribed,
      'totbooked': instance.totbooked,
      'lastbookedon': instance.lastbookedon?.toIso8601String(),
      'mainimg': instance.mainimg,
      'adminmanage': instance.adminmanage,
      'customermanage': instance.customermanage,
      'orderlist': instance.orderlist,
      'productmodule': instance.productmodule,
      'manufacturermodule': instance.manufacturermodule,
      'recipemodule': instance.recipemodule,
      'newslettermanage': instance.newslettermanage,
      'taxdiscountmanage': instance.taxdiscountmanage,
      'couponmanage': instance.couponmanage,
      'pagemanage': instance.pagemanage,
      'generalsettings': instance.generalsettings,
      'notifytolowstock': instance.notifytolowstock,
      'userright': instance.userright,
    };
