// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'signin_responce_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SignInResponce _$SignInResponceFromJson(Map<String, dynamic> json) {
  return _SignInResponce.fromJson(json);
}

/// @nodoc
mixin _$SignInResponce {
  @JsonKey(name: "messageType")
  int? get messageType => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "returnId")
  ReturnId? get returnId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SignInResponceCopyWith<SignInResponce> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SignInResponceCopyWith<$Res> {
  factory $SignInResponceCopyWith(
          SignInResponce value, $Res Function(SignInResponce) then) =
      _$SignInResponceCopyWithImpl<$Res, SignInResponce>;
  @useResult
  $Res call(
      {@JsonKey(name: "messageType") int? messageType,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "returnId") ReturnId? returnId});

  $ReturnIdCopyWith<$Res>? get returnId;
}

/// @nodoc
class _$SignInResponceCopyWithImpl<$Res, $Val extends SignInResponce>
    implements $SignInResponceCopyWith<$Res> {
  _$SignInResponceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageType = freezed,
    Object? message = freezed,
    Object? returnId = freezed,
  }) {
    return _then(_value.copyWith(
      messageType: freezed == messageType
          ? _value.messageType
          : messageType // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      returnId: freezed == returnId
          ? _value.returnId
          : returnId // ignore: cast_nullable_to_non_nullable
              as ReturnId?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ReturnIdCopyWith<$Res>? get returnId {
    if (_value.returnId == null) {
      return null;
    }

    return $ReturnIdCopyWith<$Res>(_value.returnId!, (value) {
      return _then(_value.copyWith(returnId: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SignInResponceImplCopyWith<$Res>
    implements $SignInResponceCopyWith<$Res> {
  factory _$$SignInResponceImplCopyWith(_$SignInResponceImpl value,
          $Res Function(_$SignInResponceImpl) then) =
      __$$SignInResponceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "messageType") int? messageType,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "returnId") ReturnId? returnId});

  @override
  $ReturnIdCopyWith<$Res>? get returnId;
}

/// @nodoc
class __$$SignInResponceImplCopyWithImpl<$Res>
    extends _$SignInResponceCopyWithImpl<$Res, _$SignInResponceImpl>
    implements _$$SignInResponceImplCopyWith<$Res> {
  __$$SignInResponceImplCopyWithImpl(
      _$SignInResponceImpl _value, $Res Function(_$SignInResponceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageType = freezed,
    Object? message = freezed,
    Object? returnId = freezed,
  }) {
    return _then(_$SignInResponceImpl(
      messageType: freezed == messageType
          ? _value.messageType
          : messageType // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      returnId: freezed == returnId
          ? _value.returnId
          : returnId // ignore: cast_nullable_to_non_nullable
              as ReturnId?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SignInResponceImpl implements _SignInResponce {
  const _$SignInResponceImpl(
      {@JsonKey(name: "messageType") this.messageType,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "returnId") this.returnId});

  factory _$SignInResponceImpl.fromJson(Map<String, dynamic> json) =>
      _$$SignInResponceImplFromJson(json);

  @override
  @JsonKey(name: "messageType")
  final int? messageType;
  @override
  @JsonKey(name: "message")
  final String? message;
  @override
  @JsonKey(name: "returnId")
  final ReturnId? returnId;

  @override
  String toString() {
    return 'SignInResponce(messageType: $messageType, message: $message, returnId: $returnId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignInResponceImpl &&
            (identical(other.messageType, messageType) ||
                other.messageType == messageType) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.returnId, returnId) ||
                other.returnId == returnId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, messageType, message, returnId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignInResponceImplCopyWith<_$SignInResponceImpl> get copyWith =>
      __$$SignInResponceImplCopyWithImpl<_$SignInResponceImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SignInResponceImplToJson(
      this,
    );
  }
}

abstract class _SignInResponce implements SignInResponce {
  const factory _SignInResponce(
          {@JsonKey(name: "messageType") final int? messageType,
          @JsonKey(name: "message") final String? message,
          @JsonKey(name: "returnId") final ReturnId? returnId}) =
      _$SignInResponceImpl;

  factory _SignInResponce.fromJson(Map<String, dynamic> json) =
      _$SignInResponceImpl.fromJson;

  @override
  @JsonKey(name: "messageType")
  int? get messageType;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "returnId")
  ReturnId? get returnId;
  @override
  @JsonKey(ignore: true)
  _$$SignInResponceImplCopyWith<_$SignInResponceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ReturnId _$ReturnIdFromJson(Map<String, dynamic> json) {
  return _ReturnId.fromJson(json);
}

/// @nodoc
mixin _$ReturnId {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  String? get name => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "password")
  String? get password => throw _privateConstructorUsedError;
  @JsonKey(name: "token")
  dynamic get token => throw _privateConstructorUsedError;
  @JsonKey(name: "usertype")
  int? get usertype => throw _privateConstructorUsedError;
  @JsonKey(name: "refercode")
  String? get refercode => throw _privateConstructorUsedError;
  @JsonKey(name: "referbyid")
  int? get referbyid => throw _privateConstructorUsedError;
  @JsonKey(name: "profileimg")
  String? get profileimg => throw _privateConstructorUsedError;
  @JsonKey(name: "phone")
  dynamic get phone => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  dynamic get address => throw _privateConstructorUsedError;
  @JsonKey(name: "city")
  dynamic get city => throw _privateConstructorUsedError;
  @JsonKey(name: "state")
  dynamic get state => throw _privateConstructorUsedError;
  @JsonKey(name: "country")
  dynamic get country => throw _privateConstructorUsedError;
  @JsonKey(name: "pincode")
  dynamic get pincode => throw _privateConstructorUsedError;
  @JsonKey(name: "createdon")
  DateTime? get createdon => throw _privateConstructorUsedError;
  @JsonKey(name: "userrole")
  int? get userrole => throw _privateConstructorUsedError;
  @JsonKey(name: "isactive")
  int? get isactive => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedon")
  dynamic get updatedon => throw _privateConstructorUsedError;
  @JsonKey(name: "issubscribed")
  int? get issubscribed => throw _privateConstructorUsedError;
  @JsonKey(name: "totbooked")
  int? get totbooked => throw _privateConstructorUsedError;
  @JsonKey(name: "lastbookedon")
  DateTime? get lastbookedon => throw _privateConstructorUsedError;
  @JsonKey(name: "mainimg")
  dynamic get mainimg => throw _privateConstructorUsedError;
  @JsonKey(name: "adminmanage")
  int? get adminmanage => throw _privateConstructorUsedError;
  @JsonKey(name: "customermanage")
  int? get customermanage => throw _privateConstructorUsedError;
  @JsonKey(name: "orderlist")
  int? get orderlist => throw _privateConstructorUsedError;
  @JsonKey(name: "productmodule")
  int? get productmodule => throw _privateConstructorUsedError;
  @JsonKey(name: "manufacturermodule")
  int? get manufacturermodule => throw _privateConstructorUsedError;
  @JsonKey(name: "recipemodule")
  int? get recipemodule => throw _privateConstructorUsedError;
  @JsonKey(name: "newslettermanage")
  int? get newslettermanage => throw _privateConstructorUsedError;
  @JsonKey(name: "taxdiscountmanage")
  int? get taxdiscountmanage => throw _privateConstructorUsedError;
  @JsonKey(name: "couponmanage")
  int? get couponmanage => throw _privateConstructorUsedError;
  @JsonKey(name: "pagemanage")
  int? get pagemanage => throw _privateConstructorUsedError;
  @JsonKey(name: "generalsettings")
  int? get generalsettings => throw _privateConstructorUsedError;
  @JsonKey(name: "notifytolowstock")
  int? get notifytolowstock => throw _privateConstructorUsedError;
  @JsonKey(name: "userright")
  dynamic get userright => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ReturnIdCopyWith<ReturnId> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReturnIdCopyWith<$Res> {
  factory $ReturnIdCopyWith(ReturnId value, $Res Function(ReturnId) then) =
      _$ReturnIdCopyWithImpl<$Res, ReturnId>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") String? password,
      @JsonKey(name: "token") dynamic token,
      @JsonKey(name: "usertype") int? usertype,
      @JsonKey(name: "refercode") String? refercode,
      @JsonKey(name: "referbyid") int? referbyid,
      @JsonKey(name: "profileimg") String? profileimg,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "address") dynamic address,
      @JsonKey(name: "city") dynamic city,
      @JsonKey(name: "state") dynamic state,
      @JsonKey(name: "country") dynamic country,
      @JsonKey(name: "pincode") dynamic pincode,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "userrole") int? userrole,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "issubscribed") int? issubscribed,
      @JsonKey(name: "totbooked") int? totbooked,
      @JsonKey(name: "lastbookedon") DateTime? lastbookedon,
      @JsonKey(name: "mainimg") dynamic mainimg,
      @JsonKey(name: "adminmanage") int? adminmanage,
      @JsonKey(name: "customermanage") int? customermanage,
      @JsonKey(name: "orderlist") int? orderlist,
      @JsonKey(name: "productmodule") int? productmodule,
      @JsonKey(name: "manufacturermodule") int? manufacturermodule,
      @JsonKey(name: "recipemodule") int? recipemodule,
      @JsonKey(name: "newslettermanage") int? newslettermanage,
      @JsonKey(name: "taxdiscountmanage") int? taxdiscountmanage,
      @JsonKey(name: "couponmanage") int? couponmanage,
      @JsonKey(name: "pagemanage") int? pagemanage,
      @JsonKey(name: "generalsettings") int? generalsettings,
      @JsonKey(name: "notifytolowstock") int? notifytolowstock,
      @JsonKey(name: "userright") dynamic userright});
}

/// @nodoc
class _$ReturnIdCopyWithImpl<$Res, $Val extends ReturnId>
    implements $ReturnIdCopyWith<$Res> {
  _$ReturnIdCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? token = freezed,
    Object? usertype = freezed,
    Object? refercode = freezed,
    Object? referbyid = freezed,
    Object? profileimg = freezed,
    Object? phone = freezed,
    Object? address = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? country = freezed,
    Object? pincode = freezed,
    Object? createdon = freezed,
    Object? userrole = freezed,
    Object? isactive = freezed,
    Object? updatedon = freezed,
    Object? issubscribed = freezed,
    Object? totbooked = freezed,
    Object? lastbookedon = freezed,
    Object? mainimg = freezed,
    Object? adminmanage = freezed,
    Object? customermanage = freezed,
    Object? orderlist = freezed,
    Object? productmodule = freezed,
    Object? manufacturermodule = freezed,
    Object? recipemodule = freezed,
    Object? newslettermanage = freezed,
    Object? taxdiscountmanage = freezed,
    Object? couponmanage = freezed,
    Object? pagemanage = freezed,
    Object? generalsettings = freezed,
    Object? notifytolowstock = freezed,
    Object? userright = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as dynamic,
      usertype: freezed == usertype
          ? _value.usertype
          : usertype // ignore: cast_nullable_to_non_nullable
              as int?,
      refercode: freezed == refercode
          ? _value.refercode
          : refercode // ignore: cast_nullable_to_non_nullable
              as String?,
      referbyid: freezed == referbyid
          ? _value.referbyid
          : referbyid // ignore: cast_nullable_to_non_nullable
              as int?,
      profileimg: freezed == profileimg
          ? _value.profileimg
          : profileimg // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as dynamic,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as dynamic,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as dynamic,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as dynamic,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      userrole: freezed == userrole
          ? _value.userrole
          : userrole // ignore: cast_nullable_to_non_nullable
              as int?,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      issubscribed: freezed == issubscribed
          ? _value.issubscribed
          : issubscribed // ignore: cast_nullable_to_non_nullable
              as int?,
      totbooked: freezed == totbooked
          ? _value.totbooked
          : totbooked // ignore: cast_nullable_to_non_nullable
              as int?,
      lastbookedon: freezed == lastbookedon
          ? _value.lastbookedon
          : lastbookedon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      mainimg: freezed == mainimg
          ? _value.mainimg
          : mainimg // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminmanage: freezed == adminmanage
          ? _value.adminmanage
          : adminmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      customermanage: freezed == customermanage
          ? _value.customermanage
          : customermanage // ignore: cast_nullable_to_non_nullable
              as int?,
      orderlist: freezed == orderlist
          ? _value.orderlist
          : orderlist // ignore: cast_nullable_to_non_nullable
              as int?,
      productmodule: freezed == productmodule
          ? _value.productmodule
          : productmodule // ignore: cast_nullable_to_non_nullable
              as int?,
      manufacturermodule: freezed == manufacturermodule
          ? _value.manufacturermodule
          : manufacturermodule // ignore: cast_nullable_to_non_nullable
              as int?,
      recipemodule: freezed == recipemodule
          ? _value.recipemodule
          : recipemodule // ignore: cast_nullable_to_non_nullable
              as int?,
      newslettermanage: freezed == newslettermanage
          ? _value.newslettermanage
          : newslettermanage // ignore: cast_nullable_to_non_nullable
              as int?,
      taxdiscountmanage: freezed == taxdiscountmanage
          ? _value.taxdiscountmanage
          : taxdiscountmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      couponmanage: freezed == couponmanage
          ? _value.couponmanage
          : couponmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      pagemanage: freezed == pagemanage
          ? _value.pagemanage
          : pagemanage // ignore: cast_nullable_to_non_nullable
              as int?,
      generalsettings: freezed == generalsettings
          ? _value.generalsettings
          : generalsettings // ignore: cast_nullable_to_non_nullable
              as int?,
      notifytolowstock: freezed == notifytolowstock
          ? _value.notifytolowstock
          : notifytolowstock // ignore: cast_nullable_to_non_nullable
              as int?,
      userright: freezed == userright
          ? _value.userright
          : userright // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ReturnIdImplCopyWith<$Res>
    implements $ReturnIdCopyWith<$Res> {
  factory _$$ReturnIdImplCopyWith(
          _$ReturnIdImpl value, $Res Function(_$ReturnIdImpl) then) =
      __$$ReturnIdImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") String? password,
      @JsonKey(name: "token") dynamic token,
      @JsonKey(name: "usertype") int? usertype,
      @JsonKey(name: "refercode") String? refercode,
      @JsonKey(name: "referbyid") int? referbyid,
      @JsonKey(name: "profileimg") String? profileimg,
      @JsonKey(name: "phone") dynamic phone,
      @JsonKey(name: "address") dynamic address,
      @JsonKey(name: "city") dynamic city,
      @JsonKey(name: "state") dynamic state,
      @JsonKey(name: "country") dynamic country,
      @JsonKey(name: "pincode") dynamic pincode,
      @JsonKey(name: "createdon") DateTime? createdon,
      @JsonKey(name: "userrole") int? userrole,
      @JsonKey(name: "isactive") int? isactive,
      @JsonKey(name: "updatedon") dynamic updatedon,
      @JsonKey(name: "issubscribed") int? issubscribed,
      @JsonKey(name: "totbooked") int? totbooked,
      @JsonKey(name: "lastbookedon") DateTime? lastbookedon,
      @JsonKey(name: "mainimg") dynamic mainimg,
      @JsonKey(name: "adminmanage") int? adminmanage,
      @JsonKey(name: "customermanage") int? customermanage,
      @JsonKey(name: "orderlist") int? orderlist,
      @JsonKey(name: "productmodule") int? productmodule,
      @JsonKey(name: "manufacturermodule") int? manufacturermodule,
      @JsonKey(name: "recipemodule") int? recipemodule,
      @JsonKey(name: "newslettermanage") int? newslettermanage,
      @JsonKey(name: "taxdiscountmanage") int? taxdiscountmanage,
      @JsonKey(name: "couponmanage") int? couponmanage,
      @JsonKey(name: "pagemanage") int? pagemanage,
      @JsonKey(name: "generalsettings") int? generalsettings,
      @JsonKey(name: "notifytolowstock") int? notifytolowstock,
      @JsonKey(name: "userright") dynamic userright});
}

/// @nodoc
class __$$ReturnIdImplCopyWithImpl<$Res>
    extends _$ReturnIdCopyWithImpl<$Res, _$ReturnIdImpl>
    implements _$$ReturnIdImplCopyWith<$Res> {
  __$$ReturnIdImplCopyWithImpl(
      _$ReturnIdImpl _value, $Res Function(_$ReturnIdImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? token = freezed,
    Object? usertype = freezed,
    Object? refercode = freezed,
    Object? referbyid = freezed,
    Object? profileimg = freezed,
    Object? phone = freezed,
    Object? address = freezed,
    Object? city = freezed,
    Object? state = freezed,
    Object? country = freezed,
    Object? pincode = freezed,
    Object? createdon = freezed,
    Object? userrole = freezed,
    Object? isactive = freezed,
    Object? updatedon = freezed,
    Object? issubscribed = freezed,
    Object? totbooked = freezed,
    Object? lastbookedon = freezed,
    Object? mainimg = freezed,
    Object? adminmanage = freezed,
    Object? customermanage = freezed,
    Object? orderlist = freezed,
    Object? productmodule = freezed,
    Object? manufacturermodule = freezed,
    Object? recipemodule = freezed,
    Object? newslettermanage = freezed,
    Object? taxdiscountmanage = freezed,
    Object? couponmanage = freezed,
    Object? pagemanage = freezed,
    Object? generalsettings = freezed,
    Object? notifytolowstock = freezed,
    Object? userright = freezed,
  }) {
    return _then(_$ReturnIdImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as dynamic,
      usertype: freezed == usertype
          ? _value.usertype
          : usertype // ignore: cast_nullable_to_non_nullable
              as int?,
      refercode: freezed == refercode
          ? _value.refercode
          : refercode // ignore: cast_nullable_to_non_nullable
              as String?,
      referbyid: freezed == referbyid
          ? _value.referbyid
          : referbyid // ignore: cast_nullable_to_non_nullable
              as int?,
      profileimg: freezed == profileimg
          ? _value.profileimg
          : profileimg // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as dynamic,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as dynamic,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as dynamic,
      state: freezed == state
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as dynamic,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as dynamic,
      pincode: freezed == pincode
          ? _value.pincode
          : pincode // ignore: cast_nullable_to_non_nullable
              as dynamic,
      createdon: freezed == createdon
          ? _value.createdon
          : createdon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      userrole: freezed == userrole
          ? _value.userrole
          : userrole // ignore: cast_nullable_to_non_nullable
              as int?,
      isactive: freezed == isactive
          ? _value.isactive
          : isactive // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedon: freezed == updatedon
          ? _value.updatedon
          : updatedon // ignore: cast_nullable_to_non_nullable
              as dynamic,
      issubscribed: freezed == issubscribed
          ? _value.issubscribed
          : issubscribed // ignore: cast_nullable_to_non_nullable
              as int?,
      totbooked: freezed == totbooked
          ? _value.totbooked
          : totbooked // ignore: cast_nullable_to_non_nullable
              as int?,
      lastbookedon: freezed == lastbookedon
          ? _value.lastbookedon
          : lastbookedon // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      mainimg: freezed == mainimg
          ? _value.mainimg
          : mainimg // ignore: cast_nullable_to_non_nullable
              as dynamic,
      adminmanage: freezed == adminmanage
          ? _value.adminmanage
          : adminmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      customermanage: freezed == customermanage
          ? _value.customermanage
          : customermanage // ignore: cast_nullable_to_non_nullable
              as int?,
      orderlist: freezed == orderlist
          ? _value.orderlist
          : orderlist // ignore: cast_nullable_to_non_nullable
              as int?,
      productmodule: freezed == productmodule
          ? _value.productmodule
          : productmodule // ignore: cast_nullable_to_non_nullable
              as int?,
      manufacturermodule: freezed == manufacturermodule
          ? _value.manufacturermodule
          : manufacturermodule // ignore: cast_nullable_to_non_nullable
              as int?,
      recipemodule: freezed == recipemodule
          ? _value.recipemodule
          : recipemodule // ignore: cast_nullable_to_non_nullable
              as int?,
      newslettermanage: freezed == newslettermanage
          ? _value.newslettermanage
          : newslettermanage // ignore: cast_nullable_to_non_nullable
              as int?,
      taxdiscountmanage: freezed == taxdiscountmanage
          ? _value.taxdiscountmanage
          : taxdiscountmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      couponmanage: freezed == couponmanage
          ? _value.couponmanage
          : couponmanage // ignore: cast_nullable_to_non_nullable
              as int?,
      pagemanage: freezed == pagemanage
          ? _value.pagemanage
          : pagemanage // ignore: cast_nullable_to_non_nullable
              as int?,
      generalsettings: freezed == generalsettings
          ? _value.generalsettings
          : generalsettings // ignore: cast_nullable_to_non_nullable
              as int?,
      notifytolowstock: freezed == notifytolowstock
          ? _value.notifytolowstock
          : notifytolowstock // ignore: cast_nullable_to_non_nullable
              as int?,
      userright: freezed == userright
          ? _value.userright
          : userright // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ReturnIdImpl implements _ReturnId {
  const _$ReturnIdImpl(
      {@JsonKey(name: "id") this.id,
      @JsonKey(name: "name") this.name,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "password") this.password,
      @JsonKey(name: "token") this.token,
      @JsonKey(name: "usertype") this.usertype,
      @JsonKey(name: "refercode") this.refercode,
      @JsonKey(name: "referbyid") this.referbyid,
      @JsonKey(name: "profileimg") this.profileimg,
      @JsonKey(name: "phone") this.phone,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "city") this.city,
      @JsonKey(name: "state") this.state,
      @JsonKey(name: "country") this.country,
      @JsonKey(name: "pincode") this.pincode,
      @JsonKey(name: "createdon") this.createdon,
      @JsonKey(name: "userrole") this.userrole,
      @JsonKey(name: "isactive") this.isactive,
      @JsonKey(name: "updatedon") this.updatedon,
      @JsonKey(name: "issubscribed") this.issubscribed,
      @JsonKey(name: "totbooked") this.totbooked,
      @JsonKey(name: "lastbookedon") this.lastbookedon,
      @JsonKey(name: "mainimg") this.mainimg,
      @JsonKey(name: "adminmanage") this.adminmanage,
      @JsonKey(name: "customermanage") this.customermanage,
      @JsonKey(name: "orderlist") this.orderlist,
      @JsonKey(name: "productmodule") this.productmodule,
      @JsonKey(name: "manufacturermodule") this.manufacturermodule,
      @JsonKey(name: "recipemodule") this.recipemodule,
      @JsonKey(name: "newslettermanage") this.newslettermanage,
      @JsonKey(name: "taxdiscountmanage") this.taxdiscountmanage,
      @JsonKey(name: "couponmanage") this.couponmanage,
      @JsonKey(name: "pagemanage") this.pagemanage,
      @JsonKey(name: "generalsettings") this.generalsettings,
      @JsonKey(name: "notifytolowstock") this.notifytolowstock,
      @JsonKey(name: "userright") this.userright});

  factory _$ReturnIdImpl.fromJson(Map<String, dynamic> json) =>
      _$$ReturnIdImplFromJson(json);

  @override
  @JsonKey(name: "id")
  final int? id;
  @override
  @JsonKey(name: "name")
  final String? name;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "password")
  final String? password;
  @override
  @JsonKey(name: "token")
  final dynamic token;
  @override
  @JsonKey(name: "usertype")
  final int? usertype;
  @override
  @JsonKey(name: "refercode")
  final String? refercode;
  @override
  @JsonKey(name: "referbyid")
  final int? referbyid;
  @override
  @JsonKey(name: "profileimg")
  final String? profileimg;
  @override
  @JsonKey(name: "phone")
  final dynamic phone;
  @override
  @JsonKey(name: "address")
  final dynamic address;
  @override
  @JsonKey(name: "city")
  final dynamic city;
  @override
  @JsonKey(name: "state")
  final dynamic state;
  @override
  @JsonKey(name: "country")
  final dynamic country;
  @override
  @JsonKey(name: "pincode")
  final dynamic pincode;
  @override
  @JsonKey(name: "createdon")
  final DateTime? createdon;
  @override
  @JsonKey(name: "userrole")
  final int? userrole;
  @override
  @JsonKey(name: "isactive")
  final int? isactive;
  @override
  @JsonKey(name: "updatedon")
  final dynamic updatedon;
  @override
  @JsonKey(name: "issubscribed")
  final int? issubscribed;
  @override
  @JsonKey(name: "totbooked")
  final int? totbooked;
  @override
  @JsonKey(name: "lastbookedon")
  final DateTime? lastbookedon;
  @override
  @JsonKey(name: "mainimg")
  final dynamic mainimg;
  @override
  @JsonKey(name: "adminmanage")
  final int? adminmanage;
  @override
  @JsonKey(name: "customermanage")
  final int? customermanage;
  @override
  @JsonKey(name: "orderlist")
  final int? orderlist;
  @override
  @JsonKey(name: "productmodule")
  final int? productmodule;
  @override
  @JsonKey(name: "manufacturermodule")
  final int? manufacturermodule;
  @override
  @JsonKey(name: "recipemodule")
  final int? recipemodule;
  @override
  @JsonKey(name: "newslettermanage")
  final int? newslettermanage;
  @override
  @JsonKey(name: "taxdiscountmanage")
  final int? taxdiscountmanage;
  @override
  @JsonKey(name: "couponmanage")
  final int? couponmanage;
  @override
  @JsonKey(name: "pagemanage")
  final int? pagemanage;
  @override
  @JsonKey(name: "generalsettings")
  final int? generalsettings;
  @override
  @JsonKey(name: "notifytolowstock")
  final int? notifytolowstock;
  @override
  @JsonKey(name: "userright")
  final dynamic userright;

  @override
  String toString() {
    return 'ReturnId(id: $id, name: $name, email: $email, password: $password, token: $token, usertype: $usertype, refercode: $refercode, referbyid: $referbyid, profileimg: $profileimg, phone: $phone, address: $address, city: $city, state: $state, country: $country, pincode: $pincode, createdon: $createdon, userrole: $userrole, isactive: $isactive, updatedon: $updatedon, issubscribed: $issubscribed, totbooked: $totbooked, lastbookedon: $lastbookedon, mainimg: $mainimg, adminmanage: $adminmanage, customermanage: $customermanage, orderlist: $orderlist, productmodule: $productmodule, manufacturermodule: $manufacturermodule, recipemodule: $recipemodule, newslettermanage: $newslettermanage, taxdiscountmanage: $taxdiscountmanage, couponmanage: $couponmanage, pagemanage: $pagemanage, generalsettings: $generalsettings, notifytolowstock: $notifytolowstock, userright: $userright)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ReturnIdImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.password, password) ||
                other.password == password) &&
            const DeepCollectionEquality().equals(other.token, token) &&
            (identical(other.usertype, usertype) ||
                other.usertype == usertype) &&
            (identical(other.refercode, refercode) ||
                other.refercode == refercode) &&
            (identical(other.referbyid, referbyid) ||
                other.referbyid == referbyid) &&
            (identical(other.profileimg, profileimg) ||
                other.profileimg == profileimg) &&
            const DeepCollectionEquality().equals(other.phone, phone) &&
            const DeepCollectionEquality().equals(other.address, address) &&
            const DeepCollectionEquality().equals(other.city, city) &&
            const DeepCollectionEquality().equals(other.state, state) &&
            const DeepCollectionEquality().equals(other.country, country) &&
            const DeepCollectionEquality().equals(other.pincode, pincode) &&
            (identical(other.createdon, createdon) ||
                other.createdon == createdon) &&
            (identical(other.userrole, userrole) ||
                other.userrole == userrole) &&
            (identical(other.isactive, isactive) ||
                other.isactive == isactive) &&
            const DeepCollectionEquality().equals(other.updatedon, updatedon) &&
            (identical(other.issubscribed, issubscribed) ||
                other.issubscribed == issubscribed) &&
            (identical(other.totbooked, totbooked) ||
                other.totbooked == totbooked) &&
            (identical(other.lastbookedon, lastbookedon) ||
                other.lastbookedon == lastbookedon) &&
            const DeepCollectionEquality().equals(other.mainimg, mainimg) &&
            (identical(other.adminmanage, adminmanage) ||
                other.adminmanage == adminmanage) &&
            (identical(other.customermanage, customermanage) ||
                other.customermanage == customermanage) &&
            (identical(other.orderlist, orderlist) ||
                other.orderlist == orderlist) &&
            (identical(other.productmodule, productmodule) ||
                other.productmodule == productmodule) &&
            (identical(other.manufacturermodule, manufacturermodule) ||
                other.manufacturermodule == manufacturermodule) &&
            (identical(other.recipemodule, recipemodule) ||
                other.recipemodule == recipemodule) &&
            (identical(other.newslettermanage, newslettermanage) ||
                other.newslettermanage == newslettermanage) &&
            (identical(other.taxdiscountmanage, taxdiscountmanage) ||
                other.taxdiscountmanage == taxdiscountmanage) &&
            (identical(other.couponmanage, couponmanage) ||
                other.couponmanage == couponmanage) &&
            (identical(other.pagemanage, pagemanage) ||
                other.pagemanage == pagemanage) &&
            (identical(other.generalsettings, generalsettings) ||
                other.generalsettings == generalsettings) &&
            (identical(other.notifytolowstock, notifytolowstock) ||
                other.notifytolowstock == notifytolowstock) &&
            const DeepCollectionEquality().equals(other.userright, userright));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        name,
        email,
        password,
        const DeepCollectionEquality().hash(token),
        usertype,
        refercode,
        referbyid,
        profileimg,
        const DeepCollectionEquality().hash(phone),
        const DeepCollectionEquality().hash(address),
        const DeepCollectionEquality().hash(city),
        const DeepCollectionEquality().hash(state),
        const DeepCollectionEquality().hash(country),
        const DeepCollectionEquality().hash(pincode),
        createdon,
        userrole,
        isactive,
        const DeepCollectionEquality().hash(updatedon),
        issubscribed,
        totbooked,
        lastbookedon,
        const DeepCollectionEquality().hash(mainimg),
        adminmanage,
        customermanage,
        orderlist,
        productmodule,
        manufacturermodule,
        recipemodule,
        newslettermanage,
        taxdiscountmanage,
        couponmanage,
        pagemanage,
        generalsettings,
        notifytolowstock,
        const DeepCollectionEquality().hash(userright)
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ReturnIdImplCopyWith<_$ReturnIdImpl> get copyWith =>
      __$$ReturnIdImplCopyWithImpl<_$ReturnIdImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ReturnIdImplToJson(
      this,
    );
  }
}

abstract class _ReturnId implements ReturnId {
  const factory _ReturnId(
      {@JsonKey(name: "id") final int? id,
      @JsonKey(name: "name") final String? name,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "password") final String? password,
      @JsonKey(name: "token") final dynamic token,
      @JsonKey(name: "usertype") final int? usertype,
      @JsonKey(name: "refercode") final String? refercode,
      @JsonKey(name: "referbyid") final int? referbyid,
      @JsonKey(name: "profileimg") final String? profileimg,
      @JsonKey(name: "phone") final dynamic phone,
      @JsonKey(name: "address") final dynamic address,
      @JsonKey(name: "city") final dynamic city,
      @JsonKey(name: "state") final dynamic state,
      @JsonKey(name: "country") final dynamic country,
      @JsonKey(name: "pincode") final dynamic pincode,
      @JsonKey(name: "createdon") final DateTime? createdon,
      @JsonKey(name: "userrole") final int? userrole,
      @JsonKey(name: "isactive") final int? isactive,
      @JsonKey(name: "updatedon") final dynamic updatedon,
      @JsonKey(name: "issubscribed") final int? issubscribed,
      @JsonKey(name: "totbooked") final int? totbooked,
      @JsonKey(name: "lastbookedon") final DateTime? lastbookedon,
      @JsonKey(name: "mainimg") final dynamic mainimg,
      @JsonKey(name: "adminmanage") final int? adminmanage,
      @JsonKey(name: "customermanage") final int? customermanage,
      @JsonKey(name: "orderlist") final int? orderlist,
      @JsonKey(name: "productmodule") final int? productmodule,
      @JsonKey(name: "manufacturermodule") final int? manufacturermodule,
      @JsonKey(name: "recipemodule") final int? recipemodule,
      @JsonKey(name: "newslettermanage") final int? newslettermanage,
      @JsonKey(name: "taxdiscountmanage") final int? taxdiscountmanage,
      @JsonKey(name: "couponmanage") final int? couponmanage,
      @JsonKey(name: "pagemanage") final int? pagemanage,
      @JsonKey(name: "generalsettings") final int? generalsettings,
      @JsonKey(name: "notifytolowstock") final int? notifytolowstock,
      @JsonKey(name: "userright") final dynamic userright}) = _$ReturnIdImpl;

  factory _ReturnId.fromJson(Map<String, dynamic> json) =
      _$ReturnIdImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @override
  @JsonKey(name: "name")
  String? get name;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "password")
  String? get password;
  @override
  @JsonKey(name: "token")
  dynamic get token;
  @override
  @JsonKey(name: "usertype")
  int? get usertype;
  @override
  @JsonKey(name: "refercode")
  String? get refercode;
  @override
  @JsonKey(name: "referbyid")
  int? get referbyid;
  @override
  @JsonKey(name: "profileimg")
  String? get profileimg;
  @override
  @JsonKey(name: "phone")
  dynamic get phone;
  @override
  @JsonKey(name: "address")
  dynamic get address;
  @override
  @JsonKey(name: "city")
  dynamic get city;
  @override
  @JsonKey(name: "state")
  dynamic get state;
  @override
  @JsonKey(name: "country")
  dynamic get country;
  @override
  @JsonKey(name: "pincode")
  dynamic get pincode;
  @override
  @JsonKey(name: "createdon")
  DateTime? get createdon;
  @override
  @JsonKey(name: "userrole")
  int? get userrole;
  @override
  @JsonKey(name: "isactive")
  int? get isactive;
  @override
  @JsonKey(name: "updatedon")
  dynamic get updatedon;
  @override
  @JsonKey(name: "issubscribed")
  int? get issubscribed;
  @override
  @JsonKey(name: "totbooked")
  int? get totbooked;
  @override
  @JsonKey(name: "lastbookedon")
  DateTime? get lastbookedon;
  @override
  @JsonKey(name: "mainimg")
  dynamic get mainimg;
  @override
  @JsonKey(name: "adminmanage")
  int? get adminmanage;
  @override
  @JsonKey(name: "customermanage")
  int? get customermanage;
  @override
  @JsonKey(name: "orderlist")
  int? get orderlist;
  @override
  @JsonKey(name: "productmodule")
  int? get productmodule;
  @override
  @JsonKey(name: "manufacturermodule")
  int? get manufacturermodule;
  @override
  @JsonKey(name: "recipemodule")
  int? get recipemodule;
  @override
  @JsonKey(name: "newslettermanage")
  int? get newslettermanage;
  @override
  @JsonKey(name: "taxdiscountmanage")
  int? get taxdiscountmanage;
  @override
  @JsonKey(name: "couponmanage")
  int? get couponmanage;
  @override
  @JsonKey(name: "pagemanage")
  int? get pagemanage;
  @override
  @JsonKey(name: "generalsettings")
  int? get generalsettings;
  @override
  @JsonKey(name: "notifytolowstock")
  int? get notifytolowstock;
  @override
  @JsonKey(name: "userright")
  dynamic get userright;
  @override
  @JsonKey(ignore: true)
  _$$ReturnIdImplCopyWith<_$ReturnIdImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
