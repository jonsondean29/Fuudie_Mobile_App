import 'package:iconly/iconly.dart';
import 'package:flutter/material.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:fuud/core/validations/validator.dart';

class SignInForm extends StatefulWidget {
  const SignInForm({
    required this.emailController,
    required this.passwordController,
    required this.formKey,
    super.key,
  });

  final TextEditingController emailController;
  final TextEditingController passwordController;
  final GlobalKey<FormState> formKey;

  @override
  State<SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<SignInForm> {
  bool obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          InputField(
            overrideValidator: true,
            controller: widget.emailController,
            hintText: 'Email',
            validator: (p0) {
              if (p0 != null) {
                return validateEmail(p0);
              }
              return null;
            },
            keyboardType: TextInputType.emailAddress,
            suffixIcon: const Icon(
              IconlyLight.message,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 25),
          InputField(
            controller: widget.passwordController,
            hintText: 'Password',
            obscureText: obscurePassword,
            keyboardType: TextInputType.visiblePassword,
            suffixIcon: IconButton(
              onPressed: () => setState(() {
                obscurePassword = !obscurePassword;
              }),
              icon: Icon(
                obscurePassword ? IconlyLight.hide : IconlyLight.show,
                color: Colors.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
