import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';

class AppleSignInButton extends StatelessWidget {
  String deviceid;
   AppleSignInButton({super.key,required this.deviceid});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        try {
          final result = await SignInWithApple.getAppleIDCredential(
            scopes: [
              AppleIDAuthorizationScopes.email,
              AppleIDAuthorizationScopes.fullName,
            ],
          );

          if (result.email != null) {
            if (context.mounted) {
              context.read<AuthBloc>().add(
                    Login(
                        signinParams: SigninParams(
                          email: result.email!,
                          password: 'Fudd@2024',
                          deviceid: deviceid??""
                        ),
                        context: context),
                  );
            }
          } else {
            Fluttertoast.showToast(
              msg: 'Email is required for login.',
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0,
            );
          }
        } catch (error) {
          Fluttertoast.showToast(
            msg: error.toString(),
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
      child: SvgPicture.asset(
          'assets/images/apple-icon.svg'), // Adjust the asset path accordingly
    );
  }
}
