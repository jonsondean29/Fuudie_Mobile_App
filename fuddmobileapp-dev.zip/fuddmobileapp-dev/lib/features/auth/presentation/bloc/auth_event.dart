part of 'auth_bloc.dart';

@freezed
class AuthEvent with _$AuthEvent {
  const factory AuthEvent.login(
      {required SigninParams signinParams,
      required BuildContext context}) = Login;

  const factory AuthEvent.signup(SignUpParams signUpParams) = Signup;
  const factory AuthEvent.generateOtp({required String email,required BuildContext context}) = GenerateOtp;
  const factory AuthEvent.verifyOtp({required String email,required String otp,required BuildContext context}) = VerifyOtp;
  const factory AuthEvent.resetPassword({required String email,required String password,required BuildContext context}) = ResetPassword;
}
