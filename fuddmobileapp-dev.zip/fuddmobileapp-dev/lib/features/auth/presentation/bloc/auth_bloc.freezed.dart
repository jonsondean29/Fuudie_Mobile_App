// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'auth_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AuthEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AuthEventCopyWith<$Res> {
  factory $AuthEventCopyWith(AuthEvent value, $Res Function(AuthEvent) then) =
      _$AuthEventCopyWithImpl<$Res, AuthEvent>;
}

/// @nodoc
class _$AuthEventCopyWithImpl<$Res, $Val extends AuthEvent>
    implements $AuthEventCopyWith<$Res> {
  _$AuthEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoginImplCopyWith<$Res> {
  factory _$$LoginImplCopyWith(
          _$LoginImpl value, $Res Function(_$LoginImpl) then) =
      __$$LoginImplCopyWithImpl<$Res>;
  @useResult
  $Res call({SigninParams signinParams, BuildContext context});
}

/// @nodoc
class __$$LoginImplCopyWithImpl<$Res>
    extends _$AuthEventCopyWithImpl<$Res, _$LoginImpl>
    implements _$$LoginImplCopyWith<$Res> {
  __$$LoginImplCopyWithImpl(
      _$LoginImpl _value, $Res Function(_$LoginImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? signinParams = null,
    Object? context = null,
  }) {
    return _then(_$LoginImpl(
      signinParams: null == signinParams
          ? _value.signinParams
          : signinParams // ignore: cast_nullable_to_non_nullable
              as SigninParams,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$LoginImpl implements Login {
  const _$LoginImpl({required this.signinParams, required this.context});

  @override
  final SigninParams signinParams;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AuthEvent.login(signinParams: $signinParams, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoginImpl &&
            (identical(other.signinParams, signinParams) ||
                other.signinParams == signinParams) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, signinParams, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoginImplCopyWith<_$LoginImpl> get copyWith =>
      __$$LoginImplCopyWithImpl<_$LoginImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) {
    return login(signinParams, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) {
    return login?.call(signinParams, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) {
    if (login != null) {
      return login(signinParams, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) {
    return login(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) {
    return login?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) {
    if (login != null) {
      return login(this);
    }
    return orElse();
  }
}

abstract class Login implements AuthEvent {
  const factory Login(
      {required final SigninParams signinParams,
      required final BuildContext context}) = _$LoginImpl;

  SigninParams get signinParams;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$LoginImplCopyWith<_$LoginImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SignupImplCopyWith<$Res> {
  factory _$$SignupImplCopyWith(
          _$SignupImpl value, $Res Function(_$SignupImpl) then) =
      __$$SignupImplCopyWithImpl<$Res>;
  @useResult
  $Res call({SignUpParams signUpParams});
}

/// @nodoc
class __$$SignupImplCopyWithImpl<$Res>
    extends _$AuthEventCopyWithImpl<$Res, _$SignupImpl>
    implements _$$SignupImplCopyWith<$Res> {
  __$$SignupImplCopyWithImpl(
      _$SignupImpl _value, $Res Function(_$SignupImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? signUpParams = null,
  }) {
    return _then(_$SignupImpl(
      null == signUpParams
          ? _value.signUpParams
          : signUpParams // ignore: cast_nullable_to_non_nullable
              as SignUpParams,
    ));
  }
}

/// @nodoc

class _$SignupImpl implements Signup {
  const _$SignupImpl(this.signUpParams);

  @override
  final SignUpParams signUpParams;

  @override
  String toString() {
    return 'AuthEvent.signup(signUpParams: $signUpParams)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignupImpl &&
            (identical(other.signUpParams, signUpParams) ||
                other.signUpParams == signUpParams));
  }

  @override
  int get hashCode => Object.hash(runtimeType, signUpParams);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignupImplCopyWith<_$SignupImpl> get copyWith =>
      __$$SignupImplCopyWithImpl<_$SignupImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) {
    return signup(signUpParams);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) {
    return signup?.call(signUpParams);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) {
    if (signup != null) {
      return signup(signUpParams);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) {
    return signup(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) {
    return signup?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) {
    if (signup != null) {
      return signup(this);
    }
    return orElse();
  }
}

abstract class Signup implements AuthEvent {
  const factory Signup(final SignUpParams signUpParams) = _$SignupImpl;

  SignUpParams get signUpParams;
  @JsonKey(ignore: true)
  _$$SignupImplCopyWith<_$SignupImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GenerateOtpImplCopyWith<$Res> {
  factory _$$GenerateOtpImplCopyWith(
          _$GenerateOtpImpl value, $Res Function(_$GenerateOtpImpl) then) =
      __$$GenerateOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String email, BuildContext context});
}

/// @nodoc
class __$$GenerateOtpImplCopyWithImpl<$Res>
    extends _$AuthEventCopyWithImpl<$Res, _$GenerateOtpImpl>
    implements _$$GenerateOtpImplCopyWith<$Res> {
  __$$GenerateOtpImplCopyWithImpl(
      _$GenerateOtpImpl _value, $Res Function(_$GenerateOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
    Object? context = null,
  }) {
    return _then(_$GenerateOtpImpl(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GenerateOtpImpl implements GenerateOtp {
  const _$GenerateOtpImpl({required this.email, required this.context});

  @override
  final String email;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AuthEvent.generateOtp(email: $email, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GenerateOtpImpl &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, email, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GenerateOtpImplCopyWith<_$GenerateOtpImpl> get copyWith =>
      __$$GenerateOtpImplCopyWithImpl<_$GenerateOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) {
    return generateOtp(email, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) {
    return generateOtp?.call(email, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) {
    if (generateOtp != null) {
      return generateOtp(email, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) {
    return generateOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) {
    return generateOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) {
    if (generateOtp != null) {
      return generateOtp(this);
    }
    return orElse();
  }
}

abstract class GenerateOtp implements AuthEvent {
  const factory GenerateOtp(
      {required final String email,
      required final BuildContext context}) = _$GenerateOtpImpl;

  String get email;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GenerateOtpImplCopyWith<_$GenerateOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$VerifyOtpImplCopyWith<$Res> {
  factory _$$VerifyOtpImplCopyWith(
          _$VerifyOtpImpl value, $Res Function(_$VerifyOtpImpl) then) =
      __$$VerifyOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String email, String otp, BuildContext context});
}

/// @nodoc
class __$$VerifyOtpImplCopyWithImpl<$Res>
    extends _$AuthEventCopyWithImpl<$Res, _$VerifyOtpImpl>
    implements _$$VerifyOtpImplCopyWith<$Res> {
  __$$VerifyOtpImplCopyWithImpl(
      _$VerifyOtpImpl _value, $Res Function(_$VerifyOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
    Object? otp = null,
    Object? context = null,
  }) {
    return _then(_$VerifyOtpImpl(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$VerifyOtpImpl implements VerifyOtp {
  const _$VerifyOtpImpl(
      {required this.email, required this.otp, required this.context});

  @override
  final String email;
  @override
  final String otp;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AuthEvent.verifyOtp(email: $email, otp: $otp, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$VerifyOtpImpl &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.otp, otp) || other.otp == otp) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, email, otp, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$VerifyOtpImplCopyWith<_$VerifyOtpImpl> get copyWith =>
      __$$VerifyOtpImplCopyWithImpl<_$VerifyOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) {
    return verifyOtp(email, otp, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) {
    return verifyOtp?.call(email, otp, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(email, otp, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) {
    return verifyOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) {
    return verifyOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(this);
    }
    return orElse();
  }
}

abstract class VerifyOtp implements AuthEvent {
  const factory VerifyOtp(
      {required final String email,
      required final String otp,
      required final BuildContext context}) = _$VerifyOtpImpl;

  String get email;
  String get otp;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$VerifyOtpImplCopyWith<_$VerifyOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ResetPasswordImplCopyWith<$Res> {
  factory _$$ResetPasswordImplCopyWith(
          _$ResetPasswordImpl value, $Res Function(_$ResetPasswordImpl) then) =
      __$$ResetPasswordImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String email, String password, BuildContext context});
}

/// @nodoc
class __$$ResetPasswordImplCopyWithImpl<$Res>
    extends _$AuthEventCopyWithImpl<$Res, _$ResetPasswordImpl>
    implements _$$ResetPasswordImplCopyWith<$Res> {
  __$$ResetPasswordImplCopyWithImpl(
      _$ResetPasswordImpl _value, $Res Function(_$ResetPasswordImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
    Object? password = null,
    Object? context = null,
  }) {
    return _then(_$ResetPasswordImpl(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$ResetPasswordImpl implements ResetPassword {
  const _$ResetPasswordImpl(
      {required this.email, required this.password, required this.context});

  @override
  final String email;
  @override
  final String password;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AuthEvent.resetPassword(email: $email, password: $password, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResetPasswordImpl &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, email, password, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResetPasswordImplCopyWith<_$ResetPasswordImpl> get copyWith =>
      __$$ResetPasswordImplCopyWithImpl<_$ResetPasswordImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(SigninParams signinParams, BuildContext context)
        login,
    required TResult Function(SignUpParams signUpParams) signup,
    required TResult Function(String email, BuildContext context) generateOtp,
    required TResult Function(String email, String otp, BuildContext context)
        verifyOtp,
    required TResult Function(
            String email, String password, BuildContext context)
        resetPassword,
  }) {
    return resetPassword(email, password, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(SigninParams signinParams, BuildContext context)? login,
    TResult? Function(SignUpParams signUpParams)? signup,
    TResult? Function(String email, BuildContext context)? generateOtp,
    TResult? Function(String email, String otp, BuildContext context)?
        verifyOtp,
    TResult? Function(String email, String password, BuildContext context)?
        resetPassword,
  }) {
    return resetPassword?.call(email, password, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(SigninParams signinParams, BuildContext context)? login,
    TResult Function(SignUpParams signUpParams)? signup,
    TResult Function(String email, BuildContext context)? generateOtp,
    TResult Function(String email, String otp, BuildContext context)? verifyOtp,
    TResult Function(String email, String password, BuildContext context)?
        resetPassword,
    required TResult orElse(),
  }) {
    if (resetPassword != null) {
      return resetPassword(email, password, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Login value) login,
    required TResult Function(Signup value) signup,
    required TResult Function(GenerateOtp value) generateOtp,
    required TResult Function(VerifyOtp value) verifyOtp,
    required TResult Function(ResetPassword value) resetPassword,
  }) {
    return resetPassword(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(Login value)? login,
    TResult? Function(Signup value)? signup,
    TResult? Function(GenerateOtp value)? generateOtp,
    TResult? Function(VerifyOtp value)? verifyOtp,
    TResult? Function(ResetPassword value)? resetPassword,
  }) {
    return resetPassword?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Login value)? login,
    TResult Function(Signup value)? signup,
    TResult Function(GenerateOtp value)? generateOtp,
    TResult Function(VerifyOtp value)? verifyOtp,
    TResult Function(ResetPassword value)? resetPassword,
    required TResult orElse(),
  }) {
    if (resetPassword != null) {
      return resetPassword(this);
    }
    return orElse();
  }
}

abstract class ResetPassword implements AuthEvent {
  const factory ResetPassword(
      {required final String email,
      required final String password,
      required final BuildContext context}) = _$ResetPasswordImpl;

  String get email;
  String get password;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$ResetPasswordImplCopyWith<_$ResetPasswordImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$AuthState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            SignInEntity? signInEntity, SignUpEntity? signUpEntity)
        success,
    required TResult Function(String error) failure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult? Function(String error)? failure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult Function(String error)? failure,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
    required TResult Function(_Failure value) failure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
    TResult? Function(_Failure value)? failure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    TResult Function(_Failure value)? failure,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AuthStateCopyWith<$Res> {
  factory $AuthStateCopyWith(AuthState value, $Res Function(AuthState) then) =
      _$AuthStateCopyWithImpl<$Res, AuthState>;
}

/// @nodoc
class _$AuthStateCopyWithImpl<$Res, $Val extends AuthState>
    implements $AuthStateCopyWith<$Res> {
  _$AuthStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$AuthStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'AuthState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            SignInEntity? signInEntity, SignUpEntity? signUpEntity)
        success,
    required TResult Function(String error) failure,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult? Function(String error)? failure,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult Function(String error)? failure,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
    required TResult Function(_Failure value) failure,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
    TResult? Function(_Failure value)? failure,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    TResult Function(_Failure value)? failure,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements AuthState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$AuthStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'AuthState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            SignInEntity? signInEntity, SignUpEntity? signUpEntity)
        success,
    required TResult Function(String error) failure,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult? Function(String error)? failure,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult Function(String error)? failure,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
    required TResult Function(_Failure value) failure,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
    TResult? Function(_Failure value)? failure,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    TResult Function(_Failure value)? failure,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements AuthState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$SuccessImplCopyWith<$Res> {
  factory _$$SuccessImplCopyWith(
          _$SuccessImpl value, $Res Function(_$SuccessImpl) then) =
      __$$SuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({SignInEntity? signInEntity, SignUpEntity? signUpEntity});
}

/// @nodoc
class __$$SuccessImplCopyWithImpl<$Res>
    extends _$AuthStateCopyWithImpl<$Res, _$SuccessImpl>
    implements _$$SuccessImplCopyWith<$Res> {
  __$$SuccessImplCopyWithImpl(
      _$SuccessImpl _value, $Res Function(_$SuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? signInEntity = freezed,
    Object? signUpEntity = freezed,
  }) {
    return _then(_$SuccessImpl(
      signInEntity: freezed == signInEntity
          ? _value.signInEntity
          : signInEntity // ignore: cast_nullable_to_non_nullable
              as SignInEntity?,
      signUpEntity: freezed == signUpEntity
          ? _value.signUpEntity
          : signUpEntity // ignore: cast_nullable_to_non_nullable
              as SignUpEntity?,
    ));
  }
}

/// @nodoc

class _$SuccessImpl implements _Success {
  const _$SuccessImpl({this.signInEntity, this.signUpEntity});

  @override
  final SignInEntity? signInEntity;
  @override
  final SignUpEntity? signUpEntity;

  @override
  String toString() {
    return 'AuthState.success(signInEntity: $signInEntity, signUpEntity: $signUpEntity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SuccessImpl &&
            (identical(other.signInEntity, signInEntity) ||
                other.signInEntity == signInEntity) &&
            (identical(other.signUpEntity, signUpEntity) ||
                other.signUpEntity == signUpEntity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, signInEntity, signUpEntity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SuccessImplCopyWith<_$SuccessImpl> get copyWith =>
      __$$SuccessImplCopyWithImpl<_$SuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            SignInEntity? signInEntity, SignUpEntity? signUpEntity)
        success,
    required TResult Function(String error) failure,
  }) {
    return success(signInEntity, signUpEntity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult? Function(String error)? failure,
  }) {
    return success?.call(signInEntity, signUpEntity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult Function(String error)? failure,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(signInEntity, signUpEntity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
    required TResult Function(_Failure value) failure,
  }) {
    return success(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
    TResult? Function(_Failure value)? failure,
  }) {
    return success?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    TResult Function(_Failure value)? failure,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class _Success implements AuthState {
  const factory _Success(
      {final SignInEntity? signInEntity,
      final SignUpEntity? signUpEntity}) = _$SuccessImpl;

  SignInEntity? get signInEntity;
  SignUpEntity? get signUpEntity;
  @JsonKey(ignore: true)
  _$$SuccessImplCopyWith<_$SuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$FailureImplCopyWith<$Res> {
  factory _$$FailureImplCopyWith(
          _$FailureImpl value, $Res Function(_$FailureImpl) then) =
      __$$FailureImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$FailureImplCopyWithImpl<$Res>
    extends _$AuthStateCopyWithImpl<$Res, _$FailureImpl>
    implements _$$FailureImplCopyWith<$Res> {
  __$$FailureImplCopyWithImpl(
      _$FailureImpl _value, $Res Function(_$FailureImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$FailureImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$FailureImpl implements _Failure {
  const _$FailureImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'AuthState.failure(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FailureImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FailureImplCopyWith<_$FailureImpl> get copyWith =>
      __$$FailureImplCopyWithImpl<_$FailureImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            SignInEntity? signInEntity, SignUpEntity? signUpEntity)
        success,
    required TResult Function(String error) failure,
  }) {
    return failure(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult? Function(String error)? failure,
  }) {
    return failure?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(SignInEntity? signInEntity, SignUpEntity? signUpEntity)?
        success,
    TResult Function(String error)? failure,
    required TResult orElse(),
  }) {
    if (failure != null) {
      return failure(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
    required TResult Function(_Failure value) failure,
  }) {
    return failure(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
    TResult? Function(_Failure value)? failure,
  }) {
    return failure?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    TResult Function(_Failure value)? failure,
    required TResult orElse(),
  }) {
    if (failure != null) {
      return failure(this);
    }
    return orElse();
  }
}

abstract class _Failure implements AuthState {
  const factory _Failure(final String error) = _$FailureImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$FailureImplCopyWith<_$FailureImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
