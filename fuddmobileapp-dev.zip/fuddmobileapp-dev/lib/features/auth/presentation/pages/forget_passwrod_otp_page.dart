import 'dart:io';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_form.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_apple.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_google.dart';
import 'package:pinput/pinput.dart';

@RoutePage()
class ForgetPasswrodOtpPage extends StatefulWidget {
   ForgetPasswrodOtpPage({super.key,required this.email});
  static const routeName = '/forget_password_otp';
  String email;

  @override
  State<ForgetPasswrodOtpPage> createState() => _SigninPageState();
}

class _SigninPageState extends State<ForgetPasswrodOtpPage> {
  final controller = TextEditingController();
  final focusNode = FocusNode();
  @override
  @override
  void dispose() {
    controller.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 50,
      height: 54,
      textStyle: const TextStyle(
        fontSize: 20,
        color: Color.fromRGBO(70, 69, 66, 1),
      ),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(232, 235, 241, 0.37),
        borderRadius: BorderRadius.circular(10),
      ),
    );

    final cursor = Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        width: 21,
        height: 1,
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: const Color.fromRGBO(137, 146, 160, 1),
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );

    return Scaffold(
      appBar:PreferredSize(preferredSize: Size.fromHeight(100),
      child: Stack(
        children: [
          Image.asset(
            'assets/images/top-bg.png',
            height: 80,
          ),
          Positioned(
            top: 40,
              left: 10,
              child: IconButton(
            onPressed: () {
              context.router.pop();
            },
            icon: const Icon(Icons.arrow_back),
          )),
          const Positioned(
            top: 50,
              left: 80,
              child: Text("Email Verification",style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),)),
        ],
      ),),
      body: Container(
        padding: const EdgeInsets.all(20),
        alignment: AlignmentDirectional.center,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Gap(20),
            const Text("Get your code",style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
            ),
            const Gap(10),
            const Text("Please enter the 6 digit code that send to your email address",
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.normal,
                  color: Colors.grey
              ),
              textAlign: TextAlign.center,
            ),
            const Gap(30),
            Pinput(
              length: 6,
              controller: controller,
              focusNode: focusNode,
              defaultPinTheme: defaultPinTheme,
              separatorBuilder: (index) => const SizedBox(width: 8),
              onCompleted: (value) {
                context.read<AuthBloc>().add(VerifyOtp(email: widget.email, context: context, otp: controller.text));
              },
              focusedPinTheme: defaultPinTheme.copyWith(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: const [
                    BoxShadow(
                      color: Color.fromRGBO(0, 0, 0, 0.05999999865889549),
                      offset: Offset(0, 3),
                      blurRadius: 16,
                    ),
                  ],
                ),
              ),
              showCursor: true,
              cursor: cursor,
            ),
            const Gap(10),
            Wrap(
              children: [
                const Text("If you don't received code?",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.normal,
                      color: Colors.grey
                  ),
                  textAlign: TextAlign.center,
                ),
                InkWell(
                  child: const Text("Resend",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.normal,
                        color: Colors.blue
                    ),
                    textAlign: TextAlign.center,
                  ),
                  onTap: (){

                  },
                )
              ],
            ),
            const Gap(50),
            BlocConsumer<AuthBloc, AuthState>(
              listener: (context, state) {},
              builder: (context, state) {
                return state.maybeWhen(
                  success: (signInEntity, signUpEntity) {
                    return _button();
                  },
                  loading: () => const Center(
                      child: CircularProgressIndicator()),
                  orElse: () {
                    return _button();
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
  Widget _button(){
    return GestureDetector(
      onTap: () {
        if(controller.text.length==4){
          context.read<AuthBloc>().add(VerifyOtp(email: widget.email, context: context, otp: controller.text));
        }
        },
      child: Container(
        height: 50,
        width: double.infinity,
        decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius:
            BorderRadius.circular(50)),
        child: const Center(
          child: Text(
            'Verify and Proceed',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
