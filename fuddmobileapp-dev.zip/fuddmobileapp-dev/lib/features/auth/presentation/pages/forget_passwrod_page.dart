import 'dart:io';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_form.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_apple.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_google.dart';

@RoutePage()
class ForgetPasswrodPage extends StatefulWidget {
  const ForgetPasswrodPage({super.key});
  static const routeName = '/forget_password';

  @override
  State<ForgetPasswrodPage> createState() => _SigninPageState();
}

class _SigninPageState extends State<ForgetPasswrodPage> with WidgetsBindingObserver {
  final emailController = TextEditingController();

  final passwordController = TextEditingController();
  bool isKeyboardActive = false;
  final formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  @override
  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeMetrics() {
    final bool isKeyboardShowing = MediaQuery.of(context).viewInsets.bottom > 0;
    setState(() {
      isKeyboardActive = isKeyboardShowing;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:PreferredSize(preferredSize: Size.fromHeight(100),
      child: Stack(
        children: [
          Image.asset(
            'assets/images/top-bg.png',
            height: 80,
          ),
          Positioned(
            top: 40,
              left: 10,
              child: IconButton(
            onPressed: () {
              context.router.pop();
            },
            icon: const Icon(Icons.arrow_back),
          )),
          const Positioned(
            top: 50,
              left: 80,
              child: Text("Forgot Password",style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),)),
        ],
      ),),
      body: Container(
        padding: const EdgeInsets.all(20),
        alignment: AlignmentDirectional.center,
        child: Form(
          key: formKey,
          child:  Column(
            children: [
              const Gap(20),
            const Text("Mail Address Here",style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          ),
              const Gap(10),
              const Text("Enter the email address associated with your account",
                style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color: Colors.grey
              ),
                textAlign: TextAlign.center,
              ),
              const Gap(30),
              InputField(controller: emailController,
              hintText: "Email",),
              const Gap(50),
              BlocConsumer<AuthBloc, AuthState>(
                listener: (context, state) {

                },
                builder: (context, state) {
                  return state.maybeWhen(
                    success: (signInEntity, signUpEntity) {

                      return _button();
                    },
                    loading: () => const Center(
                        child: CircularProgressIndicator()),
                    orElse: () {
                      return _button();
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _button(){
    return GestureDetector(
      onTap: () {
        if (formKey.currentState!.validate()) {
          context.read<AuthBloc>().add(GenerateOtp(email: emailController.text, context: context));
        }
      },
      child: Container(
        height: 50,
        width: double.infinity,
        decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius:
            BorderRadius.circular(50)),
        child: const Center(
          child: Text(
            'Recover Password',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
