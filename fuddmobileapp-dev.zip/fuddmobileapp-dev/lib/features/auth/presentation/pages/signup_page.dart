import 'dart:io';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gap/gap.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_up_form.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_up_with_apple.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_up_with_google.dart';

@RoutePage()
class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  static const routeName = '/signup';

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> with WidgetsBindingObserver {
  final emailController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final fullNameController = TextEditingController();
  final passwordController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  bool isKeyboardActive = false;
  bool isSubscribe = false;
  bool isTerm = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeMetrics() {
    final bool isKeyboardShowing = MediaQuery.of(context).viewInsets.bottom > 0;
    setState(() {
      isKeyboardActive = isKeyboardShowing;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: Image.asset(
              'assets/images/top-bg.png',
              height: 100,
            ),
          ),
          if (!isKeyboardActive)
            GestureDetector(
              onTap: () {
                context.router.push(const SigninRoute());
              },
              child: Align(
                alignment: Alignment.bottomRight,
                child: Image.asset(
                  'assets/images/footer-bg.png',
                  height: 100,
                ),
              ),
            ),
          ListView(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MediaQuery.of(context).size.height > 800
                      ? Gap(MediaQuery.of(context).size.height * 0.1)
                      : const Gap(20),
                  Center(
                    child: Image.asset(
                      'assets/images/logo3.png',
                      fit: BoxFit.cover,
                      height: 160,
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 20, right: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Sign up',
                          style: TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SignUpForm(
                            fullNameController: fullNameController,
                            emailController: emailController,
                            passwordController: passwordController,
                            formKey: formKey),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            IconButton(onPressed: () {
                              setState(() {
                                isSubscribe = !isSubscribe;
                              });
                            }, icon:  Icon(isSubscribe?Icons.check_box:Icons.check_box_outline_blank,)),
                            const Text("Subscribe to the NL?"),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            IconButton(onPressed: () {
                              setState(() {
                                isTerm = !isTerm;
                              });
                            }, icon:  Icon(isTerm?Icons.check_box:Icons.check_box_outline_blank,)),
                            Expanded(child: RichText(
                              overflow: TextOverflow.clip,
                              text: TextSpan(
                                children: [
                                  const TextSpan(
                                      text: 'Agree to the ',
                                      style: TextStyle(color: Colors.black)),
                                  TextSpan(
                                    text: 'Terms of Service',
                                    style: const TextStyle(
                                      decoration: TextDecoration.underline,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        showDialog(
                                          barrierDismissible: false,
                                          context: context,
                                          builder: (BuildContext context) {
                                            return Container();
                                          },
                                        );
                                      },
                                  ),
                                  const TextSpan(
                                      text: ' and ',
                                      style: TextStyle(color: Colors.black)),
                                  TextSpan(
                                    text: 'Privacy Policy',
                                    style: const TextStyle(
                                      decoration: TextDecoration.underline,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        showDialog(
                                          barrierDismissible: false,
                                          // barrierColor: Colors.white,
                                          context: context,
                                          builder: (BuildContext context) {
                                            return Container();
                                          },
                                        );
                                      },
                                  ),
                                  const TextSpan(
                                      text: ' including usage of cookies',
                                      style: TextStyle(color: Colors.black)),
                                ],
                              ),
                            ))
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        BlocBuilder<AuthBloc, AuthState>(
                          builder: (context, state) {
                            return state.maybeWhen(
                              success: (signInEntity, signUpEntity) {
                                WidgetsBinding.instance
                                    .addPostFrameCallback((_) {
                                  context.router.push(const DashboardRoute());
                                });
                                return const SizedBox();
                              },
                              loading: () => const Center(child: CircularProgressIndicator()),
                              orElse: () {
                                return InkWell(
                                  onTap: () {
                                    if (formKey.currentState!.validate()) {
                                      if(!isSubscribe){
                                        Fluttertoast.showToast(
                                            msg: "Subscribe to the NL required",
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.BOTTOM,
                                            timeInSecForIosWeb: 1,
                                            backgroundColor: Colors.red,
                                            textColor: Colors.white,
                                            fontSize: 14.0
                                        );
                                        return;
                                      }
                                      context.read<AuthBloc>().add(
                                            Signup(
                                              SignUpParams(
                                                name: fullNameController.text
                                                    .trim(),
                                                email:
                                                    emailController.text.trim(),
                                                password: passwordController
                                                    .text
                                                    .trim(),
                                              ),
                                            ),
                                          );
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                        color: AppColors.black,
                                        borderRadius:
                                            BorderRadius.circular(50)),
                                    child: const Center(
                                      child: Text(
                                        'Sing up',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Center(
                          child: RichText(
                            overflow: TextOverflow.clip,
                            text: TextSpan(
                              children: [
                                const TextSpan(
                                    text: 'By Signup You Agree to the ',
                                    style: TextStyle(color: Colors.black)),
                                TextSpan(
                                  text: 'Terms of Service',
                                  style: const TextStyle(
                                    decoration: TextDecoration.underline,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      showDialog(
                                        barrierDismissible: false,
                                        // barrierColor: Colors.white,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Container();
                                        },
                                      );
                                    },
                                ),
                                const TextSpan(
                                    text: ' and ',
                                    style: TextStyle(color: Colors.black)),
                                TextSpan(
                                  text: 'Privacy Policy',
                                  style: const TextStyle(
                                    decoration: TextDecoration.underline,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      showDialog(
                                        barrierDismissible: false,
                                        // barrierColor: Colors.white,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Container();
                                        },
                                      );
                                    },
                                ),
                                const TextSpan(
                                    text: ' including usage of cookies',
                                    style: TextStyle(color: Colors.black)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        Platform.isAndroid
                            ? Center(
                                child: Material(
                                    color: Colors.white,
                                    elevation: 5,
                                    borderRadius: BorderRadius.circular(8),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SizedBox(
                                        width: 160,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            const Text(
                                              'Sign up with',
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            GoogleSignUpButton(),
                                          ],
                                        ),
                                      ),
                                    )),
                              )
                            : Center(
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    GoogleSignUpButton(),
                                    const AppleSignUpnButton()
                                  ],
                                ),
                              ),
                        const Gap(20),
                        GestureDetector(
                          onTap: () {
                            context.router.push(const SigninRoute());
                          },
                          child: Container(
                            margin: const EdgeInsets.only(
                                left: 30, right: 30, bottom: 10),
                            child: RichText(
                              text: const TextSpan(
                                text: 'You Already have an account? ',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                                children: <TextSpan>[
                                  TextSpan(
                                    text: 'Log in',
                                    style: TextStyle(
                                        color: AppColors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
