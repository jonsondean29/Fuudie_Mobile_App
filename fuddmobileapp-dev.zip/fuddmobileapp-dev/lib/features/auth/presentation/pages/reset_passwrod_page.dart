import 'dart:io';
import 'package:fuud/core/widgets/appbar.dart';
import 'package:fuud/core/widgets/input_field.dart';
import 'package:gap/gap.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:fuud/config/theme/colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fuud/config/routes/app_router.dart';
import 'package:fuud/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:fuud/features/auth/domain/usecases/sign_in_usecase.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_form.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_apple.dart';
import 'package:fuud/features/auth/presentation/widgets/sign_in_with_google.dart';

@RoutePage()
class ResetPasswrodPage extends StatefulWidget {
   ResetPasswrodPage({super.key,required this.email});
  static const routeName = '/reset_password';
  String email;

  @override
  State<ResetPasswrodPage> createState() => _SigninPageState();
}

class _SigninPageState extends State<ResetPasswrodPage>  {
  final passwordController = TextEditingController();
  final cnfPasswordController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  @override
  @override
  void dispose() {
    passwordController.dispose();
    cnfPasswordController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:PreferredSize(preferredSize: Size.fromHeight(100),
      child: Stack(
        children: [
          Image.asset(
            'assets/images/top-bg.png',
            height: 80,
          ),
          Positioned(
            top: 40,
              left: 10,
              child: IconButton(
            onPressed: () {
              context.router.pop();
            },
            icon: const Icon(Icons.arrow_back),
          )),
          const Positioned(
            top: 50,
              left: 80,
              child: Text("Reset Password",style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),)),
        ],
      ),),
      body: Container(
        padding: const EdgeInsets.all(20),
        alignment: AlignmentDirectional.center,
        child: Form(
          key: formKey,
          child:  Column(
            children: [
              const Gap(20),
            const Text("Enter New Password",style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          ),
              const Gap(10),
              const Text("Your new password must be different from previously used password",
                style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color: Colors.grey
              ),
                textAlign: TextAlign.center,
              ),
              const Gap(30),
              InputField(controller: passwordController,
              hintText: "Password",keyboardType: TextInputType.visiblePassword,
              obscureText: true,),
              const Gap(20),
              InputField(controller: cnfPasswordController,
              hintText: "Confirm Password",keyboardType: TextInputType.visiblePassword,
              obscureText: true,
                validator: (p) {
                  if(p!.isEmpty){
                    return "Confirm password required";
                  }
                  if(p!=passwordController.text){
                    return "Password not match";
                  }
                  return null;
                },
              ),
              const Gap(50),
              BlocConsumer<AuthBloc, AuthState>(
                listener: (context, state) {},
                builder: (context, state) {
                  return state.maybeWhen(
                    success: (signInEntity, signUpEntity) {
                      return _button();
                    },
                    loading: () => const Center(
                        child: CircularProgressIndicator()),
                    orElse: () {
                      return _button();
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _button(){
    return GestureDetector(
      onTap: () {
        if (formKey.currentState!.validate()) {
          context.read<AuthBloc>().add(ResetPassword(email: widget.email, context: context, password: passwordController.text));
        }
      },
      child: Container(
        height: 50,
        width: double.infinity,
        decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius:
            BorderRadius.circular(50)),
        child: const Center(
          child: Text(
            'Recover Password',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
