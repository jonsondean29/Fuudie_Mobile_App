import 'package:fuud/features/auth/data/models/reset_password_responce.dart';

class ResetPasswordEntity {
  final int? messageType;
  final String? message;
  final ReturnId? returnId;

  ResetPasswordEntity({this.messageType, this.message, this.returnId});
}
