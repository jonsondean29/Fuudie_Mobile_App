import 'package:dartz/dartz.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/features/auth/domain/entities/sign_up_entity.dart';
import 'package:fuud/features/auth/domain/usecases/sign_up_usecase.dart';

abstract class SignUpRepository {
  Future<Either<Failure, SignUpEntity>> signupUser(SignUpParams params);
}
