import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/auth/domain/entities/sign_up_entity.dart';
import 'package:fuud/features/auth/domain/repositories/sign_up_repository.dart';

@LazySingleton()
class SignUpUsecase implements UseCaseWithParams<void, SignUpParams> {
  final SignUpRepository signUpRepository;

  SignUpUsecase({required this.signUpRepository});
  @override
  Future<Either<Failure, SignUpEntity>> call(params) {
    return signUpRepository.signupUser(params);
  }
}

class SignUpParams extends Equatable {
  final String email;
  final String name;
  final String password;

  const SignUpParams(
      {required this.email, required this.password, required this.name});
  @override
  List<Object?> get props => [email, password];
  Map<String, dynamic> toJson() {
    return {"email": email, "password": password, "name": name};
  }
}
