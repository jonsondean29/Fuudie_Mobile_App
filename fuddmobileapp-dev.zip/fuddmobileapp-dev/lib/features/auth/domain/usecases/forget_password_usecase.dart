import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:fuud/core/error/failure.dart';
import 'package:fuud/core/usecase/usecase.dart';
import 'package:fuud/features/auth/domain/entities/sign_in_entity.dart';
import 'package:fuud/features/auth/domain/repositories/sign_in_repositories.dart';

@LazySingleton()
class ForgetPasswordUsecase implements UseCaseWithParams<void, ForgetPasswordParams> {
  final SignInRepository signInRepository;

  ForgetPasswordUsecase({required this.signInRepository});
  @override
  Future<Either<Failure, SignInEntity>> call(params) {
    return signInRepository.forgetPassword(params);
  }
}
enum Type{
  GenerateOtp,VerifyOtp,ResetPassword
}
class ForgetPasswordParams extends Equatable {
  final String email;
  final String? otp;
  final String? password;
  final Type type;

  const ForgetPasswordParams({required this.email, this.password,this.otp,required this.type});
  @override
  List<Object?> get props => [email, password];
  Map<String, dynamic> toJson() {
    return {"email": email, "password": password};
  }
}
